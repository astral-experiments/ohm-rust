"""Recover the native header matrix after the first A failed before emitting a seed."""
import base64
import contextlib
import hashlib
import importlib.util
import inspect
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

N=Path(__file__).resolve().parent
D=N.parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
c=load("signed_complete_native_headers",D/"closed.py")
p,x,q,m=c.p,c.x,c.q,c.x.m
sha,read,need=x.sha,x.read,x.need
REG=N/"registration.json"
FAILED=D/"cross-legacy"/"migration-unforced-001"
INPUT="ebe4d5e863c57fb856554508ea4538e29a1eea6b1c92692ed52532139585a438"
STDERR="e3952b35216ae59db0a26e29534f06b4e7d2c83b50ecc0303ee6a1240a99c330"
LOG=N.parents[4]/"native-supervision"/"20261101T0648-header-native"/"legacy-unforced.log"
OLD='need(path==m.K/"census.py","exact graph decoder")'
NEW='need(Path(path)==m.K/"census.py","exact graph decoder")'
def repaired():
    source=inspect.getsource(x.worker)
    need(source.count(OLD)==1 and NEW not in source and 'runpy.run_path(str(D/"census.py"))' in (m.K/"probe_worker.py").read_text(),"actual emitter and exact failed callback")
    scope=dict(vars(x));exec(compile(source.replace(OLD,NEW),str(N/"matrix-worker.py"),"exec"),scope)
    return scope["worker"]
def observe_worker():
    q.overlay(p.worker,x=SimpleNamespace(worker=repaired()))()
def audit():
    j=read(REG)
    for n,h in j["files"].items():need(sha(N/n)==h,"sealed recovery "+n)
    need(sha(LOG)==STDERR and sha(FAILED/"inputs.json")==INPUT and
         [a.name for a in FAILED.iterdir()]==["inputs.json"],"original absent seed and unmodified failure")
    need(sha(D/"matrix-registration.json")==j["science"] and sha(p.REG)==j["observation"] and sha(c.REG)==j["old_reader"],"original issuer chain")
    c.audit();repaired()
    return j
def control():
    # Use the actual owning caller spelling, the exact authorized path, and a different existing file.
    def exercise(fn,name,wrong=False):
        def body():
            a=D/"census.py";target=a.with_name("fixture.rs") if wrong else a
            result=runpy.run_path(str(target));print(json.dumps({"decoded":callable(result["count"])}))
        def give(path):
            need(Path(path)==m.K/"probe_worker.py","genuine worker source");return {"main":body}
        buf=io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):q.overlay(fn,runpy=SimpleNamespace(run_path=give))()
            return json.loads(buf.getvalue())["decoded"]
        except (ValueError,AssertionError) as exc:
            need(str(exc)=="exact graph decoder",name);return str(exc)
    need(exercise(x.worker,"old")=="exact graph decoder" and exercise(repaired(),"valid") is True and exercise(repaired(),"unrelated",True)=="exact graph decoder","bad path, corrected string, unrelated path")
    return {"original":STDERR,"input":INPUT,"genuine_owning_call":"runpy.run_path(str(D/'census.py'))","fixed_gate":NEW,"other_existing_path_rejected":True,"native_calls":0}
def put(path,data):
    with path.open("x") as f:json.dump(data,f,sort_keys=True,indent=1);f.write("\n")
def attest(row,force):
    need(row.get("worker_exit")==0 and row["forced_rustc_version"]==row["perf_artifact_env"]==force,"actual native process and exact environment")
def execute(mode,role,arm,edit,state,seed=b"",route="matrix",accept_worker_failure=False):
    force=None if mode=="unforced" else m.VERSIONS["forced"]
    need(mode in m.VERSIONS and route in ("matrix","previous","original"),"registered native dispatch")
    path={"matrix":N/"matrix-worker.py","previous":N/"previous-worker.py","original":D/"migration.py"}[route]
    def launch(argv,*,env,**kw):
        need(argv[argv.index("/usr/bin/python3")+2:]==[str(path),edit,state,m.M["raw_sha"](seed) if seed else "-",str(arm["header_format"]),arm["driver_relative"],arm["driver_sha256"],arm["llvm_sha256"],arm["cohort"],role],"exact actual worker arguments and subject")
        need(not ({"RUSTC_FORCE_RUSTC_VERSION","RUSTC_FORCE_INCR_COMP_ARTIFACT_HEADER"}&env.keys()),"sterile native starting environment")
        if force:env=env|{"RUSTC_FORCE_RUSTC_VERSION":force,"RUSTC_FORCE_INCR_COMP_ARTIFACT_HEADER":force}
        proc=subprocess.run(argv,env=env,**kw)
        if proc.returncode:
            record={"scope":ACTIVE,"mode":mode,"route":route,"argv":argv,"worker_exit":proc.returncode,"stdout_sha256":hashlib.sha256(proc.stdout).hexdigest(),
                    "stderr_sha256":hashlib.sha256(proc.stderr).hexdigest(),"stdout_length":len(proc.stdout),"stderr_length":len(proc.stderr),
                    "stderr":proc.stderr[:1048576].decode(errors="replace"),"full_stderr":len(proc.stderr)<1048576}
            i=0
            while (N/"receipts"/f"{ACTIVE}-{mode}-{role}-{edit}-{state}-failure-{i}.json").exists():i+=1
            put(N/"receipts"/f"{ACTIVE}-{mode}-{role}-{edit}-{state}-failure-{i}.json",record)
        return proc
    res=q.overlay(m.M["step"],WORKER=path,subprocess=SimpleNamespace(run=launch))(role,arm,edit,state,seed)
    if not accept_worker_failure or res.get("worker_exit")==0:attest(res,force)
    if res.get("worker_exit")==0:need(res["seed_sha256"]==(m.M["raw_sha"](seed) if seed else "-"),"real previous seed")
    return res
class Routes:
    def __truediv__(self,name):
        return (N if name in ("cross-legacy","cross-ctfe") else D)/name
class Seeds:
    def __truediv__(self,name):
        need(name.startswith("cache-seeds-") and "/" not in name,"scoped physical seed")
        return q.GROUP/("dispatch-002-"+name)
def matrix(scope):
    ctx=q.overlay(x.bind,D=Routes())(scope)
    ctx["issuer"]().GROUP=Seeds()
    ctx["step"]=execute
    return ctx
def old_step(mode,role,arm,edit,state,seed=b""):
    return execute(mode,role,arm,edit,state,seed,route="previous",accept_worker_failure=True)
def grant():
    need(os.environ.get("OHM_HEADER_DISPATCH")==sha(REG),"explicit material/worker recovery registration")
def smoke():
    global ACTIVE
    ACTIVE="smoke";grant();out=N/"receipts"/"smoke.json";need(not out.exists(),"new four-lock dispatch smoke")
    h=q.v.F.q.check_host(True);q.b.open_bank();q.v.budget_live()
    with q.b.leases.PRE.four(h) as locks:
        need(len(locks)==4 and q.b.leases.available()["ram"]>=60*q.b.G and shutil.disk_usage(q.b.BANK).free>2*q.b.G+256*m.Mi,"all four native leases and original floors")
        orig_input=read(FAILED/"inputs.json");arms=x.subjects("legacy",False)
        need(arms==orig_input["subjects"],"original unforced A input including all eight validated SDKs")
        bad=execute("unforced","base8",arms["base8"],"A","ordinary",route="original",accept_worker_failure=True)
        need(bad["worker_exit"]!=0 and bad["worker_stderr"].rstrip().endswith(("ValueError: exact graph decoder","AssertionError: exact graph decoder")),"genuine repeated original worker failure")
        traces={}
        for tag,arm,mode,route in [("base8",arms["base8"],"unforced","matrix"),("CTFE",p.subjects(False)["CTFE"],"forced","previous")]:
            init=execute(mode,tag,arm,"A","ordinary",route=route);seed=base64.b64decode(init.pop("seed_gz"),validate=True)
            need(init["compile"]["exit"]==0 and init["run"]["stdout"]=="11\n" and 0<len(seed)<=12*m.Mi and m.M["raw_sha"](seed)==init["seed_gz_sha256"],"actual stored native A")
            loaded=execute(mode,tag,arm,"B","loaded",seed,route=route)
            need(loaded["compile"]["exit"]==0 and loaded["run"]["stdout"]=="17\n","actual same compiler read and changed native behavior")
            traces[tag]={"seed":init,"loaded":loaded,"seed_sha256":m.M["raw_sha"](seed),"route":route,"mode":mode}
        doc={"registration":sha(REG),"original_failure":STDERR,"original_input":INPUT,"original_worker":bad,"locks":list(map(str,locks)),"cases":traces,"performance_rows":0}
        put(out,doc);return {"smoke":sha(out),"rows":sorted(traces),"reproduced_original":bad["worker_exit"],"performance_rows":0}
def smoke_evidence():
    rec=N/"receipts"/"smoke.json";a=read(rec)
    need(a["registration"]==sha(REG) and a["original_failure"]==STDERR and a["original_input"]==INPUT and len(a["locks"])==4 and a["original_worker"]["worker_exit"] and a["original_worker"]["worker_stderr"].rstrip().endswith("exact graph decoder") and set(a["cases"])=={"base8","CTFE"},"certified genuine worker smoke")
    for k,mode in (("base8","unforced"),("CTFE","forced")):
        r=a["cases"][k];need(r["mode"]==mode and r["seed"]["run"]["stdout"]=="11\n" and r["loaded"]["run"]["stdout"]=="17\n" and r["seed"]["seed_gz_sha256"]==r["loaded"]["seed_sha256"]==r["seed_sha256"],"real emitted and reconsumed A history")
    return sha(rec)
def check_one(scope,mode):
    if scope=="previous":
        out=N/"cross-previous"/(mode+"-001");v=p.analyze(out,mode,p.subjects(True));f=out/"complete.json"
    else:
        out=N/("cross-"+scope)/("migration-"+mode+"-001");v=matrix(scope)["check"](mode,x.subjects(scope,True));f=out/"accepted.json"
    need(v==read(f),"all original semantic and source controls replayed")
    issue=N/"receipts"/(scope+"-"+mode+".json")
    need(read(issue)==issuance(scope,mode,f),"actual corrected worker, fresh output and first failed attempt")
    return v
def issuance(scope,mode,f):
    return {"registration":sha(REG),"science":sha(p.REG if scope=="previous" else x.REG),"smoke":smoke_evidence(),"prior_failed_inputs":INPUT,"prior_failure":STDERR,
            "scope":scope,"mode":mode,"signed_result":sha(f),"worker_source":sha(N/("previous-worker.py" if scope=="previous" else "matrix-worker.py")),"performance_rows":0}
def run(scope,mode):
    global ACTIVE
    ACTIVE=scope;grant();smoke_evidence()
    if scope=="previous":
        os.environ["OHM_OBSERVE_PRIOR_11"]=sha(p.REG)
        func=q.overlay(p.run,RESULT=N/"cross-previous",GROUP=q.b.BANK/"trait-rosters-observe-old11-dispatch-002",step=old_step)
        val=func(mode);f=N/"cross-previous"/(mode+"-001")/"complete.json"
    else:
        os.environ["OHM_PRIVATE_HEADER_MATRIX"]=sha(x.REG)
        val=matrix(scope)["run"](mode);f=N/("cross-"+scope)/("migration-"+mode+"-001")/"accepted.json"
    need(val==read(f),"actual terminal data");put(N/"receipts"/(scope+"-"+mode+".json"),issuance(scope,mode,f))
    return val
def closed(level):
    def checked(scope,mode,arms):
        out=N/("cross-"+scope)/("migration-"+mode+"-001")
        z=matrix(scope)["check"](mode,arms);need(z==read(out/"accepted.json") and read(N/"receipts"/(scope+"-"+mode+".json"))==issuance(scope,mode,out/"accepted.json"),"new dispatch and unchanged original decision")
        return q.overlay(c.checked,D=N,x=SimpleNamespace(bind=matrix))(scope,mode,arms)
    pp=SimpleNamespace(**vars(p));pp.RESULT=N/"cross-previous"
    if level=="complete":
        for mode in m.VERSIONS:
            f=pp.RESULT/(mode+"-001")/"complete.json";need(read(N/"receipts"/("previous-"+mode+".json"))==issuance("previous",mode,f),"authentic corrected old-worker disposition")
    result=q.overlay(c.main,checked=checked,p=pp)([level])
    return result|{"original_closed_registration_sha256":result["registration_sha256"],"registration_sha256":sha(REG),"dispatch_smoke_sha256":smoke_evidence(),"prior_failed_inputs":INPUT,"prior_failure":STDERR}
ACTIVE="none"
def main(a):
    need(__debug__ and os.sched_getaffinity(0)=={29},"original CPU29");audit()
    if a==["control"]:return control()|{"registration":sha(REG)}
    if a==["smoke"]:return smoke()
    if len(a)==2 and a[0]=="closed" and a[1] in ("safe","complete"):return closed(a[1])
    need(len(a)==3 and a[0] in ("run","closed") and a[1] in ("legacy","ctfe","previous") and a[2] in m.VERSIONS,"control|smoke|run|closed scope mode|closed safe|complete")
    return run(*a[1:]) if a[0]=="run" else check_one(*a[1:])
if __name__=="__main__":print(json.dumps(main(sys.argv[1:]),sort_keys=True))
