"""Characterize the old two format-11 compilers on disposable copies of real A state."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace

D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location("prior_schema_matrix",D/"migration.py")
x=importlib.util.module_from_spec(sp);sp.loader.exec_module(x)
q,m=x.q,x.m
need,read,sha=x.need,x.read,x.sha
REG=D/"previous-registration.json"
TAGS=("retired11","CTFE")
GROUP=q.b.BANK/"trait-rosters-observe-old11-001"
RESULT=D/"cross-previous"
LIMIT=512*1024
def audits():
    j=read(REG);x.audit()
    need(j["matrix"]==sha(x.REG) and j["program"]==sha(Path(__file__)) and j["fixture"]==sha(m.K/"fixture.rs"),"sealed original collision characterization")
def subjects(deep):
    old=q.v.bind("T1")["accepted"]("T1",deep)
    inv=read(Path(old["sdk"]).parent/"sdk.json")
    old=x.normalized(old|{"launcher_sha256":inv["bin/rustc"][0]})
    ext=x.load("pre_fix_ctfe_material",D/"ctfe-subject.py")
    other=x.normalized(ext.subject(deep))
    need(old["commit"]==q.s.REVISIONS["T1"] and other["commit"]=="df2c077a113a709ab379c8ec34e62c94c7513325" and
         old["header_format"]==other["header_format"]==11 and old["driver_sha256"]!=other["driver_sha256"],"original two actual format-11 compilers")
    return dict(retired11=old,CTFE=other)
def bounded_command(args,more):
    args=list(args)
    if more and "--crate-name" in args:args.append("-Zincremental-info")
    with tempfile.TemporaryFile() as stdout,tempfile.TemporaryFile() as stderr:
        pr=subprocess.Popen(args,cwd="/tmp/w",stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
        began=time.monotonic();reason=None
        try:
            while pr.poll() is None:
                if time.monotonic()-began>40:reason="40s command limit";break
                if max(os.fstat(f.fileno()).st_size for f in (stdout,stderr))>LIMIT:reason="512KiB per-stream limit";break
                try:pr.wait(0.01)
                except subprocess.TimeoutExpired:pass
        finally:
            if pr.poll() is None:os.killpg(pr.pid,signal.SIGKILL);pr.wait()
        result={"argv":list(map(str,args)),"exit":pr.returncode,"terminated_by_guard":reason}
        for key,f in (("stdout",stdout),("stderr",stderr)):
            size=f.tell();f.seek(0);digest=hashlib.file_digest(f,"sha256").hexdigest();f.seek(0);raw=f.read(LIMIT)
            result[key]=raw.decode(errors="replace")
            if result[key].encode()!=raw:result[key+"_retained_base64"]=base64.b64encode(raw).decode()
            result[key+"_raw"]={"sha256":digest,"bytes":size,"all_retained":len(raw)==size}
        return result
def worker():
    want=sys.argv[2]=="info"
    if want:sys.argv[2]="ordinary"
    original=runpy.run_path(str(m.K/"probe_worker.py"))
    original["main"]=q.overlay(original["main"],cmd=lambda argv:bounded_command(argv,want))
    def dispatch(path):
        need(Path(path)==m.K/"probe_worker.py","same native compiler driver");return original
    q.overlay(x.worker,runpy=SimpleNamespace(run_path=dispatch))()
def step(mode,role,arm,edit,state,seed=b""):
    opt=m.VERSIONS["forced"] if mode=="forced" else None
    def go(argv,*,env,**kw):
        need("RUSTC_FORCE_RUSTC_VERSION" not in env and "RUSTC_FORCE_INCR_COMP_ARTIFACT_HEADER" not in env,"sterile version-variable source")
        if opt:env=env|{"RUSTC_FORCE_RUSTC_VERSION":opt,"RUSTC_FORCE_INCR_COMP_ARTIFACT_HEADER":opt}
        return subprocess.run(argv,env=env,**kw)
    f=m.M["step"];rv=q.overlay(f,WORKER=Path(__file__).resolve(),subprocess=SimpleNamespace(run=go))(role,arm,edit,state,seed)
    if rv["worker_exit"]==0:
        need(rv["forced_rustc_version"]==rv["perf_artifact_env"]==opt and rv["seed_sha256"]==(m.M["raw_sha"](seed) if seed else "-"),"original input and real forced state")
    return rv
def classification(row):
    if row.get("worker_exit")!=0:return "worker error"
    r=row["compile"]
    if r.get("terminated_by_guard") or not all(r[k+"_raw"]["all_retained"] for k in ("stdout","stderr")):return "guarded/partial"
    if r["exit"]<0:return "compiler signal "+str(-r["exit"])
    if "internal compiler error" in r["stderr"] or "panicked at" in r["stderr"] or "Invalid DepKind" in r["stderr"]:return "compiler error with ICE/panic marker"
    if r["exit"]!=0:return "compiler rejected input"
    if row.get("run",{}).get("exit")!=0:return "compiled, native execution failed"
    return "compiled and ran"
def verdict(rows):
    def ok(row, message):
        if row.get("worker_exit")!=0 or row["compile"]["exit"]!=1:return False
        for line in row["compile"]["stderr"].splitlines():
            try:diag=json.loads(line)
            except ValueError:continue
            if isinstance(diag,dict) and diag.get("$message_type")=="diagnostic" and diag.get("level")=="error" and diag.get("message")==message:return True
        return False
    a=ok(rows["assert_not_loaded"],"we asserted that the incremental cache should not be loaded, but it was loaded")
    b=ok(rows["assert_loaded"],"we asserted that an existing incremental cache directory should be successfully loaded, but it was not")
    if a and not b:return "rustc explicitly reported loaded"
    if b and not a:return "rustc explicitly reported not-loaded"
    return "contradictory independent assertions" if a and b else "no decisive cache-state report"
def matches(r,ref):
    if r.get("worker_exit")!=0 or classification(r)=="guarded/partial":return False
    return r["compile"]["exit"]==ref["compile"]["exit"] and r.get("run",{}).get("exit")==ref.get("run",{}).get("exit") and r.get("run",{}).get("stdout")==ref.get("run",{}).get("stdout") and r["diagnostics"]==ref["diagnostics"]
def analyze(out,mode,arms):
    h=read(out/"intake.json");need(h["mode"]==mode and h["arms"]==arms and h["registration"]==sha(REG) and len(h["locks"])==4 and h["performance_rows"]==0,"original four-lock intake")
    expected=m.VERSIONS[mode];seeds={k:read(out/(k+"-seed.json"))for k in TAGS};clean={k:read(out/(k+"-empty.json"))for k in TAGS}
    roster=read(D/"rosters.json")["private-20261101"];paths=[];representatives={}
    for tag,arm in arms.items():
        seed=seeds[tag];em=clean[tag];need(m.M["good"](seed,"11\n") and all(seed[k]==arm[k]for k in ("driver_sha256","launcher_sha256","llvm_sha256")),"true native A")
        headers=seed["seed_headers"];need({"dep-graph.bin","work-products.bin","query-cache.bin"}<={Path(n).name for n in headers} and {(v["format"],v["version"])for v in headers.values()}=={(11,expected)},"complete format and real version")
        paths.append({Path(n).parts[0]for n in headers});need(len(paths[-1])==1,"one crate cache")
        need(m.M["good"](em["B"],"17\n") and m.M["good"](em["assert_not_loaded"],"17\n") and verdict(em)=="rustc explicitly reported not-loaded" and em["E"]["compile"]["exit"]==1 and any(d.get("code") and d["code"].get("code")=="E0277" and any(p.get("is_primary") and p.get("file_name")=="probe.rs" for p in d["spans"]) for d in em["E"]["diagnostics"]),"genuine empty history and type error")
        others=next(t for t in TAGS if t!=tag);a,b=roster[tag],roster[others];hist=seed["graph_census"]["by_number"]
        representatives[tag]={str(i):{"count":n,"writer_kind":a[i],"other_reader_kind":b[i] if i<len(b) else None,**seed["graph_census"]["first"][str(i)]} for i,n in enumerate(hist) if n and (i>=len(b) or a[i]!=b[i])}
    answers={}
    for a in TAGS:
        for b in TAGS:
            name=a+"-to-"+b;v=read(out/(name+".json"));state=verdict(v)
            for key,row in v.items():
                if row.get("worker_exit")==0:
                    need(row["seed_sha256"]==seeds[a]["seed_gz_sha256"] and row["prior_headers"]==seeds[a]["seed_headers"] and all(row[k]==seeds[b][k]for k in ("selected_driver_identity","selected_llvm_identity")),"unaltered cache and real loader")
                    need(("-Zincremental-info" in row["compile"]["argv"])==(key=="info_B"),"separate optional disposition log")
            if a==b:
                need(state=="rustc explicitly reported loaded" and m.M["good"](v["assert_loaded"],"17\n") and m.M["good"](v["no_edit"],"11\n") and m.M["good"](v["positive"],"17\n") and matches(v["negative"],clean[b]["E"]),"own history must pass")
            answers[name]={"assertion":state,"outcomes":{k:{"classification":classification(r),"compiler_exit":r.get("compile",{}).get("exit"),"native_stdout":r.get("run",{}).get("stdout")}for k,r in v.items()},
                           "unedited_matches_expected":m.M["good"](v["no_edit"],"11\n"),"edited_matches_fresh":matches(v["positive"],clean[b]["B"]),"invalid_matches_fresh_E0277":matches(v["negative"],clean[b]["E"])}
    return {"registration":sha(REG),"mode":mode,"subjects":arms,"performance_rows":0,"same_cache_directory":paths[0]==paths[1],"same_native_header_hex":(b"RSIC\x0b\x00"+bytes([len(expected)])+expected.encode()).hex(),"actual_emitted_conflicting_kinds":representatives,"observations":answers,"files":{p.name:sha(p)for p in sorted(out.glob("*.json"))if p.name!="complete.json"}}
def run(mode):
    audits();need(os.environ.get("OHM_OBSERVE_PRIOR_11")==sha(REG),"explicit old-format disposition registration")
    need(os.sched_getaffinity(0)=={29} and mode in m.VERSIONS,"physical coordinator")
    host=q.v.F.q.check_host(True);q.b.open_bank();q.v.budget_live()
    out=RESULT/(mode+"-001");sd=GROUP/mode;need(not out.exists() and not sd.exists(),"fresh old-format observation")
    with q.b.leases.PRE.four(host)as locks:
        need(len(locks)==4 and q.b.leases.available()["ram"]>=60*q.b.G and shutil.disk_usage(q.b.BANK).free>2*q.b.G+256*m.Mi,"original host floors")
        arms=subjects(True);GROUP.mkdir(mode=0o700,exist_ok=True)
        need(GROUP.resolve()==GROUP and (GROUP.stat().st_mode&0o777)==0o700,"private root");sd.mkdir(mode=0o700);out.mkdir(mode=0o700)
        m.write(out/"intake.json",{"mode":mode,"registration":sha(REG),"arms":arms,"locks":list(map(str,locks)),"performance_rows":0})
        for k,arm in arms.items():
            init=step(mode,k,arm,"A","ordinary");need(init.get("worker_exit")==0,"clean seed worker")
            raw=base64.b64decode(init.pop("seed_gz"),validate=True);need(len(raw)<=12*m.Mi and m.M["raw_sha"](raw)==init["seed_gz_sha256"],"unmodified compressed seed")
            with (sd/(k+".gz")).open("xb")as f:f.write(raw)
            m.write(out/(k+"-seed.json"),init)
            m.write(out/(k+"-empty.json"),{n:step(mode,k,arm,e,c)for n,e,c in (("B","B","ordinary"),("E","E","ordinary"),("assert_loaded","B","loaded"),("assert_not_loaded","B","not-loaded"))})
        for a in TAGS:
            for b in TAGS:
                q.v.budget_live();raw=(sd/(a+".gz")).read_bytes();need(m.M["raw_sha"](raw)==read(out/(a+"-seed.json"))["seed_gz_sha256"],"authentic state for each compile")
                rows={k:step(mode,b,arms[b],e,c,raw)for k,e,c in [*m.STATES,("info_B","B","info")]};m.write(out/(a+"-to-"+b+".json"),rows)
        doc=analyze(out,mode,arms);m.write(out/"complete.json",doc);return doc
def main(args):
    need(__debug__ and os.sched_getaffinity(0)=={29},"CPU29")
    audits()
    if args==["plan"]:return {"registration":sha(REG),"subjects":list(TAGS),"modes":m.VERSIONS,"timings":0,"previous_tree_only":True}
    need(len(args)==2 and args[0] in ("run","closed") and args[1] in m.VERSIONS,"plan | run/closed unforced|forced")
    op,mode=args
    if op=="run":return run(mode)
    out=RESULT/(mode+"-001");doc=analyze(out,mode,subjects(True));need(doc==read(out/"complete.json"),"real completed characterization");return doc
if __name__=="__main__":
    if sys.argv[1:2] in (["A"],["B"],["E"]):worker()
    else:print(json.dumps(main(sys.argv[1:]),sort_keys=True))
