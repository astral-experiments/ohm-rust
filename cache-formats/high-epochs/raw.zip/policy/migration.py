"""Repeat the original clean/same-install/swapped-install experiment with the actual new SDKs."""
import contextlib
import importlib.util
import inspect
import io
import itertools
import json
import os
from pathlib import Path
import runpy
import sys
from types import FunctionType, SimpleNamespace

D=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
q=load("high_header_native",D/"qualify.py")
R=q.R
old=load("high_header_legacy_custodian",q.v.D/"custody-002/run.py")
m=old.m;s=q.s
REG=D/"matrix-registration.json"
FORMATS={"base8":8,"old9":9,"old10":10,"retired11":11,"retired12":12,"CTFE":11,"T1":35256,"T3":40683,"T4":40683}
LABELS={"legacy":("base8","old9","old10","retired11","retired12","T1","T3","T4"),"ctfe":("CTFE","T1","T3","T4")}
HIGH={"T1","T3","T4"}
need,sha,read=s.require,q.v.sha,s.read
def compatible(a,b):
    return a==b or {a,b}=={"T3","T4"}
def pairs(scope):
    return [(a,b) for a,b in itertools.product(LABELS[scope],repeat=2) if a==b or (a in HIGH or b in HIGH)]
def audit():
    j=read(REG)
    for n,h in j["files"].items():need(sha(D/n)==h,"matrix data or reader changed "+n)
    need(j["native_registration"]==sha(q.REG) and j["actual_previous_custody"]==sha(old.REG) and j["fixture"]==sha(m.K/"fixture.rs") and j["previous_worker"]==sha(m.K/"probe_worker.py") and j["previous_migration"]==sha(q.v.D/"migrate.py"),"unchanged actual matrix sources")
    c=read(s.CTFE/"live-header-census.json")
    need(sha(s.CTFE/"live-header-census.json")==j["current_coverage"] and (c["live_named_branches"],c["live_open_prs"],c["distinct_active_head_commits"])==(373,182,372) and set(FORMATS[k] for k in HIGH).isdisjoint(c["active_header_objects"].values()),"verified current active generations")
    rr=read(D/"rosters.json")["private-20261101"]; oldro=read(m.K/"rosters.json")["revised"];ct=read(s.CTFE/"ctfe-vs-t1-depkinds.json")
    need(rr["T1"]==rr["old9"]==rr["retired11"]==ct["T1"]==oldro["T1"] and rr["base8"]==oldro["base"] and rr["T3"]==rr["T4"]==rr["old10"]==rr["retired12"]==oldro["T3"] and rr["CTFE"]==ct["ctfe"],"all genuine emitter query-name indexes")
    return j
def normalized(row):
    return {k:row[k]for k in ("commit","tree","driver_relative","driver_sha256","header_format","raw_packet_sha256","sdk","launcher_sha256","llvm_sha256")}|{"cohort":"private-20261101"}
def future(deep):
    result={}
    for k,row in q.subjects(deep).items():
        where=Path(row["sdk"]);inv=read(where.parent/"sdk.json");sr=q.ROWS[k]
        need((row["commit"],row["tree"],row["header_format"])==(sr["new_commit"],sr["tree"],FORMATS[k]) and
             (len(inv),inv[row["driver_relative"]][0],inv[q.b.DR][0])==(73,row["driver_sha256"],q.b.LLVM),"actual qualified compiler")
        result[k]=normalized(row|{"launcher_sha256":inv["bin/rustc"][0]})
    need(len({r["driver_sha256"] for r in result.values()})==3,"different native T1, T3, T4 drivers")
    return result
def subjects(scope,deep):
    audit()
    result=future(deep)
    if scope=="legacy":
        prior=old.subjects(q.v,deep)
        for alias,former in {"base8":"base8","old9":"old9","old10":"old10","retired11":"new11","retired12":"new12"}.items():
            result[alias]=normalized(prior[former])
    else:
        need(scope=="ctfe","select legacy or ctfe")
        # The procurement-specific adapter is a separate registration: legacy QA does not depend on CI storage.
        ext=load("private_format_authentic_ctfe_source",D/"ctfe-subject.py")
        result["CTFE"]=normalized(ext.subject(deep))
        need(result["CTFE"]["commit"]=="df2c077a113a709ab379c8ec34e62c94c7513325" and result["CTFE"]["tree"]=="59ec1b8a5d8f7c446534fa8725281fd215f02164" and result["CTFE"]["driver_sha256"]=="481e8cf9c46278874b40a129f44a3825d64bc050de5f0b3ff34c0986cb4d177c","the CI's actual CTFE artifact")
    need(set(result)==set(LABELS[scope]) and all(a["header_format"]==FORMATS[n] for n,a in result.items()),"authentic source/version mapping")
    return {k:result[k]for k in LABELS[scope]}
def worker():
    original=runpy.run_path(str(m.K/"probe_worker.py"));f=original["main"]
    class Files:
        def __truediv__(self,n):
            need(n in ("fixture.rs","rosters.json","census.py"),"expected worker inputs")
            return D/n if n=="rosters.json" else m.K/n
    def census(path):
        need(path==m.K/"census.py","exact graph decoder")
        return {"count":m.counter(os.environ.get("RUSTC_FORCE_RUSTC_VERSION",m.VERSIONS["unforced"]))}
    body=q.overlay(f,D=Files(),runpy=SimpleNamespace(run_path=census));buf=io.StringIO()
    with contextlib.redirect_stdout(buf):body()
    row=json.loads(buf.getvalue());row.update(forced_rustc_version=os.environ.get("RUSTC_FORCE_RUSTC_VERSION"),perf_artifact_env=os.environ.get("RUSTC_FORCE_INCR_COMP_ARTIFACT_HEADER"))
    print(json.dumps(row,sort_keys=True))
def bind(scope):
    need(scope in LABELS,"known, independent matrix");base=D/("cross-"+scope)
    tags={n:n for n in LABELS[scope]};formats={n:FORMATS[n]for n in tags}
    api=SimpleNamespace(**vars(q));api.REG=REG;api.audit=audit;api.F=q.v.F;api.BANK=q.b.BANK;api.budget_live=q.v.budget_live
    ctx=dict(vars(m),__file__=str(Path(__file__).resolve()),D=base,TAGS=tags,FORMATS=formats,compatible=compatible,plan=lambda:pairs(scope),
             issuer=lambda:api,subjects=lambda _,deep:subjects(scope,deep),scope=scope)
    ctx["step"]=q.rebind(m.step,ctx)
    code=inspect.getsource(m.check)
    for before,after in [('if a==b else','if compatible(a,b) else'),('"genuine_empty_controls":5','"genuine_empty_controls":len(arms)')]:
        need(code.count(before)==(2 if before.startswith("if ") else 1),"original saved decision shape");code=code.replace(before,after)
    exec(compile(code,str(D/"migration.py"),"exec"),ctx);original=ctx["check"]
    def check(mode,arms):
        data=original(mode,arms);out=base/("migration-"+mode+"-001");counts={}
        for a,b in pairs(scope):
            rs=read(out/(a+"-to-"+b+".json"));key="assert_not_loaded" if compatible(a,b) else "assert_loaded"
            need(rs[key]["compile"]["exit"]==1 and "run" not in rs[key],"explicit complementary cache state rejection")
        inv=read(D/"rosters.json")["private-20261101"]
        for tag in tags:
            seed=read(out/(tag+"-seed.json"));c=seed["graph_census"];counts[tag]=c["nodes"]
            need(seed["rustc"]["exit"]==0 and "release: 1.99.0-dev" in seed["rustc"]["stdout"] and len(c["by_number"])==len(inv[tag]) and sum(c["by_number"])==c["nodes"]>0,"actual emitted query-roster cardinality")
        data["compatible_loads"]=data.pop("own_cache_loaded")
        need(data["compatible_loads"]==sum(compatible(a,b) for a,b in pairs(scope)) and data["different_format_rejected"]==sum(not compatible(a,b)for a,b in pairs(scope)),"complete distribution")
        return data|{"own_loads":len(tags),"T3_T4_native_reciprocal_loads":2,"observed_graph_node_counts":counts,"scope":scope}
    ctx["check"]=check
    code=inspect.getsource(m.run)
    for before,after in [('os.environ.get("OHM_PR296_HEADER_QA")','os.environ.get("OHM_PRIVATE_HEADER_MATRIX")'),('seedout=q.GROUP/("cache-seeds-"+mode+"-001")','seedout=q.GROUP/("cache-seeds-"+scope+"-"+mode+"-001")')]:
        need(code.count(before)==1,"one scoped frontier");code=code.replace(before,after)
    exec(compile(code,str(D/"migration.py"),"exec"),ctx);return ctx
def main(a):
    need(__debug__ and os.sched_getaffinity(0)=={29},"frozen coordinator CPU")
    if a==["plan"]:
        audit()
        for scope in LABELS:bind(scope)
        return {"registration":sha(REG),"native_rows":0,"modes":m.VERSIONS,"scopes":{k:{"roles":list(v),"pairs":len(pairs(k)),"loads":sum(compatible(a,b)for a,b in pairs(k)),"rejects":sum(not compatible(a,b) for a,b in pairs(k))}for k,v in LABELS.items()}}
    need(len(a) in (2,3) and a[0] in ("subjects","run","closed") and a[1] in LABELS,"plan | subjects legacy|ctfe | run/closed legacy|ctfe unforced|forced")
    op,scope=a[:2]
    if op=="subjects":need(len(a)==2,"subject selector");return subjects(scope,True)
    need(len(a)==3 and a[2] in m.VERSIONS,"ordinary or forced");ctx=bind(scope);mode=a[2]
    if op=="run":return ctx["run"](mode)
    result=ctx["check"](mode,subjects(scope,True));need(result==read(D/("cross-"+scope)/("migration-"+mode+"-001")/"accepted.json"),"sealed original observations")
    return result
if __name__=="__main__":
    if sys.argv[1:2] in (["A"],["B"],["E"]):worker()
    else:print(json.dumps(main(sys.argv[1:]),sort_keys=True))
