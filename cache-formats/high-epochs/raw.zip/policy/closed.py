"""One verified handback for the three fresh SDKs, four real matrices and optional legacy observations."""
import importlib.util
import json
import os
from pathlib import Path
import sys
D=Path(__file__).resolve().parent
def load(name,filename):
    s=importlib.util.spec_from_file_location(name,D/filename);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load("genuine_v11_disposition","prefix.py");x=p.x;q=p.q
ext=load("authentic_ctfe_material_record","ctfe-subject.py")
read,sha,need=x.read,x.sha,x.need
REG=D/"closed-registration.json"
def audit():
    j=read(REG)
    for n,h in j["files"].items():need(sha(D/n)==h,"sealed final accessor dependency "+n)
    need(j["ctfe_issuer"]==ext.ISS and j["ctfe_issuer_registration"]==ext.REG and j["ctfe_return"]==ext.RAW,"actual CTFE source principal")
    p.audits();ext.original()
    return j
def agreed_dirs(out,roles):
    dirs=[]
    for k in roles:
        names=read(out/(k+"-seed.json"))["seed_headers"];s={Path(n).parts[0] for n in names}
        need(len(s)==1,"one real cache directory per install");dirs.extend(s)
    need(len(set(dirs))==1,"identical canonical compiler-selected crate cache directory")
    return dirs[0]
def checked(scope,mode,arms):
    out=D/("cross-"+scope)/("migration-"+mode+"-001")
    h=x.bind(scope)["check"](mode,arms)
    need(h==read(out/"accepted.json") and h["T3_T4_native_reciprocal_loads"]==2 and h["states"]["T3-to-T4"]==h["states"]["T4-to-T3"]=="loaded","all exact native return checks")
    same_dir=agreed_dirs(out,arms)
    return {"sha256":sha(out/"accepted.json"),"own":h["own_loads"],"compatible":h["compatible_loads"],"rejected":h["different_format_rejected"],"cross_T3_T4":2,"same_cache_subdirectory":same_dir}
def main(args):
    need(__debug__ and os.sched_getaffinity(0)=={29},"original CPU29")
    audit()
    if args==["audit"]:return {"registration_sha256":sha(REG),"native_registration":sha(q.REG),"matrix":sha(x.REG),"previous":sha(p.REG),"source":sha(D/"source.json"),"performance_rows":0}
    need(args in (["safe"],["complete"]),"audit | safe | complete")
    old=x.subjects("legacy",True);actual_ctfe=ext.subject(True);foreign={"CTFE":x.normalized(actual_ctfe),**{t:old[t]for t in ("T1","T3","T4")}}
    matrices={scope:{mode:checked(scope,mode,arms)for mode in ("unforced","forced")} for scope,arms in (("legacy",old),("ctfe",foreign))}
    high={k:old[k]for k in ("T1","T3","T4")}
    need({(k,m["unforced"]["own"],m["unforced"]["compatible"],m["unforced"]["rejected"]) for k,m in matrices.items()}=={("ctfe",4,6,10),("legacy",8,10,34)},"true crossed cases")
    for m in matrices.values():need(all(m["unforced"][k]==m["forced"][k] for k in ("compatible","rejected","own","cross_T3_T4")),"both real modes")
    result={"registration_sha256":sha(REG),"subjects":high,"matrices":matrices,"ctfe":{"source":actual_ctfe["commit"],"tree":actual_ctfe["tree"],"driver_sha256":actual_ctfe["driver_sha256"],"positive_81":ext.RAW,"member_manifest":ext.MAN,"format":11},"performance_rows":0}
    if args==["complete"]:
        arms={"retired11":old["retired11"],"CTFE":foreign["CTFE"]};before={}
        for mode in ("unforced","forced"):
            out=p.RESULT/(mode+"-001");z=p.analyze(out,mode,arms)
            need(z==read(out/"complete.json"),"complete preserved pre-fix return")
            before[mode]={"sha256":sha(out/"complete.json"),"same_cache_subdirectory":z["same_cache_directory"],"same_native_header_hex":z["same_native_header_hex"],
                          "directions":{a:z["observations"][a] for a in ("retired11-to-CTFE","CTFE-to-retired11")}}
        result["previous"]=before
    return result
if __name__=="__main__":print(json.dumps(main(sys.argv[1:]),sort_keys=True))
