from pathlib import Path
import cargo_messages as m
sdk=Path('/tmp/uv-workflow-search/sdk')
def verify_roles(raw,log):
    entries,details=m.decode(raw);children=m.rustc_children(log,str(sdk/'bin/rustc'));m.correlate(entries,children);m.cli_roles(entries,children)
    dirty=[x for x in entries if x['reason']=='compiler-artifact' and not x['fresh']]
    assert len(dirty)==len(children)==2
    out={}
    for ch in children:
        a=ch['argv'];test='--test'in a
        row,=[x for x in dirty if x['profile']['test']==test]
        assert row['features']==['default','self-update'] and row['target']['name']=='uv_cli' and set(row['target']['kind'])=={'lib'}
        assert a.count('crates/uv-cli/src/lib.rs')==1 and '--emit=dep-info,metadata'in a and len([v for v in a if v.startswith('incremental=')])==1
        assert [a[i+1]for i,v in enumerate(a)if v=='--cfg' and a[i+1].startswith('feature=')]==['feature="default"','feature="self-update"']
        assert (('--crate-type' in a and a[a.index('--crate-type')+1]=='lib')!=test) and ('--test' in a)==test
        ext=[x.split('=',1)[0]for i,v in enumerate(a)if v=='--extern' for x in [a[i+1]]];assert ('insta' in ext)==test
        output=Path(a[a.index('--out-dir')+1]);assert any(Path(v).parent==output for v in row['filenames'])
        out['test'if test else'lib']=dict(key=output.parent.name,argv=a,filenames=row['filenames'],features=row['features'])
    assert out['lib']['key']!=out['test']['key'];return out
