"""Offline protocol calibration on real historical all-target rustc argument vectors."""
from pathlib import Path
from unittest.mock import patch
import copy,json,re,shlex,struct,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run as r

def reject(fn,*a):
    try:fn(*a)
    except (AssertionError,ValueError):return
    raise AssertionError("negative control accepted")

def test():
    src=r.lit.NATIVE/'roles-0-stock18';old={k:r.read(src/(k+'.json'))for k in ('lib','test')}
    c=r.read(src/'comparison.json');assert c['matched_products']==c['ordinary_products']==c['replay_products'] if isinstance(c['ordinary_products'],dict) and len(c['ordinary_products'])==4 else sorted(c['matched_products'])==sorted(k for v in old.values()for k in v['artifacts'])
    def emit(fea,delete=False):
        rows=[];lines=[]
        for k in old:
            if delete and k=='test':continue
            a=old[k]['argv'][:];a[0]=str(r.sdk/'bin/rustc')
            if fea:a+=['--cfg','feature="self-update"']
            rows.append(dict(reason='compiler-artifact',target={'name':'uv_cli','kind':['lib']},features=['default','self-update']if fea else ['default'],profile={'test':k=='test'},fresh=False,package_id='path+file:///fixture/uv-cli#uv-cli@0.0.70',filenames=[str(Path(a[a.index('--out-dir')+1])/Path(v).name)for v in old[k]['artifacts']if v.endswith('.rmeta')]))
            lines.append('     Running `CARGO_PKG_NAME=uv-cli '+shlex.join(a)+'`')
        rows.append({'reason':'build-finished','success':True})
        return ('\n'.join(json.dumps(x)for x in rows)+'\n').encode(),('\n'.join(lines)+'\n').encode()
    assert set(r.verify_roles(*emit(True)))=={'lib','test'};reject(r.verify_roles,*emit(False));reject(r.verify_roles,*emit(True,True))
    u={k:dict(key=k,features=['default','self-update'],invoked_ns=100)for k in old};b={k:dict(v,invoked_ns=102)for k,v in u.items()}
    r.p.transition(u,b,True);r.p.transition(b,b,False);reject(r.p.transition,u,dict(b,test=u['test']),True)
    def graph(alter):
        body=b''.join(struct.pack('<HI',k+(1<<11),i)+bytes([i])*16+bytes([int(alter) if i else 1])*16 for i,k in enumerate([134,137]));return b'RSIC\x04\0\x01R'+b'\0'*8+body+struct.pack('<3Q',2,2,0)+b'rust-end-file'
    a=r.p.query_values(graph(False));assert a['mir_borrowck']!=r.p.query_values(graph(True))['mir_borrowck'];reject(r.p.query_values,graph(True)[:-3])
    cfg=r.read(r.D/'discovery.json');seq=r.order(cfg);data=[dict(order=s,ratio=2.1)for s in seq]
    assert r.gate(data) and r.score([data,data])['qualified'] and not r.score([data,[dict(x,ratio=1.99)for x in data]])['qualified']
    assert r.subjects()['arms'].keys()==set(r.roles)
    return dict(registration=r.audit(),historical_default_cfg_rejected=True,real_argv_template_two_roles=True,missing_unit_rejected=True,unchanged_test_stamp_rejected=True,query_difference_detected=True,cold_or_benchmark_runs=0)
if __name__=='__main__':print(json.dumps(test(),indent=2))
