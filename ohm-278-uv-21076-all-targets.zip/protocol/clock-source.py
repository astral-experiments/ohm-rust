def measure(run, env, target, cmd, label, plain):
    if not plain:
        return screen.measure(run,env,target,cmd,label)
    start = time.perf_counter_ns()
    p = subprocess.run(cmd,cwd=screen.SRC,env=env,capture_output=True)
    elapsed = time.perf_counter_ns() - start
    (run / (label + ".stdout")).write_bytes(p.stdout)
    (run / (label + ".stderr")).write_bytes(p.stderr)
    if p.returncode:
        raise RuntimeError(p.stderr.decode(errors="replace")[-1200:])
    units = [name.replace("-","_") for name in
             re.findall(r"^\s*(?:Checking|Compiling) ([\w-]+) v",p.stderr.decode(),re.M)]
    row = {"cmd":cmd,"wall_s":elapsed / 1e9,"dirty_units":units,"unit_source":"ordinary Cargo progress"}
    (run / (label + ".json")).write_text(json.dumps(row,indent=2))
    return row

def order(arms, n, seed):
    block = list(itertools.permutations(arms))
    rng = random.Random(seed)
    result = []
    while len(result) < n:
        rng.shuffle(block)
        result.extend(block)
    return result[:n]
