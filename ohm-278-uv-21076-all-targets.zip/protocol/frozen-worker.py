def worker(out, case):
    lane, src = screen.LANE, screen.SRC
    sdk = lane / "sdk"
    assert os.statvfs(sdk).f_flag & os.ST_RDONLY and os.statvfs(screen.BANK).f_flag & os.ST_RDONLY
    assert os.statvfs(screen.TASK).f_flag & os.ST_RDONLY
    assert subprocess.check_output(["stat", "-f", "-c", "%T", lane], text=True).strip() == "tmpfs"
    assert os.sched_getaffinity(0) == set(range(16))
    target, cargo_home = lane / "target", lane / "cargo"
    (lane / "home").mkdir()
    env = dict(PATH=str(sdk / "bin") + ":/usr/bin:/bin", RUSTC=str(sdk / "bin/rustc"),
               RUSTDOC=str(sdk / "bin/rustdoc"), HOME=str(lane / "home"), CARGO_HOME=str(cargo_home),
               CARGO_TARGET_DIR=str(target), CARGO_NET_OFFLINE="true", CARGO_TERM_COLOR="never",
               GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null", GIT_NO_LAZY_FETCH="1",
               GIT_ALLOW_PROTOCOL="file", LC_ALL="C.UTF-8")
    os.environ.update({k:v for k,v in env.items() if k.startswith("GIT_") or k == "HOME"})
    a, d, args = screen.CASES[case]
    jobs = "-j4" if case == "20220" else "-j8"
    plain = os.environ.get("UV_PAIR_PLAIN") == "1"
    cmd = [str(sdk / "bin/cargo"), *args, "--locked", "--offline", jobs]
    if not plain:
        cmd.extend(["--timings","--message-format=json-render-diagnostics"])
    subprocess.run(["git", "-c", "core.autocrlf=false", "clone", "--no-checkout",
                    (screen.BANK / "uv.git").resolve().as_uri(), src], check=True, env=env)
    screen.git("checkout", "-f", "--detach", a)
    delta = screen.git("diff", "--binary", "--full-index", a, d)
    assert delta
    (out / "edit.patch").write_bytes(delta)
    for name, command in (("rustc", [env["RUSTC"], "-vV"]), ("cargo", [cmd[0], "-Vv"])):
        (out / (name + ".txt")).write_bytes(subprocess.check_output(command, env=env))
    linked = subprocess.check_output(["ldd",env["RUSTC"]], env=env, text=True)
    loaded = {name:{"path":path, "sha256":sha(Path(path))}
              for name,path in re.findall(r"^\s*((?:librustc_driver|libLLVM)[^ ]+) => (\S+)",linked,re.M)}
    assert any(k.startswith("librustc_driver") for k in loaded) and any(k.startswith("libLLVM") for k in loaded)
    (out / "identity.json").write_text(json.dumps({"launcher":sha(Path(env["RUSTC"])),
        "cargo":sha(Path(cmd[0])),"linked":loaded,
        "sysroot":subprocess.check_output([env["RUSTC"],"--print","sysroot"],env=env,text=True).strip()},indent=2))
    logs = lane / "records"
    logs.mkdir()
    setup = logs / "setup"
    setup.mkdir()
    measure(setup, env, target, cmd, "warm",plain)
    assert not measure(setup, env, target, cmd, "settled",plain)["dirty_units"]
    publish(setup,out)
    target.rename(lane / "a-target")
    src.rename(lane / "a-source")
    (lane / "home").rename(lane / "a-home")
    cache = lane / "a-cargo"
    cache.mkdir()
    for child in cargo_home.iterdir():
        if child.name != "registry":
            copy(child, cache / child.name)
    tmp = Path("/tmp")
    system_cache = lane / "a-system-tmp"
    system_cache.mkdir()
    for child in tmp.iterdir():
        if child != lane:
            copy(child,system_cache / child.name)
    (out / "private-tmp.json").write_text(json.dumps(
        sorted(str(path.relative_to(system_cache)) for path in system_cache.rglob("*"))))
    send({"state":"ready","patch":hashlib.sha256(delta).hexdigest()})
    for request in sys.stdin:
        trial = request.strip()
        if trial == "stop":
            break
        if trial == "verify":
            assert case == "20220"
            check = logs / "clean-verification"
            check.mkdir()
            before = screen.sidecars(target)
            shutil.rmtree(target)
            measure(check,env,target,cmd,"clean-D",plain)
            after = screen.sidecars(target)
            names = {"lib-uv_errors.public-api-hash","lib-uv_warnings.public-api-hash",
                     "lib-uv_install_wheel.public-api-hash"}
            selected = {k:v for k,v in before.items() if Path(k).name in names}
            assert {Path(k).name for k in selected} == names
            assert all(after.get(k) == value for k,value in selected.items())
            verify = subprocess.run([cmd[0],"test","--locked","--offline",jobs,"-p","uv-errors",
                "--lib","tests::formats_debug_error_chain","--","--exact"],cwd=src,env=env,capture_output=True)
            (check / "behavior.log").write_bytes(verify.stdout + verify.stderr)
            assert verify.returncode == 0 and b"1 passed; 0 failed" in verify.stdout
            (check / "warm-and-clean.json").write_text(json.dumps(selected,indent=2))
            publish(check,out)
            send({"state":"verified","hashes":len(selected),"witness":"tests::formats_debug_error_chain"})
            continue
        assert trial.isdecimal()
        for child in tmp.iterdir():
            if child == lane:
                continue
            if child.is_dir() and not child.is_symlink():
                shutil.rmtree(child)
            else:
                child.unlink()
        for child in system_cache.iterdir():
            copy(child,tmp / child.name)
        run = logs / ("pair-" + trial)
        run.mkdir()
        for path, frozen in ((src, lane / "a-source"), (target, lane / "a-target"),
                             (lane / "home",lane / "a-home")):
            if path.exists():
                shutil.rmtree(path)
            copy(frozen, path)
        for child in cargo_home.iterdir():
            if child.name == "registry":
                continue
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
        for child in cache.iterdir():
            copy(child, cargo_home / child.name)
        settled = measure(run, env, target, cmd, "settled-A",plain)
        assert not settled["dirty_units"] and screen.git("rev-parse","HEAD").decode().strip() == a
        assert not screen.git("status", "--porcelain")
        if case == "20220":
            before = screen.sidecars(target)
        capture = os.environ.get("UV_PAIR_RDR") == "1" and trial == "1"
        if capture:
            import rdr_snapshot
            subset = {"uv_errors","uv_warnings","uv_platform","uv_python","uv_virtualenv"}
            parent_rows = rdr_snapshot.collect(target,subset)
        subprocess.run(["git", "-C", src, "apply", "--index", "-"], input=delta, env=env, check=True)
        assert screen.git("write-tree").strip() == screen.git("rev-parse", d + "^{tree}").strip()
        screen.git("reset", "-q", "--mixed", a)
        assert screen.git("rev-parse","HEAD").decode().strip() == a
        assert screen.git("write-tree").strip() == screen.git("rev-parse",a+"^{tree}").strip()
        expected = dict(env, GIT_INDEX_FILE=str(lane/"expected.index"))
        for args in (("read-tree",d),("update-index","-q","--refresh"),("diff-files","--quiet")):
            subprocess.run(["git","-C",src,*args], env=expected, check=True)
        edit = measure(run, env, target, cmd, "edit-D",plain)
        if case == "20220":
            after = screen.sidecars(target)
            changed = {k:{"parent":before.get(k),"edited":v} for k,v in after.items() if before.get(k) != v}
            assert any(k.endswith("/lib-uv_errors.public-api-hash") for k in changed)
            (run / "public-hashes.json").write_text(json.dumps(changed,indent=2))
        if capture:
            edited_rows = rdr_snapshot.collect(target,subset)
            (run / "rdr.json").write_text(json.dumps(rdr_snapshot.compare(parent_rows,edited_rows)))
        fresh = measure(run, env, target, cmd, "noop-D",plain)
        assert edit["dirty_units"] and not fresh["dirty_units"]
        if case == "20220":
            assert "uv_errors" in edit["dirty_units"]
        if case == "20651" and not plain:
            assert "uv_preview" in edit["dirty_units"] and edit["dirty_units"].count("uv_cli") == 2
        publish(run,out)
        send({"state":"measured","trial":trial,"edit":edit["wall_s"],"noop":fresh["wall_s"],
              "parent_noop":settled["wall_s"],"dirty":edit["dirty_units"]})
