"""Release −18/packaged GNU −22 first-edit pairs, fixed Cargo, with two independent checker roles."""
import hashlib, importlib.util, inspect, json, math, os, re, shutil, statistics, subprocess, sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from zipfile import ZipFile,ZIP_DEFLATED

D=Path(__file__).resolve().parent
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
r=load(D.parent/'literal-21076-dist22/run.py','literal_job22')
o,lit,sha,read=r.o,r.lit,r.sha,r.read
p=load(D/'products.py','matched_cli_units');m=load(o.STUDY/'cli-edits/workspace-19533/pilot-v3/messages.py','cargo_vv')
old=load(D.parent/'literal-21076-matched278/off_behavior.py','parser_oracle');f=old.f
host=load(D.parent/'hash-20605-root-dist22/run.py','physical_floors')
CASE='literal21076-all-features-all-targets'; ARGS=['check','-p','uv-cli','--all-targets','--all-features']
EXACT=['check','--locked','--offline','-j8',*ARGS[1:]]
P=lit.P|{'case':CASE,'args':ARGS}; sdk=o.screen.LANE/'sdk'; roles=['stock','candidate'];REG=D/'registration.json'
o.screen.CASES[CASE]=(lit.A,lit.B,ARGS)
def put(p,v):
    with p.open('x')as f:json.dump(v,f,indent=2)
def order(c):
    seq=o.pairs.order(sorted(c['sdks']),6,c['seed']);assert c['pairs']==6 and c['plain'] and not c['diagnostics'] and set(c['sdks'])==set(roles)
    assert seq.count(tuple(roles))==seq.count(tuple(reversed(roles)))==3
    return seq
def audit():
    assert __debug__;r.audit();reg=read(REG);assert all(sha(D/k)==v for k,v in reg['files'].items())
    for i,ph in enumerate(lit.PH):
        c=read(D/(ph+'.json'));assert c['name']==ph+'-s18-gnu22-all-targets-001' and c['case']==CASE and c['seed']==1101210761+i
        assert list(map(list,order(c)))==reg['orders'][ph] and c['sdks']=={k:read(r.REG)['sdk_paths'][k] for k in roles}
    assert reg['argv']==EXACT and reg['literal']==[lit.A,lit.B,P['patch_sha256']]
    return sha(REG)
def subjects():
    full=read(r.D/read(r.D/'discovery.json')['name']/'subject-intake.json');smoke=read(r.SMOKE)
    r.check_smoke(full,smoke);r.qa(r.D/read(r.D/'discovery.json')['name'])
    ret=read(r.custody.STORE/'return.json')
    assert ret['code']==0 and ret['accepted_sha256']==sha(r.custody.STORE/'accepted.json')==r.ACCEPT
    assert full['dist22']==read(r.custody.STORE/'accepted.json') and full['dist22']['registration']==r.custody.admit()
    assert all(full['arms'][k]['driver_sha256']==r.DRIVERS[k]for k in roles) and full['cargo_sha256']==o.CARGO
    return {**full,'arms':{k:full['arms'][k]for k in roles},'all_target_registration':sha(REG)}
def verify_roles(raw,log):
    entries,details=m.decode(raw);children=m.rustc_children(log,str(sdk/'bin/rustc'));m.correlate(entries,children);m.cli_roles(entries,children)
    dirty=[x for x in entries if x['reason']=='compiler-artifact' and not x['fresh']]
    assert len(dirty)==len(children)==2
    out={}
    for ch in children:
        a=ch['argv'];test='--test'in a
        row,=[x for x in dirty if x['profile']['test']==test]
        assert row['features']==['default','self-update'] and row['target']['name']=='uv_cli' and set(row['target']['kind'])=={'lib'}
        assert a.count('crates/uv-cli/src/lib.rs')==1 and '--emit=dep-info,metadata'in a and len([v for v in a if v.startswith('incremental=')])==1
        assert [a[i+1]for i,v in enumerate(a)if v=='--cfg' and a[i+1].startswith('feature=')]==['feature="default"','feature="self-update"']
        assert (('--crate-type' in a and a[a.index('--crate-type')+1]=='lib')!=test) and ('--test' in a)==test
        ext=[x.split('=',1)[0]for i,v in enumerate(a)if v=='--extern' for x in [a[i+1]]];assert ('insta' in ext)==test
        output=Path(a[a.index('--out-dir')+1]);assert any(Path(v).parent==output for v in row['filenames'])
        out['test'if test else'lib']=dict(key=output.parent.name,argv=a,filenames=row['filenames'],features=row['features'])
    assert out['lib']['key']!=out['test']['key'];return out
def native(out,arm):
    # Same original linked Cli::try_parse_from witness; build each A/B with the measured feature set.
    lane=o.screen.LANE;root=lane/'all-features-parser';root.mkdir();f.SDK=sdk;f.COUNTER=root/'logs';f.ID={arm:{'driver_sha256':r.DRIVERS[arm]}}
    historical=f.cargo
    def cargo(args,dest,label,mode):
        assert args==['build','--locked','--offline','-j8','-p','uv-cli','--lib'] and mode=='build'
        rec,log=historical([*args,'--all-features'],dest,label,mode);(dest/(label+'.cargo.log')).write_bytes(log);return rec,log
    def fresh(k):
        assert k==arm and not f.TARGET.exists() and not f.SRC.exists()
        subprocess.run(['git','clone','--no-checkout',(lit.BANK/'uv.git').resolve().as_uri(),f.SRC],check=True,env=f.environment())
        f.git('checkout','--detach',lit.A);assert f.git('rev-parse','HEAD')==lit.A and not f.git('status','--porcelain')
    def edit():
        f.git('apply','--index',str(lit.REP/'published.patch'));assert f.git('write-tree')==f.git('rev-parse',lit.B+'^{tree}')
        f.git('reset','-q','--mixed',lit.A);assert f.git('rev-parse','HEAD')==lit.A and f.git('diff','--binary','--full-index')==(lit.REP/'published.patch').read_text().strip()
    with patch.multiple(f,cargo=cargo,fresh=fresh,edit=edit):
        for state,want in zip(('A','B'),lit.EXPECT,strict=True):
            f.V=root/state;f.V.mkdir();f.SRC=f.V/'source';f.TARGET=f.V/'target'
            for n in ('home','tmp','cargo-home'):(f.V/n).mkdir()
            (f.V/'cargo-home/registry').symlink_to(lane/'cargo/registry',target_is_directory=True)
            assert f.behavior(arm,state,out)==want.encode();shutil.rmtree(f.TARGET)
def worker(out):
    doc=read(out.parent/'subject-intake.json');assert doc==subjects()
    assert r.probe(out.name,doc)==read(r.SMOKE)['arms'][out.name]
    subprocess.run([sys.executable,'-ISB',lit.D/'material.py','namespace'],check=True)
    lane=o.screen.LANE;actual=o.original;current={}
    def observe(run,env,target,cmd,label,plain):
        assert plain;host.floor(True)
        if label=='warm':assert not target.exists()
        row=actual(run,env,target,[str(sdk/'bin/cargo'),*EXACT],label,plain);value=p.units(target)
        if label=='edit-D':
            assert row['dirty_units']==['uv_cli'];p.transition(read(run/'settled-A.units.json'),value,True)
        if label in ('settled','noop-D'):p.transition(read(run/(('warm'if label=='settled'else'edit-D')+'.units.json')),value,False)
        put(run/(label+'.units.json'),value);current.update(env);return row
    with patch.object(o,'original',observe):o.worker(out,CASE,P)
    # Stop is delivered only after both arms close every clock; take the final ordinary B evidence now.
    target=lane/'target';before=p.units(target,True);queries=p.graphs(target)
    # Restore the compile target to the unexposed frozen A in the same physical path.
    # Working source is still exact uncommitted B on A. Reinstall the source's A mtime history before reapplying B.
    for n in ('target','source'):
        dst=target if n=='target' else o.screen.SRC;shutil.rmtree(dst);o.pairs.copy(lane/('a-'+n),dst)
    assert o.screen.git('rev-parse','HEAD').decode().strip()==lit.A and not o.screen.git('status','--porcelain')
    cmd=[str(sdk/'bin/cargo'),*EXACT]
    def call(*extra):
        res=subprocess.run([*cmd,*extra],cwd=o.screen.SRC,env=current,capture_output=True,check=True);return res.stdout,res.stderr
    def fresh_noop():
        s,e=call();assert not s and not re.search(rb'^\s*(?:Checking|Compiling) ',e,re.M)
    fresh_noop();delta=(out/'edit.patch').read_bytes();subprocess.run(['git','-C',o.screen.SRC,'apply','--index','-'],input=delta,env=current,check=True)
    assert o.screen.git('write-tree')==o.screen.git('rev-parse',lit.B+'^{tree}');o.screen.git('reset','-q','--mixed',lit.A)
    assert o.screen.git('diff','--binary','--full-index')==delta and o.screen.git('rev-parse','HEAD').decode().strip()==lit.A
    raw,log=call('-vv','--message-format=json-render-diagnostics')
    assert len(raw)+len(log)<24<<20
    with ZipFile(out/'offclock.zip','x',ZIP_DEFLATED,compresslevel=3)as z:z.writestr('cargo.stdout',raw);z.writestr('cargo.stderr',log)
    cmds=verify_roles(raw,log);after=p.units(target,True);again=p.graphs(target)
    assert queries==again and all(before[k]['products']==after[k]['products'] and before[k]['key']==after[k]['key']==cmds[k]['key'] for k in ('lib','test'));fresh_noop()
    put(out/'verified.json',dict(ordinary=before,replay=after,queries=queries,replay_queries=again,roles=cmds))
    if out.parent.name==read(D/'discovery.json')['name']:
        # Released targets; each independent fresh native build owns one private /tmp target.
        for name in ('a-target','target'):shutil.rmtree(lane/name)
        native(out,out.name)
def records(phase,checkpoint=True):
    cfg=read(D/(phase+'.json'));d=D/cfg['name'];plan=read(d/'plan.json');proof=read(d/'subject-intake.json')
    assert proof==subjects() and plan['config']==cfg and plan['source']==[lit.A,lit.B] and plan['runner']==sha(D/'run.py') and plan['shared_runner']==sha(D/'screen.py')
    orders=[list(s)for s in order(cfg)];assert plan['sequence']==orders;raw=[json.loads(x)for x in (d/'pairs.jsonl').read_text().splitlines()]
    assert len(raw)==6 and [list(row)for row in raw]==orders
    for arm in roles:
        a=d/arm;q=read(a/'verified.json');ident=read(a/'identity.json');assert ident['cargo']==o.CARGO and ident['launcher']==proof['arms'][arm]['launcher_sha256'] and {v['sha256']for v in ident['linked'].values()}=={r.DRIVERS[arm],proof['llvm_sha256']}
        assert plan['inputs'][arm]['cargo']==o.CARGO and plan['inputs'][arm]['sdk_cargo_before_overlay']==(o.CARGO if arm=='stock' else r.custody.CARGO)
        assert sha(a/'edit.patch')==P['patch_sha256'] and q['queries']==q['replay_queries']
        assert len(q['queries'])==2 and all(v[t]['items']>0 for v in q['queries'].values()for t in ('mir_borrowck','typeck_root'))
        with ZipFile(a/'offclock.zip')as z:assert set(z.namelist())=={'cargo.stdout','cargo.stderr'} and verify_roles(z.read('cargo.stdout'),z.read('cargo.stderr'))==q['roles']
        for k in ('lib','test'):
            assert q['ordinary'][k]['products']==q['replay'][k]['products'] and len(q['ordinary'][k]['products'])==2 and q['ordinary'][k]['key']==q['roles'][k]['key']
        if phase=='discovery':
            witnesses=[]
            for state,exp in zip(('A','B'),lit.EXPECT,strict=True):
                pre='fresh-'+arm+'-'+state;g=read(a/(pre+'-build.json'));w=read(a/(pre+'-behavior.json'))
                assert g['argv']==[str(sdk/'bin/cargo'),'build','--locked','--offline','-j8','-p','uv-cli','--lib','--all-features'] and g['exit']==0 and sha(a/(pre+'-build.cargo.log'))==g['stdout_sha256']
                assert w['source']==state and w['arm']==arm and w['compiler_sha256']==r.DRIVERS[arm] and w['witness_source']==sha(lit.SOURCE) and w['expected_clap_exit']==2 and w['fresh_empty_cargo_target'] and w['diagnostic']==exp
                witnesses.append(w)
            assert all(witnesses[0][key]!=witnesses[1][key]for key in ('program_sha256','libuv_cli_sha256'))
        for i in range(7):
            with ZipFile(a/('setup.zip'if i==0 else f'pair-{i}.zip'))as z:
                get=lambda n:json.loads(z.read(n+'.json'))
                labels=['warm','settled']if not i else ['settled-A','edit-D','noop-D']
                for l in labels:
                    obs=get(l);assert obs['cmd']==[str(sdk/'bin/cargo'),*EXACT] and obs['wall_s']>0 and not z.read(l+'.stdout')
                    logged=[n.decode().replace('-','_')for n in re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',z.read(l+'.stderr'),re.M)];assert logged==obs['dirty_units']
                    if l=='warm':assert 'uv_cli'in logged
                    else:assert logged==(['uv_cli']if l=='edit-D'else[])
                    if i:
                        assert readusage(z,l)>0 and obs['wall_s']==raw[i-1][arm][{'edit-D':'edit','settled-A':'parent_noop','noop-D':'noop'}[l]]
                for x,y in zip(labels,labels[1:]):p.transition(get(x+'.units'),get(y+'.units'),y=='edit-D')
                if i==6:assert all(q['ordinary'][k]['invoked_ns']==get('noop-D.units')[k]['invoked_ns']for k in ('lib','test'))
    if checkpoint:assert read(d/'success.json')==dict(registration=sha(REG),pairs=sha(d/'pairs.jsonl'),workers_returned=True,phase=phase)
    return [dict(order=list(x),times={a:x[a]['edit']for a in roles},ratio=x['stock']['edit']/x['candidate']['edit'])for x in raw]
def readusage(z,label):
    u=json.loads(z.read(label+'.usage.json'));return u['user_us']+u['sys_us']
def gate(d):return statistics.median(x['ratio']for x in d)>=1.8
def score(c):
    assert len(c)==2 and all(len(x)==6 for x in c);rows=c[0]+c[1];xs=[x['ratio']for x in rows]
    alpha=.025;rank=max(i for i in range(6)if 2*sum(math.comb(12,j)for j in range(i+1))/2**12<=alpha)
    ci=[sorted(xs)[rank],sorted(xs)[-rank-1]];pval=o.SCORE['sign_p'](xs,2)
    seeds=[statistics.median(x['ratio']for x in block)for block in c];strata=[[x['ratio']for x in rows if x['order'][0]==a]for a in roles];assert list(map(len,strata))==[6,6]
    orders=list(map(statistics.median,strata));return dict(n=12,median=statistics.median(xs),interval=ci,p=pval,seeds=seeds,orders=orders,qualified=ci[0]>2 and pval<alpha and min(seeds+orders)>2)
def main(args):
    seal=audit()
    if args==['audit']:return dict(registration=seal,argv=EXACT)
    if args[:1]==['worker']:assert len(args)==3 and args[2]==CASE;return worker(Path(args[1]))
    assert len(args)==1 and args[0]in (*lit.PH,'admit','score')
    assert os.sched_getaffinity(0)=={29}
    if args==['score']:assert gate(records('discovery'));return score([records(x) for x in lit.PH[1:]])
    host.floor();assert lit.REGISTRY.is_dir() and (lit.REGISTRY.parent/'verified.json').is_file()
    with r.four():r.custody.floor();proof=subjects()
    if args==['admit']:return dict(registration=seal,subjects={k:r.DRIVERS[k]for k in roles})
    ph=args[0];c=read(D/(ph+'.json'));dest=D/c['name'];assert not dest.exists()
    if ph!='discovery':assert gate(records('discovery'))
    if ph=='confirm-2':records('confirm-1')
    # Preserve the pair kernel, and wait for each returned worker's off-clock QA to close before the next.
    src=inspect.getsource(o.pairs.outer);old='            proc.stdin.close()\n        assert all(p.wait() == 0 for p in workers.values())'
    assert src.count(old)==1
    def original(obj):
        assert obj is o.pairs.outer
        return src.replace(old,'            proc.stdin.close()\n            assert proc.wait() == 0')
    assert shutil.disk_usage(D).free>=(122<<30)+(96<<20)
    with host.watched(),patch.object(o,'order',order),patch.object(o,'inspect',SimpleNamespace(getsource=original)):o.outer(D,D/(ph+'.json'),proof)
    rows=records(ph,False);put(dest/'success.json',dict(registration=seal,pairs=sha(dest/'pairs.jsonl'),workers_returned=True,phase=ph))
    return dict(phase=ph,samples=6,median=statistics.median(x['ratio']for x in rows),discovery_opens_holdout=gate(rows)if ph=='discovery'else None)
if __name__=='__main__':
    answer=main(sys.argv[1:])
    if answer is not None:print(json.dumps(answer,indent=2))
