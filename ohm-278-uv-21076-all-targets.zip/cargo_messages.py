"""Decode Cargo JSON and the exact extra-verbose build-script framing; retain raw byte evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shlex
import zipfile
from urllib.parse import unquote,urlsplit

PREFIX=re.compile(rb"^\[([A-Za-z0-9_-]+) ([0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?)\] ")
REASONS={"build-started","compiler-message","compiler-artifact","build-script-executed","build-finished"}
def require(ok,message):
    if not ok:raise ValueError(message)
def package(pid):
    url=urlsplit(pid)
    name,at,version=url.fragment.rpartition("@")
    if not at:name=unquote(url.path).rsplit("/",1)[-1]
    return name,version
def no_duplicate_keys(pairs):
    out={}
    for key,value in pairs:
        require(key not in out,"duplicate key in Cargo JSON object");out[key]=value
    return out
def decode(raw):
    require(raw.endswith(b"\n"),"incomplete Cargo stream")
    records=[];extras=Counter();producers=set();framed=hashlib.sha256()
    for lineno,line in enumerate(raw[:-1].split(b"\n"),1):
        if line.startswith(b"{"):
            record=json.loads(line,object_pairs_hook=no_duplicate_keys)
            require(isinstance(record,dict) and record.get("reason") in REASONS,f"unknown Cargo event at {lineno}")
            reason=record["reason"]
            if reason=="build-started":
                require(not records and isinstance(record.get("run_id"),str) and record["run_id"],"misplaced or invalid build-started event")
            if reason=="compiler-artifact":
                require(type(record["fresh"]) is bool and type(record["profile"]["test"]) is bool and isinstance(record["package_id"],str)
                        and isinstance(record["target"]["name"],str) and isinstance(record["filenames"],list),"bad compiler artifact")
            if reason=="compiler-message":require(isinstance(record["message"],dict) and isinstance(record["package_id"],str),"bad compiler diagnostic")
            if reason=="build-script-executed":
                require(isinstance(record["out_dir"],str),"bad build-script event");producers.add(package(record["package_id"]))
            require(not records or records[-1]["reason"]!="build-finished","Cargo event after build-finished")
            records.append(record)
        else:
            match=PREFIX.match(line)
            require(match is not None,f"unframed non-JSON stdout at {lineno}: {line[:120]!r}")
            require(not records or records[-1]["reason"]!="build-finished","extra stdout after build-finished")
            key=tuple(v.decode("ascii") for v in match.groups());extras[key]+=1;framed.update(line+b"\n")
    require(records and records[-1]=={"reason":"build-finished","success":True},"missing positive Cargo final event")
    require(set(extras)<=producers,f"stdout prefix without real build-script event: {set(extras)-producers}")
    return records,{"messages":dict(Counter(r["reason"] for r in records)),"verbose_build_script_lines":[[n,v,k]for (n,v),k in sorted(extras.items())],
                    "verbose_lines_sha256":framed.hexdigest(),"stdout_sha256":hashlib.sha256(raw).hexdigest()}
def preserve_failure(run,out,label,error):
    # Keep just this call's untouched stdout, stderr and small causally relevant metadata.
    # Do not copy the warmed target or toolchain and never overwrite earlier evidence.
    destination=out/("failure-"+run.name+"-"+label+".zip")
    selected=sorted(p for p in run.glob(label+".*") if p.is_file() and p.suffix not in (".html",))
    with zipfile.ZipFile(destination,"x",zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        z.writestr("failure.json",json.dumps({"label":label,"exception":type(error).__name__,"message":str(error)[:2000]}))
        size=sum(p.stat().st_size for p in selected)
        require(size<=96*2**20,"raw Cargo output exceeds 96 MiB failure-evidence cap")
        for p in selected:z.write(p,p.name)

def process_frames(stderr):
    # cargo-util::ProcessBuilder display encloses the entire rendered command in
    # backticks. Environment values and arguments may contain quoted newlines
    # and literal backticks, possibly as the final character of a physical line.
    require(isinstance(stderr,bytes),"stderr must contain the original bytes")
    prefix=re.compile(rb"^[ \t]*Running `")
    offset=0;start=None;body=0;line_count=0
    for line in stderr.split(b"\n"):
        end=offset+len(line)
        match=prefix.match(line)
        if start is None and match:
            start=offset;body=start+match.end();line_count=0
        elif start is not None:
            require(not match,"nested Cargo Running status inside unfinished command")
        if start is not None:
            line_count+=1
            require(end-start<=512*1024 and line_count<=256,"unbounded Cargo command")
            if line.endswith(b"`"):
                try:tokens=shlex.split(stderr[body:end-1].decode("utf-8"),comments=False,posix=True)
                except ValueError as exc:
                    require(str(exc) in ("No closing quotation","No escaped character"),"unrecognized shell syntax")
                else:
                    require(bool(tokens),"empty Cargo Running command")
                    after=end+int(end<len(stderr))
                    yield start,after,stderr[start:after].decode("utf-8"),tokens
                    start=None
        offset=end+1
    require(start is None,"unterminated Cargo Running command")
def rustc_children(stderr,rustc):
    children=[]
    for start,end,raw,tokens in process_frames(stderr):
        if rustc not in tokens:continue
        at=tokens.index(rustc)
        prefix=tokens[:at]
        require(all(re.fullmatch("[A-Za-z_][A-Za-z0-9_]*=.*",t,re.S)for t in prefix),"unexpected executable before rustc")
        env=dict(t.split("=",1)for t in prefix)
        require(len(env)==len(prefix),"duplicate command environment assignment")
        children.append({"raw":raw,"byte_range":[start,end],"package":env.get("CARGO_PKG_NAME"),"argv":tokens[at:]})
    return children
def correlate(messages,children):
    dirty=Counter((package(r["package_id"])[0],r["target"]["name"].replace("-","_"),r["profile"]["test"])
                  for r in messages if r["reason"]=="compiler-artifact" and not r["fresh"])
    seen=Counter()
    for child in children:
        a=child["argv"]
        require(a.count("--crate-name")==1 and a.count("--out-dir")==1,"rustc child has no unique compilation unit")
        seen[child["package"],a[a.index("--crate-name")+1],"--test" in a]+=1
    require(seen==dirty,f"Cargo artifact and actual rustc role multiplicities differ: {seen-dirty} / {dirty-seen}")
def cli_roles(messages,children):
    dirty=[r for r in messages if r["reason"]=="compiler-artifact" and not r["fresh"] and r["target"]["name"]=="uv_cli"]
    require(len(dirty)==2 and {r["profile"]["test"] for r in dirty}=={False,True},"missing real Cargo uv_cli roles")
    cli=[]
    for child in children:
        a=child["argv"]
        if "--crate-name" in a and a[a.index("--crate-name")+1]=="uv_cli":cli.append(a)
    require(len(cli)==2 and {"--test" in a for a in cli}=={False,True},"missing real rustc uv_cli roles")
