"""Offline verification of literal uv #21076 package checking in both rustc configurations."""
import argparse
import ast
from collections import Counter
from decimal import Decimal
from fractions import Fraction
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
from statistics import median
import sys
import zipfile
import cargo_roles
import products

ROLES=("stock","candidate");PHASES=("discovery","confirm-1","confirm-2")
A="9f5808695af96f92daf680ded0ebe939869241ed";B="79ef389e39e3b21a5443b7ab25e890f33b0dadf9"
REG="339475b984847f7c09f056b613d20481d993659c24e0e9cac98880f0d217205d"
PATCH="d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28"
RUST={"stock":"a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de","candidate":"07a3122d625927e970985f6e74d377cbed179476790e8ff3c0401dcd2b165701"}
CARGO="02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
COMMAND=["/tmp/uv-workflow-search/sdk/bin/cargo","check","--locked","--offline","-j8","-p","uv-cli","--all-targets","--all-features"]
TARGETS=("crates/uv-cli/src/lib.rs","crates/uv/tests/it/version.rs")
def need(v,reason):
    if not v:raise ValueError(reason)
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b" "+str(len(b)).encode()+b"\0"+b).hexdigest()
def ns(v):
    value=Decimal(str(v))*1_000_000_000;need(value>0 and value==value.to_integral(),"clock precision or sign");return int(value)
class Records:
    def __init__(self,z):self.z=z;self.overrides={}
    def b(self,n):return self.overrides[n] if n in self.overrides else self.z.read(n)
    def j(self,n):return json.loads(self.b(n))
    def text(self,n):return self.b(n).decode()
    def validate(self):
        entries=self.z.infolist();names=[r.filename for r in entries];h=self.j("MANIFEST.json")
        need(len(names)==len(set(names))<850 and set(h)==set(names)-{"MANIFEST.json"} and sum(r.file_size for r in entries)<9<<20,"bounded complete ZIP")
        need(all(sha(self.b(n))==v for n,v in h.items()),"published bytes")
        public=self.j("ORIGINALS.json")
        for n,v in public["members"].items():
            need(v["published_sha256"]==h[n] and (bool(v["replacements"]) or v["original_sha256"]==h[n]),"original member closure")
            if re.search(r"/(?:pair-[1-6]|setup)/",n) or n.endswith(("pairs.jsonl","verified.json","identity.json","protocol.log")):
                need(v["original_sha256"]==h[n],"timing/semantic evidence changed in publication")

def source(f):
    table=f.j("source/trees.json")
    def tree(k):
        b=bytes.fromhex(f.text("source/tree-"+k+".hex"));need(oid("tree",b)==k,"Git tree");rows={}
        while b:
            label,b=b.split(b"\0",1);mode,n=label.split(b" ",1);rows[n.decode()]=(mode.decode(),b[:20].hex());b=b[20:]
        return rows
    def diff(a,b,path=""):
        x,y=tree(a),tree(b);need(x.keys()==y.keys(),"unexpected addition or removal");out=set()
        for k,(mode,h) in x.items():
            mode2,h2=y[k];need(mode==mode2,"changed mode")
            if h!=h2:out|=diff(h,h2,path+k+"/") if mode=="40000" else {path+k}
        return out
    for rev in (A,B):
        raw=f.b("source/commit-"+rev);need(oid("commit",raw)==rev and raw.splitlines()[0].decode()=="tree "+table[rev]["tree"],"original historical commit")
        if rev==B:need(raw.splitlines()[1].decode()=="parent "+A,"direct historical parent")
        for path,want in table[rev]["paths"].items():
            k=table[rev]["tree"]
            for part in path.split("/"):_,k=tree(k)[part]
            need(k==want,"tree path "+path)
            if rev==A or path not in TARGETS:need(oid("blob",f.b("source/"+path))==k,"source preimage")
    need(diff(table[A]["tree"],table[B]["tree"])==set(TARGETS),"complete literal two-file change")
    patch=f.b("source/edit.patch");need(sha(patch)==PATCH,"original patch")
    for chunk in patch.decode().split("diff --git ")[1:]:
        lines=chunk.splitlines(keepends=True);path=lines[0].split()[0][2:];need(path in TARGETS,"unexpected patched path")
        old=f.text("source/"+path).splitlines(keepends=True);out=[];i=0
        need(lines[1].split()[1]==table[A]["paths"][path]+".."+table[B]["paths"][path],"original patch blob IDs")
        for line in lines[4:]:
            if line.startswith("@@"):
                pos=int(re.match(r"@@ -(\d+)",line)[1])-1;need(pos>=i,"overlapping hunk");out.extend(old[i:pos]);i=pos
            elif line.startswith((" ","-","+")):
                if line[0]!="+":need(old[i]==line[1:],"hunk preimage mismatch");i+=1
                if line[0]!="-":out.append(line[1:])
            else:raise ValueError("unknown diff hunk")
        need(oid("blob","".join(out+old[i:]).encode())==table[B]["paths"][path],"changed source postimage")
    clippy="cargo clippy --workspace --all-targets --all-features --locked -- -D warnings"
    workflow=f.text("source/.github/workflows/check-lint.yml").splitlines();contributing=f.text("source/CONTRIBUTING.md").splitlines()
    need(all(clippy in workflow[n-1] for n in (130,160)) and clippy in contributing[163],"historical Clippy selectors")
    need(table[A]["paths"]["Cargo.lock"]==table[B]["paths"]["Cargo.lock"]==f.j("source/material.json")["lock"]=="c1601688714997cf9380248c63a6bbb32537224d","historical lock")
    pkg=f.text("source/crates/uv-cli/Cargo.toml");need("[dev-dependencies]\ninsta = " in pkg and "[features]\ndefault = []\nself-update = []" in pkg,"feature/dev-dependency setup")

def clock(f,p,label,expected,elapsed=None):
    pre=p+"/"+label;r=f.j(pre+".json");err=f.b(pre+".stderr");u=f.j(pre+".usage.json")
    need(r["cmd"]==COMMAND and r["unit_source"]=="ordinary Cargo progress" and not f.b(pre+".stdout") and b"Finished" in err,"unwrapped ordinary check")
    dirty=[s.decode().replace("-","_") for s in re.findall(rb"^\s*(?:Checking|Compiling) ([\w-]+) v",err,re.M)]
    need(r["dirty_units"]==dirty and (dirty.count("uv_cli")==1 if expected is None else dirty==expected),"incorrect Cargo dirty roster")
    need(u["user_us"]+u["sys_us"]>0 and min(u["user_us"],u["sys_us"])>=0,"physical CPU use")
    value=ns(r["wall_s"]);need(elapsed is None or value==ns(elapsed),"raw clock does not match pair")
    units=f.j(pre+".units.json");need(set(units)=={"lib","test"} and units["lib"]["key"]!=units["test"]["key"],"missing independent unit")
    for role,t in units.items():
        need(re.fullmatch("[0-9a-f]{16}",t["key"]) and t["features"]==["default","self-update"] and
             t["invoked_ns"]>0 and t["dep_info_bytes"]>0 and (t["metadata_bytes"]==0 if role=="test" else t["metadata_bytes"]>16),"metadata or cfg")
    return units

def unit_outputs(q):
    need(q["queries"]==q["replay_queries"] and len(q["queries"])==2,"session/query-key/result comparison")
    counts=[]
    for name,table in q["queries"].items():
        need(re.fullmatch("uv_cli-[0-9a-z]+",name) and set(table)=={"typeck_root","mir_borrowck"} and
             all(t["items"]>0 and re.fullmatch("[0-9a-f]{64}",t["sha256"]) for t in table.values()),"session query vector")
        counts.append((table["typeck_root"]["items"],table["mir_borrowck"]["items"]))
    need(sorted(counts)==[(1104,923),(1139,958)],"observed query-key rosters")
    for role in ("lib","test"):
        a,b=q["ordinary"][role],q["replay"][role];key=a["key"]
        products_a=a["products"];meta="libuv_cli-"+key+".rmeta";dep="uv_cli-"+key+".d"
        need(key==b["key"]==q["roles"][role]["key"] and products_a==b["products"] and set(products_a)=={meta,dep}
             and all(re.fullmatch("[0-9a-f]{64}",v) for v in products_a.values()),"ordinary/replayed product hashes")
        need(a["features"]==b["features"]==["default","self-update"] and a["metadata_bytes"]==b["metadata_bytes"] and
             a["dep_info_bytes"]==b["dep_info_bytes"]>0 and (a["metadata_bytes"]==0)==(role=="test") and
             (products_a[meta]==sha(b""))==(role=="test"),"all four metadata/dep-info products")

def parser(f,arm):
    rows=[];want="error: invalid bump component `foo`"
    for state in "AB":
        p="parser/"+arm+"/"+state+"-";w=f.j(p+"behavior.json");g=f.j(p+"build.json")
        expected=want if state=="A" else want+"\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n"
        need(w["source"]==state and w["arm"]==arm and w["compiler_sha256"]==RUST[arm] and w["fresh_empty_cargo_target"] and
             w["expected_clap_exit"]==2 and w["diagnostic"]==expected and w["witness_source"]==sha(f.b("source/parser.rs")),"actual linked parser diagnostic")
        need(g["exit"]==0 and g["argv"]==[COMMAND[0],"build","--locked","--offline","-j8","-p","uv-cli","--lib","--all-features"] and
             g["elapsed_ns"]==g["end_ns"]-g["start_ns"]>0 and g["bytes"]==len(f.b(p+"build.cargo.log")) and g["stdout_sha256"]==sha(f.b(p+"build.cargo.log")),"independent native witness build")
        rows.append((w,g))
    need(rows[0][1]["end_ns"]<=rows[1][1]["start_ns"] and all(rows[0][0][k]!=rows[1][0][k] for k in ("libuv_cli_sha256","program_sha256")),"different linked parent and child")

def phase(f,name):
    cfg=f.j("protocol/"+name+".json");p=f.j(name+"/plan.json");s=f.j(name+"/success.json");reg=f.j("protocol/registration.json")
    need(s=={"registration":REG,"pairs":sha(f.b(name+"/pairs.jsonl")),"workers_returned":True,"phase":name} and
         p["config"]==cfg and p["source"]==[A,B] and cfg["case"]=="literal21076-all-features-all-targets" and cfg["pairs"]==6 and cfg["plain"] and not cfg["diagnostics"],"closed enrolled phase")
    seed=1101210761+PHASES.index(name);need(cfg["seed"]==seed,"wrong registered seed")
    choices=list(itertools.permutations(sorted(ROLES)));rng=random.Random(seed);orders=[]
    while len(orders)<6:rng.shuffle(choices);orders.extend(map(list,choices))
    rows=[json.loads(line) for line in f.b(name+"/pairs.jsonl").splitlines()]
    need(len(rows)==6 and orders==p["sequence"]==reg["orders"][name]==[list(r) for r in rows] and Counter(map(tuple,orders))=={ROLES:3,ROLES[::-1]:3},"wrong/missing paired arm or order")
    need(p["runner"]==sha(f.b("protocol/run.py")) and p["shared_runner"]==reg["files"]["screen.py"] and reg["argv"]==COMMAND[1:] and reg["literal"]==[A,B,PATCH],"registered source and command")
    starts={};summaries={}
    for arm in ROLES:
        folder=name+"/"+arm;identity=f.j(folder+"/identity.json");inp=p["inputs"][arm]
        need(identity["cargo"]==inp["cargo"]==CARGO and identity["launcher"]==inp["launcher"]==f.j("asset/inputs.json")["roles"][arm]["launcher_sha256"] and
             {v["sha256"] for v in identity["linked"].values()}=={RUST[arm],f.j("asset/inputs.json")["llvm_sha256"]} and RUST[arm] in inp["drivers"].values(),"actual SDK/driver and signed Cargo")
        need(inp["sdk_cargo_before_overlay"]==(CARGO if arm=="stock" else f.j("asset/inputs.json")["dist22"]["packaged_cargo"]) and
             "commit-hash: 7caf39914da1e28a67744ecbc963a5f26361474d" in f.text(folder+"/cargo.txt") and ("ohm-1.99.0-"+("18" if arm=="stock" else "22")) in f.text(folder+"/rustc.txt"),"tool versions")
        proto=f.text(folder+"/protocol.log").splitlines();need(json.loads(proto[0])==f.j("source/material.json")["registry"] and
             [json.loads(line[7:]) for line in proto if line.startswith("UVPAIR ")]==[{"state":"ready","patch":PATCH}]+[r[arm] for r in rows],"source custody and actual scheduling")
        cold=clock(f,folder+"/setup","warm",None);initial=clock(f,folder+"/setup","settled",[]);products.transition(cold,initial,False)
        starts[arm]=[cold[k]["invoked_ns"] for k in ("lib","test")]
        for i,r in enumerate(rows,1):
            trial=folder+"/pair-"+str(i);sample=r[arm]
            need(sample["state"]=="measured" and sample["trial"]==str(i) and sample["dirty"]==["uv_cli"],"ordinary timed first edit")
            a=clock(f,trial,"settled-A",[],sample["parent_noop"]);b=clock(f,trial,"edit-D",["uv_cli"],sample["edit"]);c=clock(f,trial,"noop-D",[],sample["noop"])
            need(a==initial,"different restored history");products.transition(a,b,True);products.transition(b,c,False)
        q=f.j(folder+"/verified.json");raw=f.b(folder+"/offclock/cargo.stdout");log=f.b(folder+"/offclock/cargo.stderr")
        need(cargo_roles.verify_roles(raw,log)==q["roles"],"two actual verbose rustc invocations and feature cfgs")
        unit_outputs(q);need(all(q["ordinary"][k]["invoked_ns"]==c[k]["invoked_ns"] for k in ("lib","test")),"final timed ordinary unit vs off-clock comparison")
        summaries[arm]={"queries":q["queries"],"products":{k:v["products"] for k,v in q["ordinary"].items()}}
        if name=="discovery":parser(f,arm)
    return rows,starts,summaries
def subjects(f):
    x=f.j("asset/inputs.json");w=f.j("asset/workflow.json");u=f.j("asset/provenance.json");s=f.j("asset/signed18.json");k=x["dist22"]
    need((u["toolchain"],s["toolchain"])==("ohm-1.99.0-22","ohm-1.99.0-18") and
        u["target"]==s["target"]=="x86_64-unknown-linux-gnu" and w["job"]["conclusion"]=="success" and
        w["artifact"]["workflow_run"]["id"]==w["job"]["run_id"]==w["run"]["id"]==41237680370 and
        w["job"]["id"]==k["job_id"]==124644935360 and w["artifact"]["id"]==k["artifact_id"]==13057710231,"official workflow provenance")
    need(u["coordinator"]["revision"]==w["job"]["head_sha"]==k["head"]=="007da57ba792129adb5754546e1158e7e6d732b7" and
        u["sources"]["rust"]["revision"]==k["source"]=="556a8364f1485a03be31b1a50c250d63198a943d" and
        s["sources"]["rust"]["revision"]=="a4fa11bcd38280639cb94daacc125472657db6c3" and s["sources"]["cargo"]["revision"]=="7caf39914da1e28a67744ecbc963a5f26361474d","release source identities")
    need(w["artifact"]["digest"]=="sha256:"+k["zip_sha256"] and f.text("asset/tar.sha256").split()[0]==k["tar_sha256"] and
        f.text("asset/signed18.sha256").split()[0]=="629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8" and
        x["cargo_sha256"]==CARGO and x["llvm_sha256"]=="43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51","distribution/member hashes")
    files=k["files"]
    need(files["bin/cargo"]["sha256"]==k["packaged_cargo"] and files["bin/rustc"]["sha256"]==x["roles"]["candidate"]["launcher_sha256"] and files[k["compiler"]]["sha256"]==RUST["candidate"] and any(n.startswith("lib/rustlib/x86_64-unknown-linux-gnu/lib/libstd-") for n in files),"compiler, packaged Cargo and standard library member inventory")
    reg=f.j("protocol/registration.json")
    for era in ("r18","r22"):
        n="protocol/"+era+"-queries.rs";qu=f.text(n)
        names=re.findall(r"^\s*query\s+([A-Za-z_]\w*)\b",qu,re.M);offset=len(re.findall(r"^\s*non_query\s+\w+\b",qu,re.M))
        need(sha(f.b(n)) in reg["files"].values() and offset==8 and {k:offset+names.index(k) for k in ("mir_borrowck","typeck_root")}==reg["source_kind_ids"],"release-source query kind IDs")
    mt=[json.loads(s) for s in f.b("history/matched278-pairs.jsonl").splitlines()]
    ref=f.j("history/matched278-summary.json")["checks"]["normal"]["result"]
    need(len(mt)==6 and all(set(r)=={"stock","parent","candidate"} for r in mt) and ref["source"]==[A,B] and not ref["opens_confirmation"] and
        median(r["parent"]["edit"]/r["candidate"]["edit"] for r in mt)==ref["paired_speedups"]["off/on"] and
        median(r["stock"]["edit"]/r["candidate"]["edit"] for r in mt)==ref["paired_speedups"]["signed/on"],"different #278 matched study")

def sign(vals,against):
    valid=[s for s in vals if s!=against];wins=sum(s>against for s in valid)
    return {"above":wins,"below":len(valid)-wins,"ties":len(vals)-len(valid),"one_sided_p":sum(math.comb(len(valid),i) for i in range(wins,len(valid)+1))/2**len(valid)}

def analyze(f):
    need(__debug__,"verification requires normal Python with assertions");source(f);subjects(f)
    o=f.j("ORIGINALS.json")["members"];need(o["protocol/registration.json"]["original_sha256"]==REG,"prospective registration")
    docs={k:phase(f,k) for k in PHASES}
    need(len({tuple(st[a]) for _,st,_ in docs.values() for a in ROLES})==6,"arm/phase A histories were reused")
    for a in ROLES:
        need(len({json.dumps(v[a],sort_keys=True) for _,_,v in docs.values()})==1,"cross-phase product or query disagreement")
    def pair(r):return Fraction(ns(r["stock"]["edit"]),ns(r["candidate"]["edit"]))
    pilot=docs["discovery"][0];disc=float(median([pair(r) for r in pilot]));need(disc>=1.8,"discovery gate closed")
    held=docs["confirm-1"][0]+docs["confirm-2"][0];v=[pair(r) for r in held];n=len(v)
    rank=max(i for i in range(n//2) if 2*sum(math.comb(n,j) for j in range(i+1))/2**n<=.025)
    lo,hi=float(sorted(v)[rank]),float(sorted(v)[-rank-1]);seeds=[float(median(v[:6])),float(median(v[6:]))]
    orders={a:float(median(x for x,r in zip(v,held) if next(iter(r))==a)) for a in ROLES}
    checks={i:sign(v,i) for i in (1,2)}
    def medtime(r,k):return median(x[r][k] for x in held)
    return {"discovery_excluded":6,"discovery_median":disc,"heldout":n,"seconds":{a:{k:medtime(a,k) for k in ("edit","parent_noop","noop")} for a in ROLES},
      "median_paired_speedup":float(median(v)),"nonparametric_interval":[lo,hi],"interval_order_ranks":[rank+1,n-rank],
      "interval_coverage_continuous_median":1-2*sum(math.comb(n,j) for j in range(rank+1))/2**n,"sign_tests":checks,
      "heldout_seed_medians":seeds,"heldout_order_medians":orders,"qualifies_for_2x":lo>2 and checks[2]["one_sided_p"]<.025 and min(seeds+list(orders.values()))>2,
      "all_pairs":[{"phase":ph,"pair":i,"first":next(iter(r)),"s18_ns":ns(r["stock"]["edit"]),"gnu22_ns":ns(r["candidate"]["edit"]),"ratio":float(pair(r))} for ph in PHASES for i,r in enumerate(docs[ph][0],1)]}

def negative(f):
    import copy
    result=[]
    def bad(name,fn):
        try:fn()
        except (AssertionError,ValueError,KeyError,IndexError,StopIteration):result.append(name)
        else:raise ValueError("accepted negative control "+name)
    def mutate(key,b,fn):
        f.overrides[key]=b
        try:fn()
        finally:del f.overrides[key]
    def enc(v):return json.dumps(v).encode()
    ph="confirm-2";arm=ph+"/candidate";one=arm+"/pair-1/"
    def wrong_order():
        key="protocol/"+ph+".json";v=f.j(key);v["seed"]-=1;mutate(key,enc(v),lambda:phase(f,ph))
    bad("mixed independent seed/order",wrong_order)
    def missing_arm():
        key=ph+"/pairs.jsonl";ls=f.text(key).splitlines();r=json.loads(ls[-1]);del r["stock"];ls[-1]=json.dumps(r);mutate(key,("\n".join(ls)+"\n").encode(),lambda:phase(f,ph))
    bad("missing paired arm",missing_arm)
    bad("fresh fake B",lambda:mutate(one+"edit-D.stderr",f.b(one+"settled-A.stderr"),lambda:clock(f,one[:-1],"edit-D",["uv_cli"])))
    bad("dirty final no-op",lambda:mutate(one+"noop-D.stderr",f.b(one+"edit-D.stderr"),lambda:clock(f,one[:-1],"noop-D",[])))
    bad("different raw clock",lambda:clock(f,one[:-1],"edit-D",["uv_cli"],999))
    a=f.j(one+"settled-A.units.json");b=f.j(one+"edit-D.units.json");b["test"]=a["test"]
    bad("unchanged test-unit fingerprint",lambda:products.transition(a,b,True))
    l=f.b(arm+"/offclock/cargo.stderr");raw=f.b(arm+"/offclock/cargo.stdout")
    bad("single rustc cfg",lambda:cargo_roles.verify_roles(raw,b"\n".join(row for row in l.splitlines() if b" --test " not in row)))
    bad("missing actual self-update cfg",lambda:cargo_roles.verify_roles(raw,l.replace(b"--cfg 'feature=\"self-update\"'",b"--cfg 'feature=\"bad\"'")))
    q=f.j(arm+"/verified.json");r=copy.deepcopy(q);m=next(iter(r["replay"]["test"]["products"]));r["replay"]["test"]["products"][m]="f"*64
    bad("changed metadata or dep-info",lambda:unit_outputs(r));r=copy.deepcopy(q)
    k=next(iter(r["queries"]));r["queries"][k]["mir_borrowck"]["sha256"]="f"*64
    bad("changed same-count query result",lambda:unit_outputs(r))
    g="parser/candidate/B-behavior.json";r=f.j(g);r["diagnostic"]=f.j("parser/candidate/A-behavior.json")["diagnostic"]
    bad("child reproduces old parser output",lambda:mutate(g,enc(r),lambda:parser(f,"candidate")))
    patch="source/edit.patch";bad("wrong genuine postimage",lambda:mutate(patch,f.b(patch)+b"\n",lambda:source(f)))
    return result

def main():
    op=argparse.ArgumentParser(description=__doc__);op.add_argument("--negative-controls",action="store_true")
    op.add_argument("--target",nargs=3,metavar=("PHASE","ARM","MATCHING_FINAL_B_TARGET"));arg=op.parse_args()
    with zipfile.ZipFile(sys.argv[0]) as z:
        f=Records(z);f.validate();out=analyze(f)
        if arg.negative_controls:out["negative_controls_rejected"]=negative(f)
        if arg.target:
            ph,arm,path=arg.target;need(ph in PHASES and arm in ROLES,"wrong phase or arm");q=f.j(ph+"/"+arm+"/verified.json");actual=products.units(Path(path),True)
            for role in ("lib","test"):need(actual[role]["products"]==q["ordinary"][role]["products"],"real target product mismatch")
            need(products.graphs(Path(path))==q["queries"],"real target query keys/values differ");out["matching_real_target"]=True
        print(json.dumps(out,indent=2))
if __name__=="__main__":main()
