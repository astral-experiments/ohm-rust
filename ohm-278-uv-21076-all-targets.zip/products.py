"""Check the two uv_cli unit stamps and independently match their metadata/dep-info and tracked query values."""
from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess

def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()

def units(target, content=False):
    base=target/"debug/build/uv-cli"
    result={}
    for role,name in (("lib","lib-uv_cli"),("test","test-lib-uv_cli")):
        [fp]=base.glob("*/fingerprint/"+name+".json")
        d=fp.parent.parent; key=d.name;assert re.fullmatch("[0-9a-f]{16}",key)
        info=json.loads(fp.read_bytes());assert json.loads(info["features"])==["default","self-update"]
        stamp=fp.parent/"invoked.timestamp"; assert stamp.is_file() and (fp.parent/name).is_file()
        metadata=d/"out"/("libuv_cli-"+key+".rmeta"); deps=d/"out"/("uv_cli-"+key+".d")
        assert metadata.is_file() and (metadata.stat().st_size==0 if role=="test" else metadata.stat().st_size>16)
        assert 0<deps.stat().st_size<65536 and b"crates/uv-cli/src/lib.rs" in deps.read_bytes()
        values={p.name:sha(p)for p in [metadata,deps]} if content else {}
        result[role]=dict(key=key,features=json.loads(info["features"]),invoked_ns=stamp.stat().st_mtime_ns,metadata_bytes=metadata.stat().st_size,dep_info_bytes=deps.stat().st_size,products=values)
    assert len({r["key"]for r in result.values()})==2
    return result

def transition(a,b,changed):
    assert set(a)==set(b)=={"lib","test"}
    for role in a:
        x,y=a[role],b[role]
        assert x["key"]==y["key"] and x["features"]==y["features"]==["default","self-update"]
        assert y["invoked_ns"]>x["invoked_ns"] if changed else y==x

def query_values(raw):
    # Ohm's fixed-width DepNode header has an optional indexed footer. Ignore unstable serialization order.
    assert raw[:4]==b"RSIC" and raw.endswith(b"rust-end-file") and len(raw)<128<<20
    footer=len(raw)-len(b"rust-end-file")-24;maxidx,count,edges=struct.unpack_from("<3Q",raw,footer)
    assert 0<count<=maxidx<2_000_000
    stop=footer
    if raw[footer-8:footer]==b"OHMIDX01":
        stop,roots=struct.unpack_from("<2Q",raw,footer-24);assert stop+maxidx*8+roots*4==footer-24 and roots<=count
    at=7+raw[6]+8;assert 8<at<stop
    selected={134:{},137:{}};nedges=0;seen=bytearray(maxidx)
    for _ in range(count):
        assert at+38<=stop
        flags,i=struct.unpack_from("<HI",raw,at);kind=flags&511;assert i<maxidx and not seen[i] and kind>0;seen[i]=1
        if kind in selected:
            key=raw[at+6:at+22];assert key not in selected[kind]
            selected[kind][key]=raw[at+22:at+38]
        at+=38;n=(flags>>11)-1
        if n<0:
            n=0
            for shift in range(0,32,7):
                assert at<stop
                v=raw[at];at+=1;n|=(v&127)<<shift
                if v<128:break
            else:raise ValueError("invalid edge count")
        at+=n*(1+((flags>>9)&3));nedges+=n
    assert nedges==edges and at<=stop and all(selected.values())
    return {name:{"items":len(selected[k]),"sha256":hashlib.sha256(b"".join(a+v for a,v in sorted(selected[k].items()))).hexdigest()}for k,name in [(134,"typeck_root"),(137,"mir_borrowck")]}

def graphs(target):
    folders=sorted(target.glob("debug/incremental/uv_cli-*"));assert len(folders)==2
    found={}
    for d in folders:
        sessions=[s for s in d.glob("s-*")if not s.name.endswith("-working") and (s/"dep-graph.bin").is_file()]
        # Only the most recently published session is the current compiler result.
        from os import stat
        s=max(sessions,key=lambda p:p.name)
        g=s/"dep-graph.bin";assert (s/"query-cache.bin").is_file() and 0<g.stat().st_size<128<<20
        found[d.name]=query_values(g.read_bytes())
    return found
