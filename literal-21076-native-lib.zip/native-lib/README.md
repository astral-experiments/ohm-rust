# First native uv-cli build after uv #21076

Unzip this packet and run `python3 -ISB native-lib/verify.py` from any directory. The verifier needs Python 3.9+ and Git. It creates a temporary bare repository for the included Git objects. It needs no network, compiler or prior evidence packet.

The timed command was `cargo build --lib -p uv-cli --locked --offline -j8`. HEAD remained on the actual parent, `9f5808695af96f92daf680ded0ebe939869241ed`. Each observation applied the complete uncommitted two-file delta to `79ef389e39e3b21a5443b7ab25e890f33b0dadf9`. The Git pack authenticates the commit relation, both trees, the unchanged lockfile and each changed blob. It omits unrelated source objects. It supports evidence replay rather than a full build.

Each compiler started with a separate cold A history. Six triples covered every arm order once (seed 762100101). Each of the 18 edited measurements started from the corresponding restored A history, between a clean A no-op and a clean B no-op. Each cold setup also had a clean settling no-op. All arms used signed −18 Cargo. The matched-278-on compiler is a local untrained build. The signed −21 comparison includes the whole release compiler and standard library.

| Compiler | Median first edit |
| --- | ---: |
| Signed −18 | 2.956230 s |
| Local #278-on | 2.536424 s |
| Signed −21 | 2.379232 s |

The median paired ratios were 1.248850× for −18/−21, 1.166242× for −18/local-on and 1.056307× for local-on/−21. The six −18/−21 ratios ranged from 1.218886× to 1.272054×. Signed −21 was faster in all six. The preregistered 1.8× discovery gate did not open, so this native-library build has zero held-out observations. Other `cargo check` endpoints have their own results and are excluded here.

All 18 first edits compiled only uv-cli. After the clocks stopped, the producer linked and ran the literal Clap parser witness independently against each cold A and each of the 18 edited rlib/rmeta pairs. All 21 produced the exact registered A or B diagnostic. The A and B archives held 209 and 213 object members respectively. The multiset of whole object-content hashes shared 202 members on every pair. These archive results cannot establish which objects rustc regenerated.

`raw/` contains the original Cargo command, stdout/stderr and resource summaries, library stat and collateral manifests, plus the actual single-use native link and execution records and object-content maps. `provenance.json` binds the producer files before replacing the private witness path with the included `parser.rs`; it also identifies the released SDK manifests and original source packet. The large SDK, executable and object payloads remain represented by their recorded digests. The verifier replays every arm, the source and image identities, seeded order, parser output, exact paired ratios and decision from these records.
