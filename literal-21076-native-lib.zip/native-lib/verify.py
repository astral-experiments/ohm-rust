"""Replay the literal-parent #21076 native build discovery with Python 3 and Git."""
import hashlib
import itertools
import json
import os
import random
import re
import statistics
import subprocess
import tempfile
import zipfile
from collections import Counter
from pathlib import Path

D = Path(__file__).resolve().parent
A = "9f5808695af96f92daf680ded0ebe939869241ed"
B = "79ef389e39e3b21a5443b7ab25e890f33b0dadf9"
PATCH = "d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28"
CARGO = "02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
LLVM = "43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51"
REG = "b30a417c2e82a1188341f9729681979e56c76c1fbfa913a719b09a016a3752ef"
NAMES = {"stock":"signed18", "parent":"matched278-on", "candidate":"released21"}
DRIVERS = {"stock":"a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de",
           "parent":"5c7784b3fc4a1a2502e8a89ab7187effb27e31d0ece8510c09995e6c09d4c239",
           "candidate":"dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3"}
LAUNCHERS = {"stock":"c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60",
             "parent":"c930b062ca10b3f3da27804ac86e4e7a54f0213fe119ca1cc244c4ac04eea85c",
             "candidate":"f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9"}
CMD = ["/tmp/uv-workflow-search/sdk/bin/cargo","build","--lib","-p","uv-cli","--locked","--offline","-j8"]
ERROR = "error: invalid bump component `foo`"
USAGE = "\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())

def source(p):
    info = p["source"]
    assert [info["parent"], info["child"]] == [A, B]
    patch = (D/"edit.patch").read_bytes()
    assert sha(patch) == PATCH
    env = dict(PATH=os.environ["PATH"], LC_ALL="C", GIT_CONFIG_GLOBAL=os.devnull,
               GIT_CONFIG_NOSYSTEM="1", GIT_NO_LAZY_FETCH="1", GIT_ALLOW_PROTOCOL="file")
    with tempfile.TemporaryDirectory() as path:
        repo = Path(path)/"source.git"
        def git(*args, data=None):
            return subprocess.check_output(["git","--git-dir",str(repo),*args],input=data,env=env)
        git("init","--bare","--quiet")
        git("index-pack","--stdin",data=(D/"source.pack").read_bytes())
        assert git("rev-parse", B+"^").decode().strip() == A
        assert git("diff","--full-index","--binary","--no-renames","--no-ext-diff",A,B,"--") == patch
        assert set(info["files"]) == {"crates/uv-cli/src/lib.rs","crates/uv/tests/it/version.rs"}
        for i,rev in enumerate((A,B)):
            assert git("rev-parse",rev+"^{tree}").decode().strip() == info["tree"][i]
            assert git("rev-parse",rev+":Cargo.lock").decode().strip() == info["lock_oid"]
            assert sha(git("cat-file","blob",rev+":Cargo.lock")) == info["lock_sha256"]
            for name, ids in info["files"].items():
                assert git("rev-parse",rev+":"+name).decode().strip() == ids[i]

def command(z, name, expected=None, wall=None):
    meta = json.loads(z.read(name+".json"))
    assert meta["cmd"] == CMD and meta["wall_s"] > 0
    if wall is not None:
        assert meta["wall_s"] == wall
    stderr = z.read(name+".stderr")
    actual = re.findall(rb"^\s*(Checking|Compiling) ([\w-]+) v",stderr,re.M)
    if expected is None:
        assert meta["dirty_units"].count("uv_cli") == 1
        assert actual.count((b"Compiling",b"uv-cli")) == 1
    else:
        assert actual == ([(b"Compiling",b"uv-cli")] if expected else [])
        assert meta["dirty_units"] == expected
    assert b"Finished" in stderr and not z.read(name+".stdout")
    usage = json.loads(z.read(name+".usage.json"))
    assert usage["user_us"] + usage["sys_us"] > 0
    return json.loads(z.read(name+".product.json"))

def parser(result, role):
    states = ["A",*["B"+str(i) for i in range(1,7)]]
    assert result["driver_sha256"] == DRIVERS[role] and result["timing_rows"] == 0
    assert set(result["consumers"]) == set(result["samples"]) == set(result["observed"]) == set(states)
    assert set(result["groups"]) == set(result["samples"].values())
    reference = None
    overlaps = []
    for state in states:
        key = result["samples"][state]
        archive, metadata = key.split(":")
        q = result["consumers"][state]
        g = result["groups"][key]
        assert g["state"] == ("A" if state == "A" else "B")
        assert all(n.endswith(".o") and re.fullmatch("[0-9a-f]{64}",v) for n,v in g["objects"].items())
        objects = Counter(g["objects"].values())
        assert sum(objects.values()) == (209 if state == "A" else 213)
        if state == "A":
            reference = objects
        else:
            assert key != result["samples"]["A"]
            overlaps.append(sum((reference & objects).values()))
        assert g["archive_bytes"] == result["observed"][state]["rlib"][-1]
        assert q["archive_sha256"] == archive and q["metadata_sha256"] == metadata
        assert q["witness_sha256"] == sha((D/"parser.rs").read_bytes())
        assert all(re.fullmatch("[0-9a-f]{64}",x) for x in (archive,metadata,q["clap_sha256"],q["program_sha256"]))
        assert re.fullmatch("[0-9a-f]{16}",q["clap_fingerprint"])
        build,run = q["build"],q["run"]
        args = build["argv"]
        assert args[:5] == ["/tmp/uv-workflow-search/sdk/bin/rustc","--edition=2024","parser.rs","-C","debuginfo=0"]
        assert args[-2] == "-o" and args[-1].endswith("/native-witness-"+state+"/parser")
        assert run["argv"] == [args[-1]] and build["exit"] == run["exit"] == 0
        externs = [args[i+1] for i,v in enumerate(args) if v=="--extern"]
        assert [x for x in externs if x.startswith("uv_cli=")] == ["uv_cli="+q["archive"],"uv_cli="+str(Path(q["archive"]).with_suffix(".rmeta"))]
        assert ("/a-target/" in q["archive"]) if state=="A" else ("/native-holds/pair-"+state[1:]+"/" in q["archive"])
        assert any(x.startswith("clap=") and x.endswith(".rlib") for x in externs)
        assert run["stderr"] == "" and run["stdout"] == ERROR + ("" if state == "A" else USAGE)
    assert overlaps == [202]*6

def role_evidence(role, rows, p):
    arm = D/"raw"/role
    ident = read(arm/"identity.json")
    cfg = p["inputs"][role]
    ns = read(D/"worker-namespace.json")["arms"][role]
    assert cfg["cargo"] == ident["cargo"] == ns["cargo"] == CARGO
    assert cfg["launcher"] == ident["launcher"] == ns["launcher"] == LAUNCHERS[role]
    assert set(cfg["drivers"].values()) == ({DRIVERS["stock"],DRIVERS["parent"]} if role=="parent" else {DRIVERS[role]}) and ns["driver"] == DRIVERS[role]
    assert {x["sha256"] for x in ident["linked"].values()} == set(ns["loaded"].values()) == {DRIVERS[role],LLVM}
    if role != "candidate":
        assert cfg["sdk_cargo_before_overlay"] == CARGO
    else:
        assert cfg["sdk_cargo_before_overlay"] == p["release21"]["files"]["bin/cargo"]["sha256"]
    for tool in ("cargo","rustc"):
        assert (arm/(tool+".txt")).read_text().strip() == ns["versions"][tool].strip()
    log = (arm/"protocol.log").read_text().splitlines()
    reg = json.loads(log[0])
    assert reg["packages"] == 683 and reg["lock"] == p["source"]["lock_oid"]
    measured = [json.loads(x.removeprefix("UVPAIR ")) for x in log if x.startswith("UVPAIR ")]
    assert [x for x in measured if x["state"]=="measured"] == [r[role] for r in rows]
    result = read(arm/"timed-products.json")
    parser(result,role)
    with zipfile.ZipFile(arm/"setup.zip") as z:
        w = command(z,"warm")
        settled = command(z,"settled",[])
        assert w.pop("empty_target_before") is True and w==settled and w["unit"]==result["observed"]["A"]
    for i,row in enumerate(rows,1):
        clock = row[role]
        assert clock["state"]=="measured" and int(clock["trial"])==i and clock["dirty"]==["uv_cli"]
        with zipfile.ZipFile(arm/f"pair-{i}.zip") as z:
            a=command(z,"settled-A",[],clock["parent_noop"])
            b=command(z,"edit-D",["uv_cli"],clock["edit"])
            n=command(z,"noop-D",[],clock["noop"])
        assert a["other"]==b["other"]==n["other"] and a["other"]["count"]>100 and a["other"]["uv_cli_build_script_files"]>0
        assert a["unit"]["path"]==b["unit"]["path"]==w["unit"]["path"]
        assert all(a["unit"][k][2:]==w["unit"][k][2:] for k in ("rlib","rmeta"))
        assert a["unit"]["rlib"]!=b["unit"]["rlib"] and b==n and b["unit"]==result["observed"][f"B{i}"]

def verify():
    if not __debug__:
        raise ValueError("Python assertions must be enabled")
    entries=read(D/"files.json")
    assert set(entries)=={p.relative_to(D).as_posix() for p in D.rglob("*") if p.is_file() and p!=D/"files.json"}
    for name,val in entries.items():
        f=D/name
        assert not f.is_symlink() and sha(f.read_bytes()) == val,name
    p=read(D/"provenance.json")
    assert p["registration_sha256"]==REG and p["roles"]==NAMES and p["threshold"]==1.8
    assert p["seed"]==762100101 and p["scope"]=="literal21076-native-lib" and p["actual_heldout_triples"]==0
    assert p["source_packet"]=="86e9a725b263e6c777ff7bfe8738f96bbd81a1af6b584a121af755571c9b8773"
    assert sha((D/"worker-namespace.json").read_bytes())=="01b87f69042b31721f5d45ad0ff86c46bf1dba747b891256b736dbd7582f4343"
    release=p["release21"]
    assert release["source"]=="c79998a5cd143c445a4b2528f20953b176a65c5d" and release["tag"]=="ohm-1.99.0-21"
    assert release["archive"]=={"bytes":359657153,"sha256":"6f550de85f95440a61b5bd1a9d2ab0528d4fcaf674fdc008f5e986d2138be6c4"}
    assert len(release["files"])==67 and release["files"]["bin/rustc"]["sha256"]==LAUNCHERS["candidate"]
    assert release["files"]["bin/cargo"]["sha256"]=="4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e"
    source(p)
    rows=[json.loads(line) for line in (D/"raw/pairs.jsonl").read_text().splitlines()]
    seq=list(itertools.permutations(sorted(NAMES)))
    random.Random(p["seed"]).shuffle(seq)
    assert len(rows)==6 and list(map(list,seq)) == p["sequence"] == [list(row) for row in rows]
    for role in NAMES:
        role_evidence(role,rows,p)
    def ratios(left,right):
        if right=="parent":
            return [(r[left]["edit"]/r["candidate"]["edit"])/(r[right]["edit"]/r["candidate"]["edit"]) for r in rows]
        return [r[left]["edit"]/r[right]["edit"] for r in rows]
    ratios_by_name={NAMES[a]+"/"+NAMES[b]:ratios(a,b) for a,b in (("stock","parent"),("stock","candidate"),("parent","candidate"))}
    medians={k:statistics.median(v) for k,v in ratios_by_name.items()}
    direct=ratios_by_name["signed18/released21"]
    assert statistics.median(direct)<p["threshold"]
    return dict(ordinary_first_edits=18,paired_clean_noops=36,cold_histories=3,cold_settled_noops=3,
                parser_links_and_runs=21,discovery_triples=6,heldout_triples=0,discovery_gate=p["threshold"],
                opens_confirmation=False,median_seconds={name:statistics.median(r[role]["edit"] for r in rows) for role,name in NAMES.items()},
                paired_medians=medians,paired_ratios=ratios_by_name,direct_range=[min(direct),max(direct)],
                direct_faster=sum(x>1 for x in direct),direct_at_least_twice=sum(x>=2 for x in direct),
                objects_per_A=209,objects_per_B=213,equal_content_multiset_per_pair=202)

if __name__=="__main__":
    print(json.dumps(verify(),indent=2))
