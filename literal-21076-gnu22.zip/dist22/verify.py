"""Independently replay each recorded literal edit, then reproduce the preregistered score."""
import hashlib,itertools,json,math,os,random,re,statistics,subprocess,sys,tempfile,zipfile
from pathlib import Path
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
gitid=lambda k,b:hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
med=statistics.median
ROLES={'stock':'signed18','parent':'signed21','candidate':'gnu-job22'}
PARSER={'stock':'stock18','parent':'release21','candidate':'package22'}
CARGO='02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573'
PACKAGE_CARGO={'stock':CARGO,'parent':'4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e','candidate':'df35740ab292c3654e0dac2728c3814e4c4c033c266adc4f5ef4f78856320229'}
DRIVERS={'stock':'a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de','parent':'dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3','candidate':'07a3122d625927e970985f6e74d377cbed179476790e8ff3c0401dcd2b165701'}
LAUNCHERS={'stock':'c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60','parent':'f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9','candidate':'f5af460932d42f5d91578f0ec17a6c27e721892b46c4901e85bcfe30a0b9bde1'}
LLVM='43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51'
PATCH='d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28'
A='9f5808695af96f92daf680ded0ebe939869241ed';B='79ef389e39e3b21a5443b7ab25e890f33b0dadf9'
PH=('discovery','confirm-1','confirm-2')
CMD=['/tmp/uv-workflow-search/sdk/bin/cargo','check','-p','uv-cli','--locked','--offline','-j8']
CONTRAST=[('stock','parent','signed18/signed21'),('stock','candidate','signed18/gnu-job22'),('parent','candidate','signed21/gnu-job22')]
SUFFIXES=('.json','.primary.json','.stderr','.stdout','.usage.json')
REG='105e4008df3e5bd1ce755b9e0613bba173ba88c407ff3d16a3ad7ed85933985a'
SCORE='912cc336dd5c1f6e8c46b2e15a8ba036ff88bd0ff6ed0017e8fa71c6cfc1d830'


def archive(z,states):
    names={state+s for state in states for s in SUFFIXES}
    assert set(z.namelist())==names and len(z.infolist())==len(names) and all(i.file_size<300000 for i in z.infolist())
    assert z.testzip() is None

def command(z,name,dirty,wall=None):
    record=json.loads(z.read(name+'.json'));err=z.read(name+'.stderr')
    assert record['cmd']==CMD and record['wall_s']>0
    if wall is not None:assert record['wall_s']==wall
    work=re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)
    if dirty is None:assert record['dirty_units'].count('uv_cli')==work.count(b'uv-cli')==1
    else:assert record['dirty_units']==dirty and work==([b'uv-cli'] if dirty else [])
    usage=json.loads(z.read(name+'.usage.json'));assert usage['user_us']+usage['sys_us']>0
    assert b'Finished' in err and z.read(name+'.stdout')==b''
    return json.loads(z.read(name+'.primary.json'))

def source():
    s=read(D/"uv-source.json");assert (s["parent"],s["child"])==(A,B)
    delta=(D/"edit.patch").read_bytes();assert sha(delta)==PATCH
    assert set(s["files"])=={"crates/uv-cli/src/lib.rs","crates/uv/tests/it/version.rs"}
    env={"PATH":os.environ["PATH"],"LC_ALL":"C","GIT_CONFIG_GLOBAL":os.devnull,"GIT_CONFIG_NOSYSTEM":"1","GIT_NO_LAZY_FETCH":"1","GIT_ALLOW_PROTOCOL":"file"}
    with tempfile.TemporaryDirectory()as tmp:
        repo=Path(tmp)/"repo"
        def git(*args,data=None):return subprocess.check_output(["git","--git-dir",repo,*args],input=data,env=env)
        git("init","--quiet","--bare");git("index-pack","--stdin",data=(D/"source.pack").read_bytes())
        assert git("rev-parse",B+"^").decode().strip()==A
        assert git("diff","--full-index","--binary","--no-renames","--no-ext-diff",A,B,"--")==delta
        for ix,rev in enumerate((A,B)):
            assert git("rev-parse",rev+"^{tree}").decode().strip()==s["tree"][ix]
            assert git("rev-parse",rev+":Cargo.lock").decode().strip()==s["lock_oid"]
            assert sha(git("cat-file","blob",rev+":Cargo.lock"))==s["lock_sha256"]
            for f,ids in s["files"].items():assert git("rev-parse",rev+":"+f).decode().strip()==ids[ix]

def check_parser(role):
    files=D/'parser'/role
    rows=[]
    for state in ('A','B'):
        a=read(files/(state+'-behavior.json'));g=read(files/(state+'-build.json'))
        assert (a['source'],a['arm'],a['compiler_sha256'],a['fresh_empty_cargo_target'],a['expected_clap_exit'])==(state,PARSER[role],DRIVERS[role],True,2)
        assert a['witness_source']==sha((D/'parser.rs').read_bytes())
        expected='error: invalid bump component `foo`'+('' if state=='A' else "\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n")
        assert a['diagnostic']==expected and g['exit']==0 and g['argv'][1:]==['build','--locked','--offline','-j8','-p','uv-cli','--lib']
        assert g['elapsed_ns']==g['end_ns']-g['start_ns']>0
        if role!='stock':
            b=(files/(state+'-build.cargo.log')).read_bytes();assert len(b)==g['bytes'] and sha(b)==g['stdout_sha256']
        rows.append((a,g))
    assert all(rows[0][0][k]!=rows[1][0][k]for k in ('libuv_cli_sha256','program_sha256'))
    if role!='stock':assert rows[0][1]['end_ns']<=rows[1][1]['start_ns']

def stats(cohorts):
    def ratio(row,a,b):
        # Preserve the registered registered two-ratio arithmetic, including its division order.
        return (row[a]['edit']/row['candidate']['edit'])/(row[b]['edit']/row['candidate']['edit']) if b=='parent' else row[a]['edit']/row[b]['edit']
    def phases(rows):
        return {v:med(r[k]['edit']for r in rows) for k,v in ROLES.items()}
    d=cohorts[0];h=cohorts[1:];allh=h[0]+h[1];result={}
    for a,b,label in CONTRAST:
        t=1 if a=='parent' else 2;alpha=.05 if t==1 else .025
        v=[ratio(r,a,b)for r in allh];ordered=sorted(v);i=max(k for k in range(6)if 2*sum(math.comb(12,j)for j in range(k+1))/4096<=alpha)
        interval=[ordered[i],ordered[-1-i]];seeds=[med(ratio(r,a,b)for r in h1)for h1 in h];strata=[[x for x,r in zip(v,allh)if (list(r).index(a)<list(r).index(b))==first]for first in (False,True)]
        assert list(map(len,strata))==[6,6]
        by_order=list(map(med,strata));v2=[x for x in v if x!=t];n=len(v2);high=sum(x>t for x in v2);pv=sum(math.comb(n,j)for j in range(high,n+1))/2**n
        result[label]=dict(median=med(v),interval=interval,p=pv,threshold=t,seed_medians=seeds,order_medians=by_order,passed=interval[0]>t and pv<alpha and min(seeds+by_order)>t)
    disc={label:med(ratio(r,a,b)for r in d)for a,b,label in CONTRAST}
    assert disc['signed18/gnu-job22']>=1.8
    return dict(excluded_triples=6,opens_confirmation=True,discovery=disc,discovery_seconds=phases(d),heldout_triples=12,heldout_seconds=phases(allh),contrasts=result,primary_direct_2x=result['signed18/gnu-job22']['passed'])

def phase(p,idx,smoke,source):
    plan=read(p/'plan.json');rows=[json.loads(s)for s in (p/'pairs.jsonl').read_bytes().splitlines()];seq=list(itertools.permutations(sorted(ROLES)));random.Random(2241210761+idx).shuffle(seq)
    assert plan['config']['seed']==2241210761+idx and plan['config']['pairs']==6 and plan['config']['case']=='literal21076-cli' and plan['config']['plain'] and not plan['config']['diagnostics']
    assert plan['source']==source and plan['sequence']==list(map(list,seq))==[list(r)for r in rows] and len(rows)==6
    for role in ROLES:
        arm=p/role;ident=read(arm/'identity.json');meta=read(arm/'metadata.json');cfg=plan['inputs'][role]
        assert cfg['cargo']==ident['cargo']==CARGO and cfg['launcher']==ident['launcher']==LAUNCHERS[role]
        assert cfg['sdk_cargo_before_overlay']==PACKAGE_CARGO[role] and DRIVERS[role]in cfg['drivers'].values()
        assert {v['sha256']for v in ident['linked'].values()}=={DRIVERS[role],LLVM}
        assert set(meta)=={'A','B'} and all(re.fullmatch('[0-9a-f]{64}',v['sha256'])for v in meta.values()) and meta['A']['sha256']!=meta['B']['sha256']
        assert (arm/'cargo.txt').read_text().strip()==smoke[role]['versions']['cargo'].strip() and (arm/'rustc.txt').read_text().strip()==smoke[role]['versions']['rustc'].strip()
        log=(arm/'protocol.log').read_text().splitlines();reg=json.loads(log[0]);assert reg['packages']==683 and reg['lock']=='c1601688714997cf9380248c63a6bbb32537224d'
        msgs=[json.loads(s[7:])for s in log if s.startswith('UVPAIR ')]
        assert msgs==[{'state':'ready','patch':PATCH}]+[r[role]for r in rows]
        with zipfile.ZipFile(arm/'setup.zip')as z:
            archive(z,('warm','settled'));command(z,'warm',None);command(z,'settled',[]);warm=json.loads(z.read('warm.json'));settled=json.loads(z.read('settled.json'))
            assert warm['cmd']==settled['cmd']==CMD and 'uv_cli'in warm['dirty_units'] and settled['dirty_units']==[]
        for i,r in enumerate(rows,1):
            assert r[role]['state']=='measured'and r[role]['trial']==str(i)and r[role]['dirty']==['uv_cli']
            with zipfile.ZipFile(arm/f'pair-{i}.zip')as z:
                archive(z,('settled-A','edit-D','noop-D'));prim={}
                for n,k,dirty in [('settled-A','parent_noop',[]),('edit-D','edit',['uv_cli']),('noop-D','noop',[])]:
                    rec=json.loads(z.read(n+'.json'));err=z.read(n+'.stderr')
                    assert rec['cmd']==CMD and rec['dirty_units']==dirty and rec['wall_s']==r[role][k]>0
                    assert re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)==([b'uv-cli']if dirty else []) and b'Finished'in err and not z.read(n+'.stdout')
                    usage=json.loads(z.read(n+'.usage.json'));assert usage['user_us']+usage['sys_us']>0
                    prim[n]=json.loads(z.read(n+'.primary.json'))
                a,b,c=[prim[n] for n in ('settled-A','edit-D','noop-D')];assert a['name']==b['name'] and a!=b==c
                if i==6:assert b=={k:v for k,v in meta['B'].items()if k!='sha256'}
    return rows

def sources():
    c=D/'compiler';roots=read(c/'roots.json');changed=read(c/'changed.json')
    def entries(label,owner):
        r=read(c/(label+'-'+owner+'.json'));assert not r['truncated']
        return r,{x['path']:x['sha']for x in r['entries']}
    a,b='r21','r22'
    assert [roots[q]['commit']for q in (a,b)]==['c79998a5cd143c445a4b2528f20953b176a65c5d','556a8364f1485a03be31b1a50c250d63198a943d']
    trees=lambda q:{x['path']:x['sha']for x in roots[q]['roots']}
    assert trees(a)['library']==trees(b)['library']
    owners={'codegen-llvm':'rustc_codegen_llvm','codegen-ssa':'rustc_codegen_ssa','middle':'rustc_middle','interface':'rustc_interface'}
    x,xt=entries(a,'compiler');y,yt=entries(b,'compiler')
    assert x['sha']==trees(a)['compiler'] and y['sha']==trees(b)['compiler']
    assert set(xt)==set(yt) and {k for k in xt if xt[k]!=yt[k]}==set(owners.values())
    def tree(name):
        raw=(c/(name+'.tree')).read_bytes();assert gitid('tree',raw)==name;out={}
        while raw:
            label,raw=raw.split(b'\0',1);mode,path=label.decode().split(' ',1);out[path]=(mode,raw[:20].hex());raw=raw[20:]
        return out
    resolve=xt['rustc_resolve'];src=tree(resolve)['src'][1];blobs=tree(src)
    pr=read(c/'pr278-production.json');assert {v['filename'].split('/')[-1]:v['sha']for v in pr}=={'lib.rs':'df7ebac84557230b4a67f315f80331350f5791c4','macros.rs':'4515937b4b0cc73f0a84a5bc5d409cf7c160237d'}
    assert all(blobs[v['filename'].split('/')[-1]]==('100644',v['sha']) for v in pr)
    paths=[]
    for owner,full in owners.items():
        oa,at=entries(a,owner);ob,bt=entries(b,owner);assert (oa['sha'],ob['sha'])==(xt[full],yt[full])
        assert set(at)==set(bt)
        diff={k for k in at if at[k]!=bt[k] and all(i['mode']=='100644' for i in (next(i for i in oa['entries'] if i['path']==k),next(i for i in ob['entries'] if i['path']==k)))}
        assert diff==set(changed[owner])
        for key in diff:
            for q,bb in [(a,at),(b,bt)]:
                file=c/(q+'-'+owner+'-'+Path(key).name)
                assert gitid('blob',file.read_bytes())==bb[key]==changed[owner][key][int(q==b)][1]
            paths.append('compiler/'+full+'/'+key)
    assert len(paths)==6
    return sorted(paths)

def official():
    d=D/'asset';w=read(d/'workflow.json');man=read(d/'coordinator-manifest.json');prov=read(d/'member-provenance.json');s=read(d/'distribution.json');act=read(d/'return.json')
    assert (w['run']['id'],w['job']['id'],w['job']['run_attempt'],w['job']['conclusion'],w['artifact']['id'])==(41237680370,124644935360,1,'success',13057710231)
    assert w['artifact']['workflow_run']['id']==w['run']['id'] and w['artifact']['workflow_run']['head_sha']==w['run']['head_sha']==w['job']['head_sha']==prov['coordinator']['revision']=='007da57ba792129adb5754546e1158e7e6d732b7'
    assert w['artifact']['digest']=='sha256:'+s['zip_sha256']=='sha256:bb270473af5d365049ce2ca2e02eba9c628722510cd4c758e684ca256dffede9' and w['artifact']['size_in_bytes']==356746335
    assert (d/'member-tar.sha256').read_text().split()[0]==s['tar_sha256']=='68ee7aa1405b0bf7c676f0778862ed27449c9d010a9064ec6e8bc313a2ad78f5'
    assert prov['manifest']['sha256']==sha((d/'coordinator-manifest.json').read_bytes()) and prov['toolchain']=='ohm-1.99.0-22' and prov['target']=='x86_64-unknown-linux-gnu'
    assert s['source']==man['sources']['rust']['revision']==prov['sources']['rust']['revision']=='556a8364f1485a03be31b1a50c250d63198a943d'
    assert act['code']==0 and act['accepted_sha256']=='68c3ba03671dce497e500fb14d151a1db337f2f688b071110e8dd72db5c87565' and s['elf_bolt_section'] and s['cargo_executions']==0
    old=read(d/'release21.json');files=s['files'];assert len(old['files'])==len(files)==67
    assert (old['source'],old['tag'])==('c79998a5cd143c445a4b2528f20953b176a65c5d','ohm-1.99.0-21')
    for role,manifest in [('candidate',files),('parent',old['files'])]:
        assert manifest['bin/cargo']['sha256']==PACKAGE_CARGO[role] and manifest['bin/rustc']['sha256']==LAUNCHERS[role]
        assert [v['sha256']for n,v in manifest.items()if n.startswith('lib/librustc_driver-')]==[DRIVERS[role]]
    same=sorted(n for n,v in files.items()if old['files'].get(n,{}).get('sha256')==v['sha256'])
    assert len(same)==5 and same==read(d/'sdk-comparison.json')['package_files_identical_at_same_path_to_21']

def verify():
    assert __debug__
    files=read(D/'files.json');assert set(files)=={str(p.relative_to(D))for p in D.rglob('*')if p.is_file()and p!=D/'files.json'}
    assert all(not (D/n).is_symlink() and sha((D/n).read_bytes())==v for n,v in files.items())
    p=read(D/'custody.json');assert p['registration']==REG and p['score']==sha((D/'heldout-score.json').read_bytes())==SCORE
    smoke=read(D/'worker-namespace.json');assert p['smoke']==sha((D/'worker-namespace.json').read_bytes())=='71087440ddf31336352b19189b38a8c70e0c86c1b802c0c88301b84066e9ec23' and smoke['registration']==REG
    assert len({x['versions']['cargo']for x in smoke['arms'].values()})==1
    for role in ROLES:
        r=smoke['arms'][role];assert (r['driver'],r['launcher'],r['cargo'],r['timing_rows'])==(DRIVERS[role],LAUNCHERS[role],CARGO,0)and set(r['loaded'].values())=={DRIVERS[role],LLVM}
        check_parser(role)
    source();official();changes=sources()
    h=[phase(D/ph,i,smoke['arms'],[A,B])for i,ph in enumerate(PH)];result=stats(h);assert result==read(D/'heldout-score.json')
    wins={}
    for a,b,name in CONTRAST:
        ratios=[r[a]['edit']/r[b]['edit']for cohort in h[1:] for r in cohort];wins[name]={'above_one':sum(v>1 for v in ratios),'above_two':sum(v>2 for v in ratios)}
    return {'score':result,'heldout_pair_counts':wins,'ordinary_first_edits':54,'renewed_uv_cli_rmeta':54,'clean_immediate_A_B_noops':108,'cold_A_seeds':9,'fresh_package22_parser_cases':2,'exact_reused_parser_cases':4,'compiler_source_changes':changes}
if __name__=='__main__':print(json.dumps(verify(),indent=2))
