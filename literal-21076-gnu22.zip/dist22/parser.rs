use clap::Parser;
use std::io::{self, Write};

fn main() {
    let result = uv_cli::Cli::try_parse_from(["uv", "version", "--bump", "foo"]);
    let Err(error) = result else {
        panic!("accepted an invalid version bump");
    };
    assert_eq!(error.exit_code(), 2);
    let message = error.to_string();
    assert!(message.contains("invalid bump component `foo`"));
    io::stdout().write_all(message.as_bytes()).unwrap();
}
