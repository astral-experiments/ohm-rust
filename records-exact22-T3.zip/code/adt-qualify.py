"""A third exact PR-base native role, using the original stage1 and run-make qualification."""
import importlib.util
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys
from types import FunctionType,SimpleNamespace

D=Path(__file__).resolve().parent
R=D.parent;OLD=R/"review-pr-base-qa/native-qa";REVIEW=R/"review-adt-1.99-22";CK=REVIEW/"checkout"
def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
q=module("unaltered_R22_native",OLD/"qualify.py");b=q.b;need=q.need;read=q.read;sha=q.sha
REG=D/"registration.json";MAP=D/"source-map.json"
T1="2c57d173a7da0d8f41f1582a336d9b99f1294c66";HEAD="b4889f3a1a81e3d32e458ad2143df066f332da66";TREE="67de93bb7a0b51d18d3b271da0fc4b381d053213"
GROUP=b.BANK/"trait-rosters-pr22-adt-native-001"
STAGES=[([], "3 3"), (["unrelated"],"3 3"), (["unrelated","matching"],"7 3"), (["unrelated","moved"],"3 7"),
        (["unrelated"],"3 3"), (["unrelated","moved"],"3 7"), (["unrelated","retired"],"3 3")]


def source():
    from subprocess import check_output
    def git(*a):return check_output(["git","--no-lazy-fetch","-C",CK,*a],env=os.environ|{"GIT_NO_LAZY_FETCH":"1","GIT_OPTIONAL_LOCKS":"0"})
    need(git("rev-parse","HEAD","HEAD^","HEAD^{tree}").decode().splitlines()==[HEAD,T1,TREE],"exact T3 checkout/ancestry")
    need(git("rev-parse","--path-format=absolute","--git-common-dir").decode().strip()==str(CK/".git") and not git("status","--porcelain"),"private, clean source")
    paths=git("diff","--name-only",q.p.ROLE["base"],HEAD).decode().splitlines()
    need(len(paths)==11 and sum(p.startswith("tests/run-make/trait-impl-bucket-projection/")for p in paths)==3,"complete cumulative sources")
    files={p:{name:git("rev-parse",rev+":"+p).decode().strip() for name,rev in (("T1",T1),("T3",HEAD))}for p in paths}
    for p,r in files.items():need(q.p.Z((CK/p).read_bytes())==r["T3"],"working source "+p)
    support=read(OLD/"registration.json")["frozen_support"]["support_git_objects"]
    for p,want in support.items():
        need(git("ls-tree",HEAD,"--",p).decode().split()[2]==want,"unchanged T3 support "+p)
    return dict(commit=HEAD,tree=TREE,parent=T1,parent_tree=q.p.TREE["candidate"],release=q.p.ROLE["base"],
        files=files,support=support,stack_sha256=sha(REVIEW/"stack.patch"),cumulative_sha256=sha(REVIEW/"against-22.patch"))


def check_reg():
    e=read(REG)
    original=read(OLD/"registration.json")
    need(sha(OLD/"registration.json")=="be8221f56ba7ad3fa29a628ebedb978d79472be9a3112fae2a0ac69d7b85ac3c" and
        all(sha(OLD/n)==h for n,h in original["sources_sha256"].items()) and
        all(sha(D/n)==h for n,h in e["files"].items()) and original["host_native_sha256"]==e["host_native_sha256"],"third source and original QA registrations")
    need(e["stages"]==[[c,x]for c,x in STAGES] and read(MAP)["tree"]==TREE,"the reviewed seven revisions")
    return e


def audit():
    check_reg();previous=q.source_audit();need(read(MAP)==source(),"canonical tree overlay")
    need(sha(REVIEW/"verified.json")=="b0a2ca7bea728bd4792536aefd831daa5ccbb93ee56df875c6976d6a5cad99f2","deterministic native-source equivalence")
    return {"original":previous,"source":read(MAP),"third_registration":sha(REG),"storage":str(GROUP/"candidate"),"native_launched":False}


def verify_heads(src,role,fixture):
    need(role=="candidate" and fixture,"standalone T3 emitted only after its full source and fixture are installed")
    for p,r in read(MAP)["files"].items():q.p.check_file(src/p,"100644",r["T3"])


def stack(src,out):
    need(not (out/"T1-source-input.json").exists(),"new source interval")
    prior=read(out/"release-source.json")
    need(prior["commit"]==T1 and prior["tree"]==q.p.TREE["candidate"] and prior["fixture_present_before_compile"],"genuine T1 source precondition")
    for n,r in read(MAP)["files"].items():q.p.check_file(src/n,"100644",r["T1"])
    (out/"release-source.json").rename(out/"T1-source-input.json")
    for name,flags in [("check",["--check"]),("apply",[])]:
        b.native(["git","apply","--whitespace=error-all",*flags,str(REVIEW/"stack.patch")],src,out/("T3-"+name+".log"))
    verify_heads(src,"candidate",True)
    b.put(out/"release-source.json",{**prior,"role":"candidate","commit":HEAD,"tree":TREE,
        "T1_source_intake_sha256":sha(out/"T1-source-input.json"),"T1_to_T3":read(MAP)["files"],"T1_to_T3_patch_sha256":sha(REVIEW/"stack.patch"),
        "authentic_cumulative_patch_sha256":sha(REVIEW/"against-22.patch"),"fixture_present_before_compile":True})


def prepare(role,out):
    need(role=="candidate","T3 operator cannot issue another original role")
    q.p.prepare("candidate",out)
    stack(b.SRC,out)


def finish(events,wrap,driver,llvm):
    events.sort();need(wrap==1 and len(events)==5*len(STAGES),"the complete 21-rustc and 14-run seven-revision trace")
    runs=[];i=0
    for stage,(cfg,expected)in enumerate(STAGES):
        _,op,pid,src,args=events[i];i+=1
        actual=[args[j+1]if v=="--cfg"else v.split("=",1)[1]for j,v in enumerate(args)if v=="--cfg" or v.startswith("--cfg=")]
        need((op,src)==("rustc","roster.rs") and actual==cfg,"real producer revision flags")
        for solver in ("default","next"):
            _,op,compiler,src,args=events[i];_,ran,program,val,_=events[i+1];i+=2
            need((op,src,ran)==("rustc","reader.rs","run") and val==expected+"\n" and
                 ("-Znext-solver" in args)==(solver=="next") and "-Zincremental-verify-ich" in args and
                 any("incremental="+solver in arg for arg in args) and any("roster=" in a for a in args),
                 "actual solver, linked roster, persistent cache and selected program output")
            runs.append(dict(stage=stage,cfg=cfg,solver=solver,producer_pid=pid,rustc_pid=compiler,program_pid=program,stdout=val,argv=args))
    need(len({x["rustc_pid"]for x in runs})==14 and len({x["producer_pid"]for x in runs})==7 and
         len({x["program_pid"]for x in runs})==14,"distinct genuine fixture children")
    return dict(executed_readers=runs,compiler_executions=21,executable_runs=14,observed_roster_revisions=7,
                mapped_driver=driver,mapped_llvm=llvm,stdout_by_solver={s:[r["stdout"]for r in runs if r["solver"]==s]for s in ("default","next")})


def decoder():
    src=inspect.getsource(q.tr.decode);cut='    events.sort();need(wrap==1 and len(events)==20,'
    need(src.count(cut)==1,"reuse the original trace lexer, process, exit and both image checks")
    env=dict(vars(q.tr),finish=finish)
    exec(compile(src[:src.index(cut)]+"    return finish(events,wrap,driver,llvm)\n",str(OLD/"trace.py")+"#T3-seven-revisions","exec"),env)
    return env["decode"]


def kernel():
    p=SimpleNamespace(**vars(q.p));p.ROLE={"candidate":HEAD};p.TREE={"candidate":TREE}
    p.GROUP=GROUP;p.prepare=prepare;p.verify_heads=verify_heads
    ctx=dict(vars(q),HERE=D,REG=REG,p=p,REG_OUT=lambda role:D/"t3-native.zip",tr=SimpleNamespace(decode=decoder()),
             check_reg=check_reg,source_audit=audit)
    for n in ("budget","check_host","replay","worker","launch","accepted","main"):
        f=getattr(q,n);ctx[n]=FunctionType(f.__code__,ctx,f.__name__,f.__defaults__,f.__closure__)
    original=ctx["accepted"]
    def accepted(role,deep=True):
        got=original(role,deep);out=GROUP/role;src=read(out/"release-source.json")
        need(src["T1_to_T3"]==read(MAP)["files"] and src["T1_source_intake_sha256"]==sha(out/"T1-source-input.json")
             and src["T1_to_T3_patch_sha256"]==read(MAP)["stack_sha256"] and read(out/"T1-source-input.json")["commit"]==T1,
             "actual complete T1 precursor and T3 source overlay")
        for name,flags in [("check",["--check"]),("apply",[])]:
            cmd=read(out/("T3-"+name+".command.json"))
            need(cmd["exit"]==0 and cmd["argv"]==["git","apply","--whitespace=error-all",*flags,str(REVIEW/"stack.patch")],"actual T3 "+name)
        need(got["solver_stdout"]=={s:[x+"\n" for _,x in STAGES]for s in ("default","next")},"both actual seven-stage outputs")
        return got
    ctx["accepted"]=accepted
    return ctx


if __name__=="__main__":
    args=sys.argv[1:]
    if args==["audit"]:result=audit()
    elif args==["preflight"]:result=kernel()["main"](args)
    elif args in (["run","t3"],["closed","t3"]):result=kernel()["main"]([args[0],"candidate"])
    elif args==["worker","candidate"]:check_reg();result=kernel()["main"](args)
    else:raise ValueError("audit | preflight | run t3 | closed t3")
    print(json.dumps(result,sort_keys=True))
