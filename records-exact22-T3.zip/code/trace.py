"""Read the unmodified run-make binary's real rustc, mapped DSOs and reader stdout."""
import ast
import hashlib
import io
from pathlib import Path
import re
import zipfile

Q=r'"(?:\\.|[^"\\])*"'
EXEC=re.compile(r'^(\d+\.\d+) execve\(('+Q+r'), (\[.*?\]), .* = 0$')
STAMP=r'^\d+\.\d+ '
WRITE=re.compile(STAMP+r'write\(1(?:<.*?>)?, ('+Q+r'), (\d+)\)\s+= (\d+)$')
WRITEV=re.compile(STAMP+r'writev\(1(?:<.*?>)?, \[(.*)\], \d+\)\s+= (\d+)$')
IOV=re.compile(r'iov_base=('+Q+r'), iov_len=(\d+)')
MMAP=re.compile(r'\bmmap\(.*?\bPROT_EXEC\b.*?, \d+<(/[^>]+)>, [^)]*\)\s+= 0x[0-9a-f]+')
OUTS=['3\n','3\n','7\n','3\n']
def need(ok,scope):
    if not ok:raise ValueError(scope)
def textbytes(q):return ast.literal_eval("b"+q)
def decode(archive,rustc,reader,rmake,driver,llvm):
    events=[];programs=[];wrap=0
    with zipfile.ZipFile(archive) as z:
        names=z.namelist();need(len(names)==len(set(names)) and all(re.fullmatch(r"trace\.\d+",n) for n in names)
                                and sum(i.file_size for i in z.infolist())<=64<<20,"raw trace set")
        for name in names:
            lines=z.read(name).decode(errors='strict').splitlines();execs=[]
            for line in lines:
                m=EXEC.match(line)
                if m:execs.append((m[1],ast.literal_eval(m[2]),m[3]))
            if not execs:continue
            roles=[(ts,exe,av) for ts,exe,av in execs if exe in (rustc,reader,rmake)]
            if not roles:continue
            need(len(roles)==1 and len(execs)==1,"unexpected executable chain")
            ts,exe,raw=roles[0];args=ast.literal_eval(raw);pid=int(name.split(".")[1])
            need(args[0]==exe and any(re.search(r'\bexit_group\(0\)',q) or '+++ exited with 0 +++' in q for q in lines),"fixture process/exit")
            if exe==rmake:wrap+=1;continue
            if exe==rustc:
                needed=[n for n in ('roster.rs','reader.rs') if n in args]
                need(len(needed)==1,"original producer/consumer argv")
                dsos={m[1] for line in lines if (m:=MMAP.search(line)) and re.match(r'(?:libLLVM|librustc_driver-)',Path(m[1]).name)}
                need(dsos=={driver,llvm},"actual mapped executable DSO paths: "+repr(dsos))
                events.append((ts,'rustc',pid,needed[0],args))
            else:
                data=b''
                for line in lines:
                    if m:=WRITE.match(line):
                        v=textbytes(m[1]);need(len(v)==int(m[2])==int(m[3]),"partial/ambiguous write");data+=v
                    elif m:=WRITEV.match(line):
                        chunks=[textbytes(k) for k,n in IOV.findall(m[1]) if len(textbytes(k))==int(n)]
                        need(sum(map(len,chunks))==int(m[2]),"partial/ambiguous vector write");data+=b''.join(chunks)
                events.append((ts,'run',pid,data.decode(),args))
    events.sort();need(wrap==1 and len(events)==20,"four producers, eight real consumers, eight executed programs")
    index=0
    for stage,(unrelated,matching) in enumerate([(False,False),(True,False),(True,True),(True,False)]):
        _,op,pid,src,args=events[index];index+=1
        need((op,src)==('rustc','roster.rs') and ('unrelated' in args)==unrelated and ('matching' in args)==matching,"real upstream cfg/argv")
        for solver in ('default','next'):
            _,op,cpid,src,args=events[index];_,run,rpid,value,rargs=events[index+1];index+=2
            need((op,src,run)==('rustc','reader.rs','run') and value==OUTS[stage] and (('-Znext-solver' in args)==(solver=='next'))
                 and '-Zincremental-verify-ich' in args and any('incremental='+solver in a for a in args),"actual solver/cache/program stdout")
            programs.append(dict(stage=stage,solver=solver,producer_pid=pid,rustc_pid=cpid,program_pid=rpid,stdout=value,argv=args))
    return dict(executed_readers=programs,compiler_executions=12,executable_runs=8,observed_roster_revisions=4,
                mapped_driver=driver,mapped_llvm=llvm,stdout_by_solver={k:[r['stdout'] for r in programs if r['solver']==k] for k in ('default','next')})
