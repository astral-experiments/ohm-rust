"""Portable, standard-library replay of exactly twelve corrected-release held-out triples."""
import ast
import hashlib
import io
import itertools
import json
from pathlib import Path
import sys
from zipfile import ZipFile

HIST="5af9fb8b180ca1b757f379c4158fcfc01d1ae4a9a781edbb31e1c91415a183e1"
STATS="cdd0e9c850584ed95902ca0b7978a0140c8bd1704ea12be8935ebabda6725bf9"
TRACE="14edca5b4b1f3f8d5c88d4b9f34c1a30e3af8adf72737db4c53139b4ec4ba0e3"
T3TRACE="a57368739659fb83e461a1f42c4d3d832e463275e1c0e1ae5bf35162610ff949"
REB="5184442540a4c2e2efe153e17240ca5ad2a19bfc22ac31c67f168d0b7754ca36"
QUAL="8a6b9f63ba5f812e24d0aeb49b33e083e9ce15edc9eb57fbd0ea1303c875c848"
MIG="1de511ab526102ab6af235b061479f73fd72fa799a803f41e8509e50decc3c67"
AUTH="7787c28dec95a5ddc97af7cb1139193df748b3b3ca3950e210745507cae67243"
LLVM="43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51"
ARTIFACTS={"source/T1-stack.patch":"55e569d67556d8595f75fcb110752485fd6272a403f68915623fd6ec4497c6d4",
           "source/T3-stack.patch":"de9a0147201e798c34a501fe7c8e209b88981b52fd5b917fb851cc0560a19bf8",
           "source/measured.json":"e74985383247527529cfda699d66afac81852cf9211c7e258d0246dc926395e3",
           "cache/fixture.rs":"68ee764b7d38e2c8add4a6961b422e998f3aa47611501a247b0c2da4733bc0f8"}
ROLES={"base":("625207d26ce4449c9c95d871c88cfb50e904c09f","8b72462af9b3251a8610e4310d34b9de4f1c8344",8),
       "T1":("6d997cb8c8ebd3cb0e16c28c09d9855d862238a2","c23ae897702d63e1ef8e55f2ada9d00c0d010558",9),
       "T3":("3334fcb9306dadf768e58248c4fefb53852fe02d","95e8cebdff72ed7658654e8169d4982abbfe03d5",10)}
PUB={"base":"556a8364f1485a03be31b1a50c250d63198a943d","T1":"8833a44ae11c06f328141f5b4254729c2d7b27cc","T3":"a34f2fffdf6f68cb07e89e0a239d30d0e2af38b5"}
digest=lambda b:hashlib.sha256(b).hexdigest()
jd=lambda v:digest(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def need(ok,message):
    if not ok:raise ValueError(message)
def namespace(src,name):
    env={"__name__":"supplement_"+name,"__file__":name}
    exec(compile(src,name,'exec'),env);return env
def replace(text,old,new):
    need(text.count(old)==1,'owning source changed: '+old[:66]);return text.replace(old,new)


def statistics_source(original):
    need(digest(original)==HIST,'established reviewer clocks and statistic body')
    text=original.decode()
    for old,new in [('recipe=runpy.run_path(str(ROOT/"statistics_recipe.py"))','recipe=SUPPLIED_RECIPE'),
                    ('("discovery","holdout-1","holdout-2"),SEEDS[stage]','("holdout-1","holdout-2"),SEEDS[stage][1:]'),
                    ('held=cohorts[1]+cohorts[2]','held=cohorts[0]+cohorts[1]'),
                    ('"discovery_excluded":6','"discovery_excluded":0')]:
        text=replace(text,old,new)
    return text


def decoder(base,adt,role):
    need(digest(base)==TRACE and digest(adt)==T3TRACE,'owning syscall decoders')
    x=namespace(base,'trace.py')
    if role=='T3':
        text=adt.decode();tree=ast.parse(text)
        names={n.name:ast.get_source_segment(text,n) for n in tree.body if isinstance(n,ast.FunctionDef)}
        stages=next(n for n in tree.body if isinstance(n,ast.Assign) and any(getattr(t,'id',None)=='STAGES' for t in n.targets))
        x['STAGES']=ast.literal_eval(stages.value)
        exec(compile(names['finish'],'seven-revisions','exec'),x)
        tree=ast.parse(base);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='decode')
        src=ast.get_source_segment(base.decode(),fn)
        anchor='    events.sort();need(wrap==1 and len(events)==20,'
        need(src.count(anchor)==1,'exact native event lexer')
        exec(compile(src[:src.index(anchor)]+'    return finish(events,wrap,driver,llvm)\n','mapped-seven','exec'),x)
    return x['decode']


def native(z,cert):
    load=lambda n:json.loads(z.read(n))
    base=z.read('code/trace.py');adt=z.read('code/adt-qualify.py');out={}
    for role,expect in ROLES.items():
        who=cert["subjects"][role]
        need((who['commit'],who['tree'],who['header_format'])==expect and who['llvm_sha256']==LLVM,'actual source/header')
        prefix='native/'+role+'/';meta=load(prefix+'receipt.json')
        need(meta['original_native_zip_sha256']==who['raw_packet_sha256'] and meta['worker_and_suite_exits']==[0,0,0,0],'closed native compilation and suites')
        names=meta['canonical_kernel_paths']
        need(len(names)==5 and len(set(names))==5 and names[3].endswith('/'+Path(who['driver_relative']).name),'source-specific canonical role images')
        decoded=decoder(base,adt,role)(io.BytesIO(z.read(prefix+'syscall-excerpts.zip')),*names)
        need(decoded['stdout_by_solver']==meta['stdout_by_solver'] and [decoded['compiler_executions'],decoded['executable_runs']]==([21,14] if role=='T3' else [12,8]),'both solvers observed under these images')
        need(meta['driver_sha256']==who['driver_sha256'] and meta['llvm_sha256']==LLVM,'original qualification and timed compiler identity')
        out[role]={'compiler_processes':decoded['compiler_executions'],'executed_readers':decoded['executable_runs'],
                   'default':decoded['stdout_by_solver']['default'],'next':decoded['stdout_by_solver']['next']}
    return out


def good(row,s):
    return row['worker_exit']==row['compile_exit']==0 and row.get('run_exit')==0 and row.get('run_stdout')==s


def matrix(z,cert):
    load=lambda n:json.loads(z.read(n));seeds={};cleans={};states={}
    for role,(_,_,fmt) in ROLES.items():
        arm=cert['subjects'][role];r=load('cache/'+role+'-seed.json');clean=load('cache/'+role+'-clean.json');m=load('cache/'+role+'-mismatch.json')
        need(good(r,'11\n') and good(clean['B'],'17\n') and good(m,'17\n') and clean['E']['compile_exit']==1 and 'E0277'in clean['E']['diagnostic_codes'],'actual clean and deliberate-error controls')
        need(r['driver_sha256']==arm['driver_sha256'] and r['launcher_sha256']==arm['launcher_sha256'] and r['llvm_sha256']==LLVM and
             r['seed_headers'] and all(i['format']==fmt and i['version']=='1.99.0-dev' for i in r['seed_headers'].values()),'real compiler identity and serialized input')
        need(m["assertion"]=="mismatched-header" and m["seed_sha256"]==r["seed_gz_sha256"] and "commit-hash: unknown" in r["rustc_identity"].splitlines(),"native forced-header control")
        seeds[role]=r;cleans[role]=clean
    for left,right in itertools.product(ROLES,repeat=2):
        name=left+'-to-'+right;rows=load('cache/'+name+'.json');same=left==right
        need(set(rows)=={'no_edit','positive','negative','assert_loaded','assert_not_loaded'},'full native migration matrix')
        for x in rows.values():
            need(x['seed_sha256']==seeds[left]['seed_gz_sha256'] and x['prior_headers_sha256']==jd(seeds[left]['seed_headers']) and
                 all(x[k]==seeds[right][k] for k in ('selected_driver_identity','selected_llvm_identity','driver_path','llvm_path')),'true original seed and selected target compiler')
            need(x['worker_exit']==0 and x['compile_argv'][0]=='/tmp/sdk/bin/rustc' and '-Cincremental=/tmp/w/incremental' in x['compile_argv'],'same cache and compiler paths')
        failed='assert_not_loaded' if same else 'assert_loaded';success='assert_loaded' if same else 'assert_not_loaded'
        msg='we asserted that the incremental cache should not be loaded' if same else 'we asserted that an existing incremental cache directory should be successfully loaded'
        need(rows[failed]['cache_assertion_text']==[msg] and rows[failed]['compile_exit']!=0 and good(rows[success],'17\n'),'direct post-cache load-state assertion')
        need(rows['no_edit']['source_sha256']==seeds[right]['source_sha256'] and rows['positive']['source_sha256']==cleans[right]['B']['source_sha256'] and
             rows['negative']['source_sha256']==cleans[right]['E']['source_sha256'],'actual identical/edit/failure source controls')
        need(good(rows['no_edit'],'11\n') and good(rows['positive'],'17\n') and rows['negative']['compile_exit']==cleans[right]['E']['compile_exit'] and
             rows['negative']['diagnostics_sha256']==cleans[right]['E']['diagnostics_sha256'] and 'E0277' in rows['negative']['diagnostic_codes'],'native source changes and fresh matching error')
        states[name]='loaded' if same else 'not-loaded'
    need(states==cert['states'] and cert['migration_registration']==MIG and cert['performance_rows']==0,'three self-loads and six cross-install rejections')
    return states


def expected_members():
    names={"__main__.py","SHA256.json","README.md","uv-20988.patch","registered-result.json","native-authority.json",
           "publication-relation.json","compiler-receipts.json","times.csv","code/trace.py","code/adt-qualify.py","code/registered-reviewer.py","code/statistics_recipe.py",*ARTIFACTS}
    for cohort in ("holdout-1","holdout-2"):
        names.update(cohort+"/"+n for n in ("pairs.jsonl","plan.json"))
        for arm in ("stock","parent","candidate"):
            prefix=f"{cohort}/{arm}/"
            names.update(prefix+n for n in ("identity.json","cargo.txt","rustc.txt","protocol.log","private-tmp.json","setup.zip",*[f"pair-{i}.zip" for i in range(1,7)]))
    for a in ROLES:
        names.update("native/"+a+"/"+n for n in ("receipt.json","syscall-excerpts.zip"))
        names.update("cache/"+a+"-"+n+".json" for n in ("clean","mismatch","seed"))
        names.update("cache/"+a+"-to-"+b+".json" for b in ROLES)
    return names


def analyze(packet):
    need(__debug__,'Python assertions must be enabled')
    with ZipFile(packet) as z:
        infos=z.infolist();need(len(infos)==len({i.filename for i in infos})<240 and sum(i.file_size for i in infos)<48<<20,'bounded, unique public packet')
        names=set(z.namelist());need(names==expected_members(),'exactly the two new held-outs and registered non-timing material')
        load=lambda n:json.loads(z.read(n));manifest=load('SHA256.json')
        need(set(manifest)|{'SHA256.json'}==names and all(digest(z.read(n))==h for n,h in manifest.items()),'exact per-member integrity')
        need(all(digest(z.read(n))==sha for n,sha in ARTIFACTS.items()),'authentic compiler and migration sources')
        subject=load('compiler-receipts.json');cert=load('native-authority.json');relation=load('publication-relation.json')
        need(cert['exact_native_registration']==QUAL and cert['confirmation_registration']==AUTH and digest(z.read('publication-relation.json'))==REB,'source and exact fresh cohort authority')
        need({v['role'] for v in relation['commits']}==set(ROLES) and
             all(r['previous']==ROLES[r['role']][0] and r['current']==PUB[r['role']] and r['compiler_tree']==r['previous_compiler_tree'] for r in relation['commits']),'published and measured compiler subtrees')
        need(relation['only_cross_release_difference']==':160000 160000 2554a1dfaf22474b360a4298883acf41f82bd78f 8269d772aa1ef02e5efaa331dfb40eb55d71f719 M\tsrc/tools/cargo','only root gitlink changed')
        for a,r in (('parent','T1'),('candidate','T3')):
            need(subject['roles'][a]['driver_sha256']==cert['subjects'][r]['driver_sha256'] and subject['roles'][a]['commit']==ROLES[r][0],'measured native arms')
        native_checks=native(z,cert);cache=matrix(z,cert)
        code=z.read('code/registered-reviewer.py');recipe=z.read('code/statistics_recipe.py')
        need(digest(recipe)==STATS,'unchanged statistical recipe')
        env={'SUPPLIED_RECIPE':namespace(recipe,'statistics_recipe.py'),'__name__':'exact_review_only','__file__':'registered-reviewer.py'}
        src=statistics_source(code);exec(compile(src,'registered-reviewer-heldouts','exec'),env)
        result=env['analyze'](packet,'T3')
    need(result['held_out_triples']==12 and result['discovery_excluded']==0,'exactly twelve new triples')
    return {**result,'family':'exact untrained RC22 stage1 T1/T3; signed -18 Cargo','historical_pgo_rows':0,'cache':cache,'native':native_checks}


if __name__=='__main__':
    need(len(sys.argv) in (1,2),'python3 packet.zip or python3 verify_exact.py packet.zip')
    print(json.dumps(analyze(Path(sys.argv[-1])),indent=2))
