# Checking uv-cli after the original uv #21076 edit

The median first check took **3.014 s with signed Ohm Rust 18, 3.651 s with #278 off, and 1.838 s with #278 on**. The median paired speedup was **1.652×** against the signed compiler and **1.986×** against the matched off compiler. The signed comparison missed the preregistered 1.8× discovery gate. No held-out comparisons ran.

All six triples used the full first-parent edit from `9f5808695af96f92daf680ded0ebe939869241ed` to `79ef389e39e3b21a5443b7ab25e890f33b0dadf9`. The edit was applied without advancing HEAD. It changes the diagnostic for `uv version --bump foo` and the corresponding uv test. [uv #21076](https://github.com/astral-sh/uv/pull/21076)

| Triple | Execution order | Signed 18 (s) | Matched off (s) | Matched on (s) |
| --- | --- | ---: | ---: | ---: |
| 1 | on, off, signed | 3.045 | 3.660 | 1.835 |
| 2 | off, signed, on | 3.008 | 3.641 | 1.875 |
| 3 | signed, on, off | 3.019 | 3.632 | 1.834 |
| 4 | signed, off, on | 2.964 | 3.626 | 1.932 |
| 5 | off, on, signed | 2.997 | 3.669 | 1.802 |
| 6 | on, signed, off | 3.052 | 3.664 | 1.840 |

Each arm used its own warmed parent, signed Rust 18 Cargo and the same LLVM library. Each sample restored the arm’s parent target and measured the ordinary `cargo check -p uv-cli --locked --offline -j8`. Each of the 18 first edits rechecked exactly `uv_cli` and renewed its rmeta. The immediately preceding parent check and following child check did no work in all 18 cases. The matched off/on compilers differ in the #278 implementation. The signed compiler is a separate comparison. [Ohm Rust #278](https://github.com/astral-experiments/ohm-rust/pull/278)

### Offline replay

```sh
python3 -IB verify.py
```

The verifier requires Python 3.10 or later and Git. It regenerates the entire uncommitted patch from the 22-object Git proof, including both authentic commits, the relevant trees, both versions of the two changed files and the lockfile. It verifies the original command archives, all 18 first edits and 36 no-ops, time/order ledgers, compiler/Cargo/LLVM identities and six separately linked A/B parser observations. The original frozen scorer reads the raw wall clocks. Ratios are medians of within-triple ratios. The parser checks expected exit status 2 in both revisions. Only the child printed the extended usage and help text.

`data/` contains the unmodified command and product records. `data/plan.json` uses portable role names for host paths. `provenance.json` retains SHA-256 commitments for the original unsanitized plan, namespace and SDK records and identifies the separately completed parser witnesses. Signed/on used exact-driver behaviors observed earlier on the same two literal revisions; off was linked after the six triples. All three workers’ actual compiler and library identities are in their native records. Wall clocks for parser builds are outside the comparisons.

The coordinator separately reported executor session `93611`, terminal chunk `445581`, exit 0. The native harness did not save a separate outer exit file. The offline replay reads the command and correctness evidence independently of that operator report.
