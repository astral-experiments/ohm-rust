"""Offline replay of the six literal-parent #278 discovery triples. Requires Python 3 and Git."""
import hashlib, itertools, json, os, random, re, runpy, statistics, subprocess, tempfile, zipfile
from pathlib import Path

D=Path(__file__).resolve().parent
P=json.loads((D/"provenance.json").read_bytes())
RAW=P["raw"]
ARMS={"stock":"signed","parent":"off","candidate":"on"}
DRIVERS={"stock":"a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de",
         "parent":"d8c9b773f401ec3f39fa687556590fe2f9467a014ffbf7a66616abb774073064",
         "candidate":"5c7784b3fc4a1a2502e8a89ab7187effb27e31d0ece8510c09995e6c09d4c239"}
CARGO="02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
LLVM="43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51"
PATCH="d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28"
A="9f5808695af96f92daf680ded0ebe939869241ed"
B="79ef389e39e3b21a5443b7ab25e890f33b0dadf9"
READ=lambda path:json.loads(path.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()

def original(path,key):
    data=path.read_bytes()
    assert {"bytes":len(data),"sha256":sha(data)}==RAW[key],key
    return data

def source():
    s=P["source"];assert (s["parent"],s["child"])==(A,B)
    delta=original(D/"edit.patch","published_source_patch");assert sha(delta)==PATCH
    assert set(s["files"])=={"crates/uv-cli/src/lib.rs","crates/uv/tests/it/version.rs"}
    env={"PATH":os.environ["PATH"],"LC_ALL":"C","GIT_CONFIG_GLOBAL":os.devnull,"GIT_CONFIG_NOSYSTEM":"1","GIT_NO_LAZY_FETCH":"1","GIT_ALLOW_PROTOCOL":"file"}
    with tempfile.TemporaryDirectory()as tmp:
        repo=Path(tmp)/"repo"
        def git(*args,data=None):return subprocess.check_output(["git","--git-dir",repo,*args],input=data,env=env)
        git("init","--quiet","--bare");git("index-pack","--stdin",data=(D/"source.pack").read_bytes())
        assert git("rev-parse",B+"^").decode().strip()==A
        assert git("diff","--full-index","--binary","--no-renames","--no-ext-diff",A,B,"--")==delta
        for ix,rev in enumerate((A,B)):
            assert git("rev-parse",rev+"^{tree}").decode().strip()==s["tree"][ix]
            assert git("rev-parse",rev+":Cargo.lock").decode().strip()==s["lock_oid"]
            assert sha(git("cat-file","blob",rev+":Cargo.lock"))==s["lock_sha256"]
            for f,ids in s["files"].items():assert git("rev-parse",rev+":"+f).decode().strip()==ids[ix]

def check_role(role,samples):
    arm=D/"data"/role
    rd=lambda n:original(arm/n,"ordinary/"+role+"/"+n)
    ident=json.loads(rd("identity.json"));ns=P["namespace"][role]
    assert ident["cargo"]==ns["cargo"]==CARGO and ident["launcher"]==ns["launcher"]==P["arms"][role]["launcher_sha256"]
    assert set(ns["loaded"].values())=={DRIVERS[role],LLVM}=={r["sha256"]for r in ident["linked"].values()}
    assert ns["driver"]==DRIVERS[role] and ns["llvm"]==LLVM
    assert ns["sdk_members"]==149+(role!="stock") and ns["same_file_companions"]==149-(role!="stock")
    for tool,fn in (("rustc","rustc.txt"),("cargo","cargo.txt")):
        assert rd(fn).decode().strip()==ns["versions"][tool].strip()
    meta=json.loads(rd("metadata.json"));assert all(re.fullmatch("[0-9a-f]{64}",v["sha256"]) for v in meta.values())
    pkt=rd("protocol.log").decode().splitlines();reg=json.loads(pkt[0]);assert reg["lock"]==P["source"]["lock_oid"] and reg["packages"]==683
    msgs=[json.loads(v[7:]) for v in pkt if v.startswith("UVPAIR ")]
    assert msgs[0]=={"state":"ready","patch":PATCH} and msgs[1:]==[v[role] for v in samples]
    assert RAW["ordinary/"+role+"/edit.patch"]["sha256"]==PATCH
    argv=["/tmp/uv-workflow-search/sdk/bin/cargo","check","-p","uv-cli","--locked","--offline","-j8"]
    rd("setup.zip")
    with zipfile.ZipFile(arm/"setup.zip")as z:
        cold=json.loads(z.read("warm.json"));settled=json.loads(z.read("settled.json"))
        assert cold["cmd"]==settled["cmd"]==argv and "uv_cli" in cold["dirty_units"] and settled["dirty_units"]==[]
    for i,s in enumerate(samples,1):
        n=f"pair-{i}.zip";rd(n)
        with zipfile.ZipFile(arm/n)as z:
            prim={}
            for stage,metric in (("settled-A","parent_noop"),("edit-D","edit"),("noop-D","noop")):
                row=json.loads(z.read(stage+".json"));dirty=["uv_cli"] if stage=="edit-D" else []
                assert row["cmd"]==argv and row["dirty_units"]==dirty and row["wall_s"]==s[role][metric]>0
                text=z.read(stage+".stderr")
                assert re.findall(rb"^\s*(?:Checking|Compiling) ([\w-]+) v",text,re.M)==([b"uv-cli"]if dirty else []) and b"Finished" in text
                assert z.read(stage+".stdout")==b""
                use=json.loads(z.read(stage+".usage.json"));assert use["user_us"]+use["sys_us"]>0
                prim[stage]=json.loads(z.read(stage+".primary.json"))
            a,b,noop=[prim[n]for n in ("settled-A","edit-D","noop-D")]
            assert a["name"]==b["name"] and a!=b==noop
            if i==6:assert b=={k:v for k,v in meta["B"].items()if k!="sha256"}
    forms=[];key={"stock":"stock18","parent":"off","candidate":"reference"}[role]
    for rev in ("A","B"):
        folder=D/"parser"/role
        def inp(suffix):return original(folder/(rev+"-"+suffix),f"parser/{role}/{rev}/{suffix}")
        p=json.loads(inp("behavior.json"));f=json.loads(inp("build.json"))
        assert f["exit"]==0 and f["argv"][1:]==["build","--locked","--offline","-j8","-p","uv-cli","--lib"]
        assert f["elapsed_ns"]==f["end_ns"]-f["start_ns"]>0 and p["fresh_empty_cargo_target"] is True
        assert (p["compiler_sha256"],p["witness_source"],p["source"],p["arm"])==(DRIVERS[role],sha((D/"parser.rs").read_bytes()),rev,key)
        expected="error: invalid bump component `foo`"+("" if rev=="A" else "\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n")
        assert p["expected_clap_exit"]==2 and p["diagnostic"]==expected
        if role=="parent":assert sha(inp("build.cargo.log"))==f["stdout_sha256"]
        forms.append(p)
    assert all(forms[0][n]!=forms[1][n] for n in ("libuv_cli_sha256","program_sha256"))

def verify():
    assert __debug__
    manifest=json.loads((D/"files.json").read_bytes())
    assert all(sha((D/n).read_bytes())==h for n,h in manifest.items()) and not any((D/n).is_symlink() for n in manifest)
    assert set(manifest)|{"files.json"}=={str(p.relative_to(D))for p in D.rglob("*") if p.is_file()}
    source();original(D/"parser.rs","parser_program")
    plan=READ(D/"data/plan.json");cfg=plan["config"];assert plan["source"]==[A,B] and cfg["plain"] and not cfg["diagnostics"]
    assert cfg["seed"]==2782107601 and cfg["case"]=="literal21076-cli" and cfg["pairs"]==6
    block=list(itertools.permutations(sorted(ARMS)));random.Random(cfg["seed"]).shuffle(block)
    assert plan["sequence"]==P["schedules"]==list(map(list,block))
    raw=original(D/"data/pairs.jsonl","all_ordinary_clocks");samples=[json.loads(s)for s in raw.splitlines()]
    assert len(samples)==6 and [list(s)for s in samples]==plan["sequence"]
    for i,s in enumerate(samples,1):
        assert all(r["state"]=="measured" and r["trial"]==str(i) and r["dirty"]==["uv_cli"]for r in s.values())
    assert P["labels"]==ARMS and P["signed_cargo"]==CARGO and P["common_llvm"]==LLVM
    assert P["qualified_signed_files"]==67 and P["shared_files"]==148 and P["first_edit_only"] is True
    for role in ARMS:check_role(role,samples)
    assert P["prior_parser_source"]=={"historical_parent":A,"historical_child":B} and P["prior_parser_exit"]==0
    scorer=original(D/"score-pairs.py","original_score")
    assert sha(scorer)=="cdd0e9c850584ed95902ca0b7978a0140c8bd1704ea12be8935ebabda6725bf9"
    score=runpy.run_path(str(D/"score-pairs.py"))["score"]([D/"data"])
    off=score["comparisons"]["parent"]["pair_ratios"];signed=score["comparisons"]["stock"]["pair_ratios"]
    ratios={"signed/off":statistics.median(a/b for a,b in zip(signed,off)),"signed/on":statistics.median(signed),"off/on":statistics.median(off)}
    assert P["heldout_gate"]=={"ratio":"signed/on","threshold":1.8,"discovery_triples":6,"heldout_triples":0}
    assert ratios["signed/on"]<P["heldout_gate"]["threshold"]
    return {"source":[A,B],"discovery_triples":6,"first_edits":18,"clean_A_and_B_noops":36,"native_parser_cases":6,
            "seconds":{v:score["roles"][k]["edit"]for k,v in ARMS.items()},"paired_speedups":ratios,
            "nomination_gate":1.8,"opens_confirmation":False,"heldout_triples":0}

if __name__=="__main__":
    print(json.dumps(verify(),indent=2))
