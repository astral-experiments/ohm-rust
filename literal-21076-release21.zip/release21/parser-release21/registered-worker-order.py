def worker(out):
    p=read(out.parent/"subject-intake.json");check_smoke(p,read(SMOKE))
    assert p["namespace_smoke_sha256"]==sha(SMOKE) and p["logical_roles"]==ROLES
    with patch.multiple(lit,D=D,REG=REG,ACCEPT=ACCEPT):lit.worker(out)
    if out.name=="candidate" and out.parent.name==read(D/"discovery.json")["name"]:
        subprocess.run([sys.executable,"-ISB",D/"behavior.py",out],check=True)
