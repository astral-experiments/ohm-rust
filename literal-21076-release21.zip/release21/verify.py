"""Replay the literal-parent signed −18/−21 Cargo results with Python 3 and Git."""
import hashlib, io, itertools, json, math, os, random, re, runpy, statistics, subprocess, sys, tempfile, zipfile
from pathlib import Path
D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
med=statistics.median
OLD='86e9a725b263e6c777ff7bfe8738f96bbd81a1af6b584a121af755571c9b8773'
SEALS=('74e18b0647a47563af94df91707abe22f865c1e4937402b94be9a4b692278d2b','dff75d054b470f2ffa4c38c96d3f07f187d2bbf2fe294e24379243519e646fa4','01b87f69042b31721f5d45ad0ff86c46bf1dba747b891256b736dbd7582f4343')
ROLES={'stock':'signed18','parent':'matched278-on','candidate':'released21'}
PARSER={'stock':'stock18','parent':'reference','candidate':'release21'}
DRIVERS={'stock':'a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de','parent':'5c7784b3fc4a1a2502e8a89ab7187effb27e31d0ece8510c09995e6c09d4c239','candidate':'dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3'}
LAUNCHERS={'stock':'c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60','parent':'c930b062ca10b3f3da27804ac86e4e7a54f0213fe119ca1cc244c4ac04eea85c','candidate':'f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9'}
LLVM='43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51'
CARGO='02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573'
RELCARGO='4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e'
PATCH='d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28'
PH=('discovery','confirm-1','confirm-2')
CMD=['/tmp/uv-workflow-search/sdk/bin/cargo','check','-p','uv-cli','--locked','--offline','-j8']
CONTRAST=[('stock','parent','signed18/matched278-on'),('stock','candidate','signed18/released21'),('parent','candidate','matched278-on/released21')]
def prior(tmp):
    b=(D/'literal-21076-matched278.zip').read_bytes();assert sha(b)==OLD
    with zipfile.ZipFile(io.BytesIO(b)) as z:z.extractall(tmp)
    old=tmp/'matched278'
    checked=json.loads(subprocess.check_output([sys.executable,'-ISB',old/'verify.py']))
    assert checked['heldout_triples']==0 and checked['first_edits']==18
    return old,checked['source']
def check_parser(old,role):
    files=(D/'parser-release21') if role=='candidate' else old/'parser'/('stock' if role=='stock' else 'candidate')
    rows=[]
    for state in ('A','B'):
        a=read(files/(state+'-behavior.json'));g=read(files/(state+'-build.json'))
        assert (a['source'],a['arm'],a['compiler_sha256'],a['fresh_empty_cargo_target'],a['expected_clap_exit'])==(state,PARSER[role],DRIVERS[role],True,2)
        assert a['witness_source']==sha((old/'parser.rs').read_bytes())
        expected='error: invalid bump component `foo`'+('' if state=='A' else "\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n")
        assert a['diagnostic']==expected and g['exit']==0 and g['argv'][1:]==['build','--locked','--offline','-j8','-p','uv-cli','--lib']
        assert g['elapsed_ns']==g['end_ns']-g['start_ns']>0
        if role=='candidate':
            b=(files/(state+'-build.cargo.log')).read_bytes();assert len(b)==g['bytes'] and sha(b)==g['stdout_sha256']
        rows.append((a,g))
    assert all(rows[0][0][k]!=rows[1][0][k]for k in ('libuv_cli_sha256','program_sha256'))
    if role=='candidate':assert rows[0][1]['end_ns']<=rows[1][1]['start_ns']
def stats(cohorts):
    def ratio(row,a,b):
        # Preserve the registered signed/on arithmetic, including its division order.
        return (row[a]['edit']/row['candidate']['edit'])/(row[b]['edit']/row['candidate']['edit']) if b=='parent' else row[a]['edit']/row[b]['edit']
    def phases(rows):
        return {v:med(r[k]['edit']for r in rows) for k,v in ROLES.items()}
    d=cohorts[0];h=cohorts[1:];allh=h[0]+h[1];result={}
    for a,b,label in CONTRAST:
        t=1 if a=='parent' else 2;alpha=.05 if t==1 else .025
        v=[ratio(r,a,b)for r in allh];ordered=sorted(v);i=max(k for k in range(6)if 2*sum(math.comb(12,j)for j in range(k+1))/4096<=alpha)
        interval=[ordered[i],ordered[-1-i]];seeds=[med(ratio(r,a,b)for r in h1)for h1 in h];strata=[[x for x,r in zip(v,allh)if (list(r).index(a)<list(r).index(b))==first]for first in (False,True)]
        assert list(map(len,strata))==[6,6]
        by_order=list(map(med,strata));v2=[x for x in v if x!=t];n=len(v2);high=sum(x>t for x in v2);pv=sum(math.comb(n,j)for j in range(high,n+1))/2**n
        result[label]=dict(median=med(v),interval=interval,p=pv,threshold=t,seed_medians=seeds,order_medians=by_order,passed=interval[0]>t and pv<alpha and min(seeds+by_order)>t)
    disc={label:med(ratio(r,a,b)for r in d)for a,b,label in CONTRAST}
    assert disc['signed18/released21']>=1.8
    return dict(excluded_triples=6,opens_confirmation=True,discovery=disc,discovery_seconds=phases(d),heldout_triples=12,heldout_seconds=phases(allh),contrasts=result,primary_direct_2x=result['signed18/released21']['passed'])
def phase(p,idx,smoke,source):
    plan=read(p/'plan.json');rows=[json.loads(s)for s in (p/'pairs.jsonl').read_bytes().splitlines()];seq=list(itertools.permutations(sorted(ROLES)));random.Random(212107601+idx).shuffle(seq)
    assert plan['config']['seed']==212107601+idx and plan['config']['pairs']==6 and plan['config']['case']=='literal21076-cli' and plan['config']['plain'] and not plan['config']['diagnostics']
    assert plan['source']==source and plan['sequence']==list(map(list,seq))==[list(r)for r in rows] and len(rows)==6
    for role in ROLES:
        arm=p/role;ident=read(arm/'identity.json');meta=read(arm/'metadata.json');cfg=plan['inputs'][role]
        assert cfg['cargo']==ident['cargo']==CARGO and cfg['launcher']==ident['launcher']==LAUNCHERS[role]
        assert cfg['sdk_cargo_before_overlay']==(RELCARGO if role=='candidate'else CARGO) and DRIVERS[role]in cfg['drivers'].values()
        assert {v['sha256']for v in ident['linked'].values()}=={DRIVERS[role],LLVM}
        assert set(meta)=={'A','B'} and all(re.fullmatch('[0-9a-f]{64}',v['sha256'])for v in meta.values()) and meta['A']['sha256']!=meta['B']['sha256']
        assert (arm/'cargo.txt').read_text().strip()==smoke[role]['versions']['cargo'].strip() and (arm/'rustc.txt').read_text().strip()==smoke[role]['versions']['rustc'].strip()
        log=(arm/'protocol.log').read_text().splitlines();reg=json.loads(log[0]);assert reg['packages']==683 and reg['lock']=='c1601688714997cf9380248c63a6bbb32537224d'
        msgs=[json.loads(s[7:])for s in log if s.startswith('UVPAIR ')]
        assert msgs==[{'state':'ready','patch':PATCH}]+[r[role]for r in rows]
        with zipfile.ZipFile(arm/'setup.zip')as z:
            warm=json.loads(z.read('warm.json'));settled=json.loads(z.read('settled.json'))
            assert warm['cmd']==settled['cmd']==CMD and 'uv_cli'in warm['dirty_units'] and settled['dirty_units']==[]
        for i,r in enumerate(rows,1):
            assert r[role]['state']=='measured'and r[role]['trial']==str(i)and r[role]['dirty']==['uv_cli']
            with zipfile.ZipFile(arm/f'pair-{i}.zip')as z:
                prim={}
                for n,k,dirty in [('settled-A','parent_noop',[]),('edit-D','edit',['uv_cli']),('noop-D','noop',[])]:
                    rec=json.loads(z.read(n+'.json'));err=z.read(n+'.stderr')
                    assert rec['cmd']==CMD and rec['dirty_units']==dirty and rec['wall_s']==r[role][k]>0
                    assert re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)==([b'uv-cli']if dirty else []) and b'Finished'in err and not z.read(n+'.stdout')
                    usage=json.loads(z.read(n+'.usage.json'));assert usage['user_us']+usage['sys_us']>0
                    prim[n]=json.loads(z.read(n+'.primary.json'))
                a,b,c=[prim[n] for n in ('settled-A','edit-D','noop-D')];assert a['name']==b['name'] and a!=b==c
                if i==6:assert b=={k:v for k,v in meta['B'].items()if k!='sha256'}
    return rows
def verify():
    assert __debug__
    files=read(D/'files.json');assert set(files)=={str(p.relative_to(D))for p in D.rglob('*')if p.is_file()and p!=D/'files.json'}
    assert all(not (D/n).is_symlink()and sha((D/n).read_bytes())==v for n,v in files.items())
    p=read(D/'provenance.json');smoke=read(D/'worker-namespace.json')
    assert (p['registration'],p['release21']['projected_sha256'],sha((D/'worker-namespace.json').read_bytes()))==SEALS
    assert smoke['registration']==SEALS[0] and smoke['projected_sha256']==SEALS[1] and len({r['versions']['cargo']for r in smoke['arms'].values()})==1
    for k,r in smoke['arms'].items():
        assert (r['driver'],r['launcher'],r['cargo'],set(r['loaded'].values()),r['timing_rows'])==(DRIVERS[k],LAUNCHERS[k],CARGO,{DRIVERS[k],LLVM},0)
    rel=p['release21'];assert rel['tag']=='ohm-1.99.0-21' and rel['source']=='c79998a5cd143c445a4b2528f20953b176a65c5d' and rel['archive']=={'sha256':'6f550de85f95440a61b5bd1a9d2ab0528d4fcaf674fdc008f5e986d2138be6c4','bytes':359657153}
    assert len(rel['files'])==smoke['arms']['candidate']['members']==67 and rel['files']['bin/cargo']['sha256']==RELCARGO and rel['files']['bin/rustc']['sha256']==LAUNCHERS['candidate']
    assert {x['sha256']for n,x in rel['files'].items()if 'librustc_driver-'in n or n.endswith('libLLVM.so.23.1-rust-1.99.0-beta')}=={DRIVERS['candidate'],LLVM}
    assert p['roles']==ROLES and p['release21']['rustc_vv'].strip()==smoke['arms']['candidate']['versions']['rustc'].strip()
    assert all(p['native_hashes'][n]['sha256']==v for n,v in files.items()if n in p['native_hashes'])
    with tempfile.TemporaryDirectory() as tmp:
        old,source=prior(Path(tmp))
        for r in ROLES:check_parser(old,r)
        for ph in PH:assert all(p['native_hashes'][ph+'/'+r+'/edit.patch']['sha256']==sha((old/'edit.patch').read_bytes())==PATCH for r in ROLES)
        cohorts=[phase(D/ph,i,smoke['arms'],source)for i,ph in enumerate(PH)]
    res=stats(cohorts);assert res==read(D/'score.stdout.json')
    return {'source':source,'ordinary_first_edits':54,'clean_immediate_noops':108,'cold_A_seeds':9,'fresh_release_parser_cases':2,'exact_prior_parser_cases':4,'discovery_excluded_from_confirmation':True,'score':res}
if __name__=='__main__':print(json.dumps(verify(),indent=2))
