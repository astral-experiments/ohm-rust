use uv_resolver::ResolutionMode;

fn main() {
    println!("{}|{}|{}", ResolutionMode::default(), ResolutionMode::Lowest, ResolutionMode::LowestDirect);
}
