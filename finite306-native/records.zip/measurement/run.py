"""Ordinary first edits on the actual shipped -18 and the qualified pre-BOLT PR #306 image."""
from contextlib import contextmanager
from pathlib import Path
from statistics import median
from unittest.mock import patch
from zipfile import ZipFile
import hashlib,importlib.util,inspect,json,os,re,shutil,subprocess,sys

D=Path(__file__).resolve().parent;R=D.parents[1];STUDY=R.parents[1]
S=R/'review-finite-v12/selector-002/trial';PRIOR=S/'discovery-resolver-finite-v12-pgo-001'
REG=D/'registration.json';ROLES=('stock','candidate');PH=('discovery','confirm-1','confirm-2')
def load(p,n):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=load(D.parent/'run.py','native_resolver_ordinary_source')
o=load(R/'paired/ordinary.py','fixed_signed_cargo_native_306')
h=load(R/'paired/hash-20605-root-dist22/run.py','exclusive_capacity_native_306')
product=load(D/'products.py','finite306_product');sha=product.sha;read=base.read
def config(form,phase):return D/(form+'-'+phase+'.json')
def phases(form):return [read(config(form,ph)) for ph in PH]
def order(cfg):
    seq=o.pairs.order(sorted(ROLES),6,cfg['seed'])
    assert cfg['pairs']==6 and set(cfg['sdks'])==set(ROLES) and all(seq.count(t)==3 for t in set(seq)) and len(set(seq))==2
    return [list(t)for t in seq]
def identity(got,want):
    assert got['cargo']==o.CARGO and got['launcher']==want['launcher_sha256']
    own=Path(want['driver_relative']).name
    assert set(got['linked'])=={own,'libLLVM.so.23.1-rust-1.99.0-beta'}
    assert got['linked'][own]['sha256']==want['driver_sha256'] and got['linked']['libLLVM.so.23.1-rust-1.99.0-beta']['sha256']==want['llvm_sha256']
    assert all(Path(v['path']).resolve().is_relative_to(o.screen.LANE/'sdk')for v in got['linked'].values())
def subjects(check_live=False):
    stored=read(S/'admission.json');a=stored['arms'];qualified=stored['qualified_sources'];t=a['candidate']
    assert t['header_format']==12 and qualified['pre_BOLT'] and t['tree']=='7fd44bf57a11609d65d7feeea1db6b6279a77f04'
    assert t['driver_sha256']=='f10dcce341a10cd09646bdd778952f6ad32631854d3197f917da8ae47d06d642'
    assert t['profile_sha256']=='70892579bb848a9eb268d1d74538e53b849f3de4c0df6a05a504f071bdb869ea'
    assert t['commit']=='fd96f14140962cc722aa1335c4449c01f3f3a286' and a['stock']['driver_sha256']==o.stock()['driver_sha256']
    arms={k:dict(a[k])for k in ROLES}
    for key in ROLES:
        prev=read(PRIOR/key/'identity.json')
        if key=='stock':arms[key].update(launcher_sha256=prev['launcher'],llvm_sha256=t['llvm_sha256'])
        identity(prev,arms[key])
    if check_live:
        p=subprocess.check_output(['/usr/bin/python3','-ISB',str(S/'run.py'),'admit'])
        assert json.loads(p)['verified']==sha(S/'admission.json')
    return dict(registration=sha(REG),issuer=sha(S/'admission.json'),arms=arms)
def audit():
    reg=read(REG);assert __debug__ and all(sha(D/k)==v for k,v in reg['files'].items())
    assert all(sha(base.HERE/k)==v for k,v in read(base.REG)['files'].items())
    assert o.screen is base.screen and o.pairs is base.pairs and o.screen.BANK==Path(base.PROTO['bank'])
    assert all(o.screen.CASES[case]==(base.A,base.B,base.forms.CASES[case])for case in base.FORMS.values());o.audit()
    assert sha(Path(base.PROTO['bank'])/'receipt.json')==base.PROTO['bank_receipt_sha256']
    doc=subjects();seeds=[]
    for form in base.FORMS:
        for ph,c in zip(PH,phases(form),strict=True):
            seeds.append(c['seed']);assert c['case']==base.FORMS[form] and c['name']==form+'-'+ph+'-306-001' and c['bank']==base.PROTO['bank'] and c['plain'] and not c['diagnostics']
            assert c['sdks']=={k:v['sdk']for k,v in doc['arms'].items()} and order(c)==reg['schedules'][c['name']]
            assert list(c['sdks'])==(list(ROLES) if (list(base.FORMS).index(form)+PH.index(ph))%2==0 else list(reversed(ROLES)))
    assert len(set(seeds))==6
    return sha(REG)
def worker(out,case):
    cfg=read(out.parent/'plan.json')['config'];form=next(f for f,c in base.FORMS.items() if c==case)
    assert any(cfg==c for c in phases(form)) and out.parent==D/cfg['name'] and out.name in ROLES
    sdk=o.screen.LANE/'sdk';intake=read(out.parent/'subject-intake.json');assert intake==subjects()
    backend=o.pairs.worker
    def enclosed(out,case):
        original=o.pairs.measure;held={}
        def step(run,env,target,cmd,label,plain):
            h.floor(True)
            if label=='warm':
                identity(read(out/'identity.json'),intake['arms'][out.name])
                for n in ('rustc.txt','cargo.txt'):assert (out/n).read_bytes()==(PRIOR/out.name/n).read_bytes()
            row=original(run,env,target,cmd,label,plain)
            if label=='edit-D':assert sorted(row['dirty_units'])==sorted(product.DIRTY)
            now=product.take(base,run,env,target,form,label,cmd)
            if label=='warm':held['warm']=now
            elif label=='settled':
                product.transition(held['warm'],now,False);held['settled']=now
                cost=int(subprocess.check_output(['du','-s','-B1',target]).split()[0])
                assert shutil.disk_usage('/tmp').free>=cost+(4<<30),'insufficient private target copy or 3-GiB reserve'
            elif label=='settled-A':
                prior=held['settled'];assert now['sha256']==prior['sha256'] and now['units']==prior['units'];held['A']=now
            elif label=='edit-D':product.transition(held['A'],now,True);held['B']=now
            else:
                assert label=='noop-D';product.transition(held['B'],now,False);held.update(env=env.copy(),target=target,last=run.name)
            h.floor(True);return row
        with patch.object(o.pairs,'measure',step):backend(out,case)
        assert held['last']=='pair-6' and held['target']==o.screen.LANE/'target'
        # Both actual A and B products are still private. Check each at its canonical build path after all clocks.
        for revision,state,key in [('A',held['settled'],'offclock-A'),('B',held['B'],'offclock')]:
            for name,live in [('source',o.screen.SRC),('target',held['target'])]:
                checkpoint=o.screen.LANE/('a-'+name);other=o.screen.LANE/('postclock-B-'+name)
                assert live.is_dir() and not live.is_symlink()
                if revision=='A':
                    assert checkpoint.is_dir() and not checkpoint.is_symlink() and not other.exists();live.rename(other);checkpoint.rename(live)
                else:
                    assert not checkpoint.exists() and other.is_dir() and not other.is_symlink();shutil.rmtree(live);other.rename(live)
            assert o.screen.git('rev-parse','HEAD').decode().strip()==base.A
            assert not o.screen.git('diff','--exit-code',base.A if revision=='A' else base.B)
            q=out/key;q.mkdir();product.offclock(form,held['env'],held['target'],sdk,o.screen.SRC,q,state,revision)
            h.floor(True);product.put(q/'success.json',{'measured_sha256':state['sha256'],'form':form,'revision':revision})
    with patch.object(o.pairs,'worker',enclosed):
        o.worker(out,case,base.PROTO|{'args':base.forms.CASES[case],'required_dirty':product.DIRTY})
def paired(row,sequence,i,k,a,b,n):
    assert list(row)==sequence and set(sequence)==set(ROLES) and int(row[k]['trial'])==i and row[k]['state']=='measured'
    assert [row[k][col]for col in ('parent_noop','edit','noop','dirty')]==[a['wall_s'],b['wall_s'],n['wall_s'],b['dirty_units']]
def raw_rows(form,phase):
    cfg=read(config(form,phase));out=D/cfg['name'];p=read(out/'plan.json');doc=read(out/'subject-intake.json')
    assert p['config']==cfg and list(p['config']['sdks'])==list(cfg['sdks']) and p['sequence']==order(cfg) and p['source']==[base.A,base.B] and doc==subjects()
    assert sha(D/'run.py')==p['runner'] and p['config']['sdks']=={k:v['sdk']for k,v in doc['arms'].items()}
    rows=[json.loads(l)for l in (out/'pairs.jsonl').read_text().splitlines()];assert len(rows)==6
    cmd=[str(o.screen.LANE/'sdk/bin/cargo'),*base.forms.CASES[cfg['case']],'--locked','--offline','-j8']
    for k in ROLES:
        d=out/k;identity(read(d/'identity.json'),doc['arms'][k]);assert sha(d/'edit.patch')==base.PROTO['patch_sha256']
        def verify(z,label):
            raw=z.read(label+'.stderr');row=json.loads(z.read(label+'.json'));v=json.loads(z.read(label+'.verified.json'))
            dirty=[x.decode().replace('-','_')for x in re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',raw,re.M)]
            assert row['cmd']==cmd and row['dirty_units']==dirty and row['wall_s']>0 and len(v['sha256'])==64
            if label=='edit-D':assert sorted(dirty)==sorted(product.DIRTY)
            elif label!='warm':assert not dirty
            if form=='test':product.roster(z.read(label+'.listing'))
            else:assert hashlib.sha256(z.read(label+'.members')).hexdigest()==v['archive_members']
            return row,v
        with ZipFile(d/'setup.zip') as z:
            _,w=verify(z,'warm');_,a=verify(z,'settled');product.transition(w,a,False)
        for i,(full,seq)in enumerate(zip(rows,order(cfg),strict=True),1):
            assert list(full)==seq and int(full[k]['trial'])==i
            with ZipFile(d/f'pair-{i}.zip')as z:
                parent,first=verify(z,'settled-A');edit,b=verify(z,'edit-D');noop,n=verify(z,'noop-D')
                assert first['sha256']==a['sha256'] and first['units']==a['units'];product.transition(first,b,True);product.transition(b,n,False)
                paired(full,seq,i,k,parent,edit,noop)
        for rev,value,folder in [('A',a,'offclock-A'),('B',b,'offclock')]:
            q=d/folder;assert read(q/'success.json')=={'measured_sha256':value['sha256'],'form':form,'revision':rev}
            for name in (['exact-list','all-resolver-tests']if form=='test' else ['link-measured-rlib','run-rlib-client'])+(['changed-workspace-test']if rev=='B' else []):
                c=read(q/(name+'.json'));assert c['exit']==0 and c['stdout']==sha(q/(name+'.out')) and c['stderr']==sha(q/(name+'.err'))
            if form=='test':
                product.passed((q/'all-resolver-tests.out').read_bytes(),product.roster((q/'exact-list.out').read_bytes()))
                err=(q/'all-resolver-tests.err').read_bytes();assert not re.search(rb'^\s*(Checking|Compiling) ',err,re.M) and os.fsencode(Path(value['artifact']['path']).name)in err
            else:assert (q/'run-rlib-client.out').read_bytes()==b'highest|lowest|lowest-direct\n'
            if rev=='B':product.passed((q/'changed-workspace-test.out').read_bytes(),[product.FOCUSED])
    return [(row['stock']['edit']/row['candidate']['edit'],list(row)[0])for row in rows]
def gate(rows):
    assert len(rows)==6 and len([k for _,k in rows if k=='stock'])==3 and len([k for _,k in rows if k=='candidate'])==3
    return median(x for x,_ in rows)>=1.8
def closed(form,phase):
    dest=D/read(config(form,phase))['name'];r=read(dest/'closed.json');assert r['registration']==sha(REG) and all(sha(dest/k)==v for k,v in r['raw'].items())
    observed=raw_rows(form,phase);assert r['ratios']==[list(v)for v in observed];return observed
def costs(form,phase):
    dest=D/read(config(form,phase))['name'];rows=list(map(json.loads,(dest/'pairs.jsonl').read_text().splitlines()));info={}
    for k in ROLES:
        with ZipFile(dest/k/'setup.zip')as z:setup={n:json.loads(z.read(n+'.json'))['wall_s']for n in ('warm','settled')}
        info[k]=setup|{n:median(r[k][n]for r in rows)for n in ('edit','noop','parent_noop')}
    return info
def score(form):
    disc=closed(form,PH[0]);opens=gate(disc)
    result=dict(form=form,discovery=disc,discovery_median=median(x for x,_ in disc),seconds={PH[0]:costs(form,PH[0])},opens=opens,heldout_pairs=0,status='confirmation pending' if opens else 'screen below 1.8')
    if opens and (D/phases(form)[1]['name']/'closed.json').is_file():result.update(heldout_pairs=len(closed(form,PH[1])),status='second confirmation pending')
    if opens and (D/phases(form)[2]['name']).exists():
        sets=[closed(form,ph)for ph in PH[1:]];result['seconds'].update({ph:costs(form,ph)for ph in PH[1:]});all_rows=sum(sets,[]);v=sorted(x for x,_ in all_rows)
        orders=[median(x for x,k in all_rows if k==key)for key in ROLES];seeds=[median(x for x,_ in batch)for batch in sets]
        p=o.SCORE['sign_p'](v,2);result.update(heldout_pairs=12,status='two independently seeded cohorts complete',ratios=[x for x,_ in all_rows],median=median(v),order_stat_interval=[v[1],v[-2]],coverage=1-26/4096,orders=orders,seeds=seeds,p_above_two=p,qualifies=v[1]>2 and p<.05/2 and min(orders+seeds)>2)
    return result
def serial_source(fn):
    assert fn is o.pairs.outer
    src=inspect.getsource(fn);needle='            proc.stdin.close()\n        assert all(p.wait() == 0 for p in workers.values())'
    assert src.count(needle)==1
    return src.replace(needle,'            proc.stdin.close()\n            assert proc.wait() == 0')
def run(form,phase):
    cfg=read(config(form,phase));assert not (D/cfg['name']).exists()
    if phase!=PH[0]:
        assert gate(closed(form,PH[0]))
        if phase==PH[2]:assert len(closed(form,PH[1]))==6
    sys.path.insert(0,str(o.screen.SCOUT));import stage1
    host,_=stage1.original.v.local_receipt(stage1.RECEIPT,stage1.OLD)
    source=serial_source(o.pairs.outer)
    @contextmanager
    def already_locked(other):
        assert Path(other.__file__)==Path(host.__file__) and Path(other.native.__file__)==Path(host.native.__file__)
        assert set(other.locks())==set(host.locks())<set(locks) and len(set(locks))==4
        yield locks
    with h.watched(),stage1.PRE.four(host)as locks:
        h.floor();doc=subjects(True)
        with patch.object(stage1.PRE,'four',already_locked),patch.object(o,'order',order),patch.object(inspect,'getsource',side_effect=lambda f:source if f is o.pairs.outer else (_ for _ in ()).throw(AssertionError('unexpected source selector'))):
            o.outer(D,config(form,phase),doc)
    dest=D/cfg['name'];result=raw_rows(form,phase)
    files=[dest/'plan.json',dest/'subject-intake.json',dest/'pairs.jsonl']
    for k in ROLES:
        root=dest/k;files.extend([root/'identity.json',root/'edit.patch',root/'offclock-A/success.json',root/'offclock/success.json',*sorted(root.glob('*.zip'))])
    raw={str(p.relative_to(dest)):sha(p)for p in files};product.put(dest/'closed.json',{'registration':sha(REG),'raw':raw,'ratios':result})
    return {'form':form,'phase':phase,'rows':closed(form,phase)}
def main(args):
    seal=audit()
    if args==['audit']:return {'registration':seal,'rows':0}
    if args==['admit']:return subjects(True)
    if args[0]=='worker':worker(Path(args[1]),args[2]);return
    assert os.sched_getaffinity(0)=={29}
    if args==['all']:
        for form in base.FORMS:run(form,PH[0])
        for form in base.FORMS:
            if score(form)['opens']:
                for ph in PH[1:]:run(form,ph)
        return [score(form)for form in base.FORMS]
    form,phase=args;assert form in base.FORMS
    if phase=='score':return score(form)
    assert phase in PH
    return run(form,phase)
if __name__=='__main__':
    x=main(sys.argv[1:])
    if x is not None:print(json.dumps(x,sort_keys=True),flush=True)
