# Resolver native first edits with PR 306

From the task checkout, run the two independent discoveries and any eligible fresh held-outs serially.

```sh
D=work/uv-workflow-search/phase-costs/trait-rosters/build-test-ordinary/finite306
taskset -c 29 /usr/bin/python3 -ISB "$D/controls.py"
taskset -c 29 /usr/bin/python3 -ISB "$D/run.py" all
```

For a single native slot use `run.py build discovery` or `run.py test discovery`. Follow with `FORM confirm-1` and `FORM confirm-2` only when the signed/T4 median is at least 1.8. `FORM score` replays all available completed required cohorts. `admit` independently verifies the actual upstream SDK issuer. A partial phase stays in its original output directory and cannot qualify.

Both commands use an unwrapped signed −18 Cargo, locked and offline, with eight jobs on CPUs 0–15. The edit is the complete uncommitted uv parent b60da7ad to child 1979349b. Each phase independently cold-builds A on each arm. Setup alternates arm order across both forms and seeds. Within each phase three pairs run signed-first and three run T4-first. Each edit receives a private A target, source, Cargo state and home, with a clean A no-op and immediate B no-op. The B progress log must identify exactly uv-workspace, uv-types, uv-distribution and uv-resolver with newer compiler-invocation stamps. All raw clocks and non-timed complete product hashes remain separate.

Every pre/post product must be a real native resolver rlib or the executable Cargo itself announced, with the identical full 99-test inventory and no-op bytes. After all paired clocks each worker checks its own original A and B at their original paths. Build links a downstream Rust program directly against each measured rlib and checks three real ResolutionMode results. Test runs all 99 tests on the already-built A and B harness via the same Cargo with zero compilations. Both commands also execute the new actual B workspace regression with a bracket/question-mark directory and four exclusion patterns. Any failed oracle leaves the native phase unqualified. Both workers finish this QA in series.

Only the two new held-out cohorts contribute to the conditional 2× decision. The second-smallest of the twelve pair ratios must exceed 2, the one-sided exact sign test above 2 must pass 0.025 across the two endpoints, and both seed medians and both order medians must exceed 2. The second and eleventh order statistics have 99.3652% per-endpoint central coverage. The signed-vs-T4 comparison includes the different compiler, standard library and release configurations. T4 is the independently trained pre-BOLT image. The separate PR 306 resolver-check and earlier native measurements are input provenance and prior context only.

Allow roughly 5–8 minutes per six-pair cohort, including cold setup and off-clock correctness. This estimate uses older native inputs. Each cohort requires the original four exclusive leases, at least 55 GiB available RAM at intake, a 20-GiB private allocation per role, at least 3 GiB private reserve and 122 GiB free on each backing volume. Each role prices its true cold target before copying. Results land beside this script in FORM-PHASE-306-001.
