"""Small byte and source controls. Genuine archived inputs are unscored here."""
from pathlib import Path
import copy,hashlib,importlib.util,json,re,subprocess,sys
from zipfile import ZipFile
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('registered_native306',D/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
def refuse(fn,*args):
    try:fn(*args)
    except (AssertionError,RuntimeError,ValueError):return
    raise AssertionError(fn)
def check():
    seal=r.audit();doc=r.subjects()
    # The actual stage1 host/lease module must expose the genuine native foreign-process guard. No lease is taken here.
    sys.path.insert(0,str(r.o.screen.SCOUT));import stage1
    h,_=stage1.original.v.local_receipt(stage1.RECEIPT,stage1.OLD);leases=stage1.PRE.read(stage1.PRE.LEASES)['all_four_locks'];assert callable(h.native.foreign) and len(set(leases))==4 and set(h.locks())<set(leases)
    for k in r.ROLES:
        rep=r.read(r.PRIOR/k/'identity.json');r.identity(rep,doc['arms'][k])
        for key in ('cargo','launcher','linked'):
            wrong=copy.deepcopy(rep)
            if key=='linked':wrong[key].pop(next(iter(wrong[key])))
            else:wrong[key]='f'*64
            refuse(r.identity,wrong,doc['arms'][k])
    # Original cohort data are schema controls only. Pair identity and raw Cargo clock must agree.
    actual=json.loads((r.PRIOR/'pairs.jsonl').read_text().splitlines()[0]);two={k:v for k,v in actual.items()if k in r.ROLES};seq=list(two)
    for k in r.ROLES:
        with ZipFile(r.PRIOR/k/'pair-1.zip')as z:args=[json.loads(z.read(l+'.json')) for l in ('settled-A','edit-D','noop-D')]
        r.paired(two,seq,1,k,*args);refuse(r.paired,dict(reversed(list(two.items()))),seq,1,k,*args)
        wrong=copy.deepcopy(two);wrong[k]['edit']+=.001;refuse(r.paired,wrong,seq,1,k,*args)
    receipts={}
    for form in r.base.FORMS:
        old=r.base.replay('signed18',form);assert sorted(old['first_edit']['dirty_units'])==sorted(r.product.DIRTY)
        with ZipFile(r.base.HERE/f'signed18-{form}-001/records.zip')as z:
            c='resolver-'+form+'/';a=json.loads(z.read(c+'settled.artifact.json'));b=json.loads(z.read(c+'noop.artifact.json'))
            assert a==json.loads(z.read(c+'warm.artifact.json')) and b==json.loads(z.read(c+'first-edit.artifact.json'))
            if form=='test':
                listing=z.read(c+'noop.test-list');names=r.product.roster(listing);assert len(names)==99
                refuse(r.product.roster,listing.replace(names[0].encode(),b'fake_other_owner',1))
            raw=z.read(c+'first-edit.stderr');units=[s.decode().replace('-','_')for s in re.findall(rb'^\s*(?:Compiling|Checking) ([\w-]+) v',raw,re.M)];assert units==r.product.DIRTY
            receipts[form]={'raw_sha256':hashlib.sha256(raw).hexdigest(),'units':units,'resolver_bytes':[a['size'],b['size']]}
    case=r.phases('build')[0];r.order(case);refuse(r.order,case|{'pairs':5})
    good=[(1.8,'stock'),(1.8,'candidate')]*3;assert r.gate(good);assert not r.gate([(1.79,k)for _,k in good]);refuse(r.gate,good[:-1]);refuse(r.gate,[(3,'stock')]*6)
    artifact={'path':'debug/libuv_resolver.rlib','size':10};units={k:['true-roster-fixture',1]for k in r.product.DIRTY}
    first={'artifact':artifact,'sha256':'d'*64,'units':units};last=first|{'units':{k:[v[0],2]for k,v in units.items()}}
    r.product.transition(first,last,True);r.product.transition(last,last,False)
    refuse(r.product.transition,first,last,False);refuse(r.product.transition,first,first,True)
    wrong=copy.deepcopy(last);wrong['units']['uv_resolver'][1]=1;refuse(r.product.transition,first,wrong,True)
    source=r.serial_source(r.o.pairs.outer);assert source.count('proc.wait() == 0')==1
    repo=Path(r.base.PROTO['bank'])/'uv.git';fn='crates/uv-workspace/src/workspace.rs'
    git=['git','--no-lazy-fetch','--git-dir',str(repo),'show']
    a,b=[subprocess.check_output(git+[rev+':'+fn])for rev in (r.base.A,r.base.B)]
    test=r.product.FOCUSED.split('::')[-1].encode();assert test not in a and b.count(test)==1
    assert b'workspace[glob]?' in b and b'assert_json_snapshot!' in b[b.index(test):]
    resolver=subprocess.check_output(git+[r.base.B+':crates/uv-resolver/src/resolution_mode.rs'])
    assert all(x in resolver for x in (b'"highest"',b'"lowest"',b'"lowest-direct"'))
    return {'registration':seal,'historical_raw_controls':receipts,'scripts':'fragments validated against actual merged source and SDK receipts','benchmark_rows':0}
if __name__=='__main__':print(json.dumps(check(),sort_keys=True))
