"""Off-clock identity and behavior of the concrete resolver product."""
import hashlib,json,os,re,shutil,subprocess
from pathlib import Path

LIST='ec73b0be264a4f677a47495384b47f0de80d9a28308e474424db446a4554920f'
FOCUSED='workspace::tests::exclude_package_with_normalized_glob_and_escaped_root'
DIRTY=['uv_workspace','uv_types','uv_distribution','uv_resolver']
def sha(p):
    with p.open('rb')as s:return hashlib.file_digest(s,'sha256').hexdigest()
def put(p,x):
    with p.open('x')as s:json.dump(x,s,indent=2)
def need(g,msg):
    if not g:raise RuntimeError(msg)
def roster(raw):
    names=[l[:-6]for l in raw.decode().splitlines() if l.endswith(': test')]
    need(len(names)==len(set(names))==99 and hashlib.sha256(raw).hexdigest()==LIST,'exact original 99-test roster')
    return sorted(names)
def passed(raw,names):
    actual=sorted(re.findall(r'^test ([\w:]+) \.\.\. ok$',raw.decode(),re.M))
    need(actual==names and f'test result: ok. {len(names)} passed; 0 failed; 0 ignored; 0 measured;'.encode() in raw,'complete native successes')


def take(base,run,env,target,form,label,cmd):
    base.output_witness(run,env,target,form,label)
    stat=json.loads((run/(label+'.artifact.json')).read_bytes());artifact=target/stat['path']
    stamps={}
    for name in DIRTY:
        kind='test-lib-' if name=='uv_resolver' and form=='test' else 'lib-'
        [finger]=(target/'debug/build'/name.replace('_','-')).glob('*/fingerprint/'+kind+name+'.json')
        stamps[name]=[finger.parent.parent.name,(finger.parent/'invoked.timestamp').stat().st_mtime_ns]
    content={'artifact':stat,'sha256':sha(artifact),'units':stamps}
    if form=='test':
        listing=subprocess.check_output([artifact,'--list'],cwd=base.screen.SRC,env=env,timeout=45)
        roster(listing);(run/(label+'.listing')).write_bytes(listing);content['listing']=LIST
    else:
        members=subprocess.check_output(['/usr/bin/ar','t',artifact],env=env,timeout=45)
        assert len(members)<4<<20 and b'lib.rmeta' in members.splitlines() and any(k.endswith(b'.o')for k in members.splitlines())
        content['archive_members']=hashlib.sha256(members).hexdigest();(run/(label+'.members')).write_bytes(members)
    put(run/(label+'.verified.json'),content)
    return content


def transition(a,b,changed):
    assert a['artifact']['path']==b['artifact']['path']
    if changed:
        assert all(a['units'][k][0]==b['units'][k][0] and a['units'][k][1]<b['units'][k][1]for k in DIRTY)
    else:assert a==b


def offclock(form,env,target,sdk,src,out,actual_state,revision):
    env=env|{'INSTA_UPDATE':'no'}
    primary=target/actual_state['artifact']['path'];assert sha(primary)==actual_state['sha256']
    def execute(name,cmd,expected=None):
        p=subprocess.run(cmd,cwd=src,env=env,capture_output=True,timeout=400)
        for key,data in [('out',p.stdout),('err',p.stderr)]:
            assert len(data)<4<<20;(out/(name+'.'+key)).write_bytes(data)
        put(out/(name+'.json'),{'argv':list(map(str,cmd)),'exit':p.returncode,'stdout':hashlib.sha256(p.stdout).hexdigest(),'stderr':hashlib.sha256(p.stderr).hexdigest()})
        assert p.returncode==0,(name,p.stderr[-1200:])
        if expected is not None:assert p.stdout==expected
        return p
    cargo=sdk/'bin/cargo'
    if form=='test':
        listing=execute('exact-list',[primary,'--list']).stdout
        p=execute('all-resolver-tests',[cargo,'test','-p','uv-resolver','--lib','--locked','--offline','-j8','--','--test-threads=1'])
        assert not re.search(rb'^\s*(Checking|Compiling) ',p.stderr,re.M)
        assert os.fsencode(primary.name) in p.stderr
        passed(p.stdout,roster(listing))
    else:
        root=target.parent/('resolver-rlib-client-'+revision);root.mkdir()
        client=root/'client.rs';client.write_bytes((Path(__file__).parent/'client.rs').read_bytes())
        extern_dirs={p.parent for glob in ('*.rlib','*.rmeta','*.so') for p in target.rglob(glob) if p.is_file()}
        native_dirs={p.parent for p in target.rglob('*.a') if p.is_file()}
        args=[sdk/'bin/rustc','--crate-name','resolver_product_check','--edition=2024',client,'--extern','uv_resolver='+str(primary)]
        for ty,items in [('dependency',extern_dirs),('native',native_dirs)]:
            for path in sorted(items):args+=['-L',ty+'='+str(path)]
        exe=root/'client';execute('link-measured-rlib',[*args,'-o',exe])
        execute('run-rlib-client',[exe],b'highest|lowest|lowest-direct\n')
    # The edit's actual checked-in regression, including the literal bracket/question-mark workspace root.
    if revision=='A':
        assert sha(primary)==actual_state['sha256'];return
    assert revision=='B'
    p=execute('changed-workspace-test',[cargo,'test','-p','uv-workspace','--lib','--locked','--offline','-j8',FOCUSED,'--','--exact','--test-threads=1'])
    passed(p.stdout,[FOCUSED]);assert sha(primary)==actual_state['sha256']
