"""Run the packaged raw-evidence verifier with Python 3.11+ and its standard library."""
import argparse
import ast
from collections import Counter
import copy
import csv
from decimal import Decimal
from fractions import Fraction
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
from statistics import median
import subprocess
import sys
import tempfile
import zipfile

BASE,NEW="signed18","gnu22-cargo18"
ARMS=(BASE,NEW)
A="deba0cbdc329d0a6cd118d5e1d58a203df08c0d3"
B="801cb8566547b0d74690a0daf9c795502a5ddafb"
CARGO="02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
REG="1c4f263c9569bbae9e9591b1a0580694642ece89f5a1321c0fca2a6f2a7b739b"
POST="8b95bde06acefef97e4405a21b0a4256d93f29b7"
COMMAND=["/tmp/ohm-literal-launcher-22742/sdk/bin/cargo","build","--locked","--offline","-j8","-p","uv","--bins"]
HARD="/dev/null/ohm-untracked-relink-inputs"
DATA_STDIN=b"launcher\0stdin\nnon-UTF8-\xff\n"
ARG_BYTES=(b"--",b"",b"path with spaces",b"two\nlines",b"non-UTF8-\xff")
def need(ok,why):
    if not ok:raise ValueError(why)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def gblob(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
class Files:
    def __init__(self,z):self.z=z
    def raw(self,name):return self.z.read(name)
    def j(self,name):return json.loads(self.raw(name))
    def hash(self,name):return sha(self.raw(name))
    def text(self,name):return self.raw(name).decode()
    def check_manifest(self):
        entries=self.z.infolist();names=[x.filename for x in entries]
        need(len(entries)<750 and len(names)==len(set(names)) and sum(x.file_size for x in entries)<8_000_000,"unbounded or duplicate archive member")
        manifest=self.j("SHA256.json")
        need(set(manifest)==set(names)-{"SHA256.json"},"manifest membership")
        for name,digest in manifest.items():need(self.hash(name)==digest,"changed bytes: "+name)

def source(files):
    new=files.raw("uv/B-uvx.rs");old=files.raw("uv/A-uvx.rs")
    edits=files.j("uv/upstream-paths.json")
    need(len(edits)==1 and edits[0]["filename"]=="crates/uv/src/bin/uvx.rs" and edits[0]["status"]=="modified"
         and files.j("uv/A-commit.json")["sha"]==A and files.j("uv/B-commit.json")["sha"]==B
         and files.j("uv/B-commit.json")["parents"]==[A] and edits[0]["sha"]==gblob(new)==POST
         and gblob(old)=="074817b3f41536438e5d61642f5a15122a3ab5b1" and gblob(files.raw("uv/Cargo.lock"))=="587877fa59ff962b6f636fde2cd3c3926ef12ad3","literal source, lock or parent")
    source_ids=files.j("history/source-lines.json")
    for label,path in (("C18 command","cargo18-compiler.rs"),("R22 writer","rust22-driver.rs"),("R22 default","rust22-options.rs")):
        reg=next(x for x in source_ids if x["label"]==label)
        raw=files.raw("history/"+path)
        need(sha(raw)==reg["sha256"] and gblob(raw)==reg["blob"],"compiler or Cargo source identity")
    need("-Zohm-check-relink-inputs" not in files.text("history/cargo18-compiler.rs") and
         "ohm_check_relink_inputs: bool = (false," in files.text("history/rust22-options.rs") and
         "if !check_relink_inputs {\n                passes::write_dep_info_for_outputs(tcx, &output_paths, false);" in files.text("history/rust22-driver.rs"),
         "unchecked Cargo18 and GNU22 dep-info path")
    lines=old.decode().splitlines();decoded=[];i=0
    for line in edits[0]["patch"].splitlines():
        if line.startswith("@@"):
            match=re.match(r"@@ -(\d+)(?:,\d+)? \+",line);need(match,"bad hunk")
            start=int(match[1])-1;need(start>=i,"overlapping hunks");decoded.extend(lines[i:start]);i=start
        elif line.startswith((" ","-","+")):
            if line[0]!="+":need(lines[i]==line[1:],"wrong hunk preimage");i+=1
            if line[0]!="-":decoded.append(line[1:])
        else:raise ValueError("invalid patch")
    need(("\n".join(decoded+lines[i:])+"\n").encode()==new,"wrong hunk postimage")

def product(files,folder,obs):
    need(files.j(folder+"/status.json")=={"uv":0,"uvx":0,"json":0} and all(files.raw(folder+"/"+n+".stderr")==b"" for n in ("uv","uvx","json")),"native process status")
    need(files.j(folder+"/programs.json")==obs["programs"] and files.j(folder+"/git.json")==obs["git"]==files.j("uv/git-version.json")["bank"][A],"ELF owners or historical Git")
    admitted=files.j("uv/product-admission.json")["ordinary"]
    need(files.j(folder+"/json.stdout")==obs["detail"]==admitted["serialized"] and obs["detail"]["commit_info"] is None and
         {n:files.text(folder+"/"+n+".stdout") for n in ("uv","uvx")}==obs["versions"]==admitted["public_strings"],"ordinary native version")
    for key,exe in (("uvx@pair",b"uv@pair"),("uvx@fallback",b"uv")):
        need(obs["argv_and_exit"][key]=={"exit":37,"stderr":"","stdout_hex":(b"\0".join([exe,b"tool",b"uvx",*ARG_BYTES])+b"\0").hex()},"argv byte forwarding")
    need(obs["argv_and_exit"]==files.j("oracle/behavior-control.json")["observed"]["cases"] and obs["raw_stdin_hex"]==DATA_STDIN.hex() and obs["child_exit"]==37,"stdin, exit or missing companion")
    for name,x in obs["programs"].items():
        need(re.fullmatch(r"build/uv/[0-9a-f]+/out/"+name,x["producer"]) and len(x["sha256"])==64 and x["bytes"]>0,"complete binary ownership")

def clock(files,folder,kind,cl):
    need(cl==files.j(folder+"/"+kind+"-clock.json") and cl["argv"]==COMMAND and cl["exit"]==0 and cl["pid"]>0 and
         0<cl["start_ns"]<cl["end_ns"] and cl["wall_ns"]==cl["end_ns"]-cl["start_ns"],"raw timing")
    err=files.raw(folder+"/"+kind+".stderr");out=files.raw(folder+"/"+kind+".stdout")
    need(sha(err)==cl["stderr"] and sha(out)==cl["stdout"] and out==b"" and b"Finished" in err,"raw Cargo output")
    compiled=re.findall(rb"^\s*(?:Compiling|Checking)\s+(\S+)",err,re.M)
    need(compiled==[s.encode() for s in cl["packages"]],"raw Cargo roster")
    if kind in ("seed","cold-A"):need(b"uv" in compiled,"missing seed compilation")
    elif kind=="edit":need(compiled==[b"uv"] and re.search(rb"^\s*Compiling\s+uv\s",err,re.M),"B did not actually compile uv")
    else:need(not compiled and cl["write_closed_ns"] is None,"control compiled a target")

def row(files,folder,obs,seed,expected,include_stamps=True):
    a,b=obs["A"],obs["B"]
    need(obs["head"]==A and obs["postimage"]==POST and a==seed["A"] and b==expected and obs["seed"]==seed["archive"],"incorrect fresh restoration or source")
    product(files,folder+"/product-A",a);product(files,folder+"/product-B",b)
    need(a["programs"]["uv"]==b["programs"]["uv"] and a["programs"]["uvx"]["sha256"]!=b["programs"]["uvx"]["sha256"] and
         {k:v for k,v in a.items() if k!="programs"}=={k:v for k,v in b.items() if k!="programs"},"native A/B relation")
    c=obs["clocks"];need(set(c)=={"sham","edit","noop"},"missing clock")
    for k,v in c.items():clock(files,folder,k,v)
    need(c["edit"]["write_closed_ns"] is not None and c["sham"]["end_ns"]<=c["edit"]["write_closed_ns"]<=c["edit"]["start_ns"] and c["edit"]["end_ns"]<=c["noop"]["start_ns"],"actual first edit sequence")
    if include_stamps:
        s=obs["stamps"]
        for label,prod in (("sham",a),("noop",b)):
            l,r=s["before_"+label],s["after_"+label]
            need(l==r and set(l)=={"uv","uvx"} and all(len(x)==4 and x[2]==prod["programs"][name]["bytes"] for name,x in l.items()),"no-op touched ELF")
        need(s["before_sham"]["uv"]==s["before_noop"]["uv"] and s["before_sham"]["uvx"]!=s["before_noop"]["uvx"],"wrong rewritten program")
    return tuple(c[k]["wall_ns"] for k in ("edit","sham","noop"))

def roster(obs,expected):
    need(obs["order"]==expected and set(obs["arms"])==set(ARMS),"mixed order or missing arm")

def direct(f):
    reg=f.j("protocol/registration.json");ret=f.j("direct/worker-return.json");q=f.j("direct/complete.json")
    need(f.hash("protocol/registration.json")==REG==q["registration"]==f.j("direct/intake.json")["registration"] and
         ret["exit"]==ret["worker_exit"]==0 and ret["complete"]==f.hash("direct/complete.json") and q["phase"]=="discovery","unclosed cohort")
    need(q["triplets"]==f.hash("direct/triplets.json") and q["subjects"]==f.hash("uv/subjects.json") and q["sdks"]==f.hash("direct/actual-sdks.json"),"phase seals")
    seeds={};versions=f.j("direct/actual-sdks.json");sdk=f.j("uv/subjects.json")
    for arm in ARMS:
        folder="direct/seed-"+arm;seed=seeds[arm]=f.j(folder+"/seed.json")
        cold=f.j(folder+"/cold-A-clock.json");clock(f,folder,"cold-A",cold);clock(f,folder,"settled",f.j(folder+"/settled-clock.json"))
        need(seed["identity"]==q["seed_ids"][arm]==["discovery",arm,cold["pid"],cold["start_ns"],cold["end_ns"]] and
             {k:v for k,v in seed.items() if k!="identity"}==q["seeds"][arm],"wrong independent A")
        need(versions[arm]["cargo_sha256"]==sdk["arms"][arm]["effective_cargo"]==CARGO and
             versions[arm]["driver"]==sdk["arms"][arm]["driver_sha256"] and versions[arm]["driver"] in versions[arm]["loaded"],"wrong compiler stack")
        product(f,folder+"/product-A",seed["A"])
    need(versions[BASE]["driver"]!=versions[NEW]["driver"] and all(sdk["arms"][BASE]["files"][k]["sha256"]==sdk["arms"][NEW]["files"][k]["sha256"] for k in sdk["runtime_linkers"]),"common native tools")
    rows=f.j("direct/triplets.json");orders=reg["orders"]["discovery"]
    need(len(rows)==len(orders)==6 and Counter(map(tuple,orders))=={ARMS:3,ARMS[::-1]:3},"balanced six-pair discovery")
    allrows=[];previous=-1
    for n,(saved,order) in enumerate(zip(rows,orders),1):
        roster(saved,order);timings={}
        for arm in order:
            folder="direct/r"+str(n)+"-"+arm;rr=saved["arms"][arm];obs=f.j(folder+".json")
            need(rr["receipt"]==f.hash(folder+".json") and obs["order"]==order and obs["phase"]=="discovery" and obs["role"]==arm and
                 rr["sha_seed"]==seeds[arm]["archive"],"wrong arm, raw receipt or history")
            first,sham,noop=row(f,folder,obs,seeds[arm],q["B"][arm]);cs=obs["clocks"]
            need((first,sham,noop)==(rr["edit_ns"],rr["sham_ns"],rr["noop_ns"]) and cs["sham"]["start_ns"]>previous,"wrong row or physical order")
            previous=cs["noop"]["end_ns"];timings[arm]={"B_ns":first,"sham_ns":sham,"noop_ns":noop}
        allrows.append({"pair":n,"order":order,**timings})
    ratios=[Fraction(r[BASE]["B_ns"],r[NEW]["B_ns"]) for r in allrows]
    for v,r in zip(ratios,allrows):r["ratio_fraction"]=str(v);r["ratio"]=float(v)
    passed=median(ratios)>=Fraction(18,10)
    need(not passed and reg["discovery"]=={"excluded":True,"pairs":6,"required_median":1.8},"published discovery gate")
    summary={"pairs":allrows,"median_paired_fraction":str(median(ratios)),"median_paired_ratio":float(median(ratios)),
             "median_B_ns":{a:median(r[a]["B_ns"] for r in allrows) for a in ARMS},"GNU22_faster":sum(v>1 for v in ratios),
             "noop_exceeds_B":{a:sum(r[a]["noop_ns"]>r[a]["B_ns"] for r in allrows) for a in ARMS},"eligible_for_holdouts":passed}
    return summary,rows

def predecessor(f):
    ret=f.j("previous/worker-return.json")
    need(ret["exit"]==ret["worker_exit"]==1 and ret["complete"] is None and
         'first compilation indistinguishable from hot no-op' in f.text("previous/worker.log"),"excluded original failure")
    a=f.j("previous/seed-gnu22-cargo18/seed.json")["A"];root="previous/r1-gnu22-cargo18";b=copy.deepcopy(a)
    for item,file in (("programs","programs.json"),("detail","json.stdout"),("git","git.json")):b[item]=f.j(root+"/product-B/"+file)
    b["versions"]={k:f.text(root+"/product-B/"+k+".stdout") for k in ("uv","uvx")}
    cs={n:f.j(root+"/"+n+"-clock.json") for n in ("sham","edit","noop")};seed=f.j("previous/seed-gnu22-cargo18/seed.json")
    # The earlier closed worker passed changed(a,b) before its duration check.
    x={"A":a,"B":b,"head":A,"postimage":POST,"clocks":cs,"seed":seed["archive"]}
    first,sham,noop=row(f,root,x,seed,b,include_stamps=False)
    need((first,sham,noop)==(716652635,465659990,880143810) and first<noop,"real counterexample")
    return {"unpaired":True,"excluded":True,"B_ns":first,"sham_ns":sham,"noop_ns":noop}
def diagnostic(f):
    outer=f.j("signed21/observed.json");ret=f.j("signed21/worker-return.json")
    need(ret["result"]==f.hash("signed21/observed.json") and outer["source_edit_count"]==outer["scored_first_B_rows"]==ret["scored_first_B_rows"]==0,
         "signed21 is an unchanged separate diagnostic")
    from trace_parser import record_exec
    need(f.j("signed21/cold-A-clock-unwrapped.json")["wall_ns"]==109306559035 and
         f.j("signed21/first-repeat-clock-unwrapped.json")["wall_ns"]==1819395173,"separate unwrapped cold and first repeat")
    obj=next(iter(f.j("signed21/cold/actual-root-object-instructions.json")["objects"].values()))
    need(Counter(x["instruction"].split(":",1)[1].split()[0] for x in obj["example"])=={"pcmpeqb":6,"pand":4,"pmovmskb":2},"actual rlib instructions")
    out=[];units=["constant_time_eq","blake3","uv","uvx"];previous_source=None
    for i in range(1,4):
        side="repeat-"+str(i);p="signed21/"+side+"/";meta=f.j(p+"observed.json");snap=f.j(p+"dependency-snapshot.json")
        need(meta["complete_raw_cargo"]==f.hash(p+"cargo.stderr.gz") and meta["complete_raw_execve"]==f.hash(p+"execve.trace.gz"),"original native traces")
        log=gzip.decompress(f.raw(p+"cargo.stderr.gz")).decode();trace=gzip.decompress(f.raw(p+"execve.trace.gz")).decode()
        cmd=record_exec(trace.splitlines());rust=[c for c in cmd["processes"] if c["exe"].endswith("/bin/rustc")]
        labels=re.findall(r"^\s*(?:Compiling|Checking)\s+(\S+)",log,re.M)
        need(len(labels)==36 and labels==meta["cargo_labels"]==outer["stages"][side]["Cargo_packages"] and
             [c["crate"] for c in rust]==meta["rustc_compiles"]==units and all(c["rustc_probe"] is False for c in rust) and
             len([c for c in cmd["processes"] if c["exe"].endswith("/wild-ld/ld.bfd")])==2,"actual rustc/labels/linker roster")
        for c in rust[:2]:
            need('"-Zohm-check-relink-inputs"' in c["root_argv_line"],"actual checked native library")
            k=c["crate"];need(any("package_id="+k+" " in line and 'target="'+k+'"' in line and
                'dirty: FsStatusOutdated(StaleItem(MissingFile { path: "'+HARD+'" }))' in line for line in log.splitlines()),"each independent missing input")
            leaves=[x for x in snap["marker_appearances"] if "/"+k+"/" in x["path"]]
            need(len(leaves)==2 and all(x["markers"]==[HARD] for x in leaves) and snap["marker_stat"][HARD]["errno"]==20,"crate and Cargo dep-info")
        need(all(x in rust[1]["root_argv_line"] for x in ('"static=blake3_sse2_sse41_avx2_assembly"','"static=blake3_avx512_assembly"')),"bundled blake3 archives")
        need(all(any('target="'+k+'"' in l and 'dirty: FsStatusOutdated(StaleDepFingerprint' in l for l in log.splitlines()) for k in ("uv","uvx")),"downstream fingerprint")
        facts=snap["root_dep_input_facts"]
        if previous_source is not None:need(facts==previous_source,"unchanged crate sources")
        previous_source=facts
        arrival=int(Decimal(rust[0]["time"])*10**9)
        fingerprint=next(v["mtime_ns"] for k,v in snap["files"].items() if k.endswith("/fingerprint/lib-constant_time_eq.json"))
        span=(fingerprint-arrival)/1e6;overlap=(int(Decimal(rust[1]["time"])*10**9)-arrival)/1e6
        need(round(span,3)==f.j("signed21/analysis.json")["stages"][side]["trace_exec_to_success_fingerprint_ms"]["constant_time_eq"] and 0<overlap<span,"overlapping instrumented window")
        out.append({"repeat":i,"traced_wall_ns":meta["trace_elapsed_ns"],"cargo_labels":len(labels),"rustc_units":units,"linkers":2,
                    "cte_exec_to_success_fingerprint_ms":round(span,3),"cte_to_blake3_exec_ms":round(overlap,3)})
    headline=f.j("signed21/matched-instruction-probes/cases.json")
    for k,d in headline.items():
        actual=f.raw("signed21/matched-instruction-probes/"+k+".d")
        need(d["returncode"]==0 and d["marker"]==(HARD.encode() in actual) and
             d["advisory"]==(b"/dev/null/ohm-recheck-dependent-links" in actual),"standalone probe dep-info")
    need(all(headline[k]["marker"] for k in ("pcmpeqb","pand","pmovmskb","external","external-changed")) and
         headline["external"]["product"]!=headline["external-changed"]["product"] and not headline["none"]["marker"] and
         headline["comment"]["advisory"] and not headline["comment"]["marker"],"true native-input controls")
    patch=next(p["patch"] for p in f.j("history/ohm-rust-266-files.json") if p["filename"].endswith("/asm.rs"))
    need("NativeLibKind::Static { bundle: None | Some(true)" in patch and "return RelinkInputs::Rebuild;" in patch,"#266 archive guard")
    return out

def historical(f):
    result={}
    for name in ("bins","test"):
        records=list(csv.DictReader(io.StringIO(f.text("history/"+name+"-matched-pairs.csv"))))
        if name=="test":records=[r for r in records if r["synthetic"]=="False" and r["credited"]=="True" and r["kind"]=="timed" and r["scope"]=="combined"]
        need(len(records)==12,"earlier matched pairs")
        rs=[Fraction(int(r["control_ns"]),int(r["candidate_ns"])) for r in records];v=median(rs)
        need(min(rs)>2 and round(float(v),3)=={"bins":4.235,"test":3.183}[name],"prior matched comparison")
        result[name]={"pairs":12,"median_paired_ratio":float(v),"base":"Ohm -20 source plus #270","treatment":"same plus #275"}
    return result

def negative_controls(f,rows):
    def rejected(fn,label):
        try:fn()
        except ValueError:return
        raise ValueError("accepted negative control: "+label)
    expected=rows[0]["order"]
    x=copy.deepcopy(rows[0]);del x["arms"][NEW];rejected(lambda:roster(x,expected),"missing arm")
    y=copy.deepcopy(rows[0]);y["order"]=y["order"][::-1];rejected(lambda:roster(y,expected),"mixed order")
    class Fake(Files):
        # A consistent source of fresh Cargo stderr and corresponding clock hash,
        # while still masquerading as the recorded B command.
        def raw(self,name):
            prefix="direct/r1-"+NEW+"/"
            if name==prefix+"edit.stderr":return f.raw(prefix+"noop.stderr")
            if name==prefix+"edit-clock.json":
                c=f.j(name);c.update(packages=[],stderr=f.hash(prefix+"noop.stderr"));return json.dumps(c).encode()
            return f.raw(name)
    fake=Fake(f.z);folder="direct/r1-"+NEW;c=fake.j(folder+"/edit-clock.json")
    rejected(lambda:clock(fake,folder,"edit",c),"fresh fake B")
    x=f.j(folder+".json");x["B"]=x["A"];seed=f.j("direct/seed-"+NEW+"/seed.json")
    rejected(lambda:row(f,folder,x,seed,x["B"]),"unchanged ELF")
    return ["missing arm","swapped order","fresh fake B","unchanged ELF"]

def native(f,arm,side,root):
    from native_forwarding import observe,ENV,ARGUMENTS
    root=Path(root).resolve(strict=True);x=f.j("direct/r1-"+arm+".json")[side]
    for n in ("uv","uvx"):
        image=root/n;phys=x["programs"][n];owner=root/phys["producer"]
        need(image.is_file() and owner.is_file() and image.stat().st_size==phys["bytes"],"supply a matching Cargo debug directory")
        for p in (image,owner):
            with p.open("rb") as h:need(hashlib.file_digest(h,"sha256").hexdigest()==phys["sha256"],"binary digest: "+str(p))
        cmd=subprocess.run([image,"--version"],env=ENV,capture_output=True,timeout=10)
        need((cmd.returncode,cmd.stdout.decode(),cmd.stderr)==(0,x["versions"][n],b""),"native version")
    cmd=subprocess.run([root/"uv","self","version","--output-format","json"],env=ENV,capture_output=True,timeout=10)
    need(cmd.returncode==0 and cmd.stderr==b"" and json.loads(cmd.stdout)==x["detail"],"native serialized version")
    import shutil
    with tempfile.TemporaryDirectory() as temp:
        tmp=Path(temp)
        result=observe(root/"uvx",tmp)
        need(result["binary_sha256"]==x["programs"]["uvx"]["sha256"] and result["cases"]==x["argv_and_exit"],"native non-UTF8 argv/exit")
        front=tmp/"uvx";shutil.copy2(root/"uvx",front);comp=tmp/"uv"
        comp.write_text("#!/usr/bin/python3 -ISB\nimport sys\nsys.stdout.buffer.write(sys.stdin.buffer.read());sys.exit(37)\n");comp.chmod(0o755)
        cmd=subprocess.run([front,*ARGUMENTS],input=DATA_STDIN,env=ENV,capture_output=True,timeout=10)
        need((cmd.returncode,cmd.stdout,cmd.stderr)==(37,DATA_STDIN,b""),"real raw stdin forwarding")

def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--products",nargs=3,metavar=("ARM","A_OR_B","DEBUG_DIR"),help="also run independent native product witnesses against an exactly matching Cargo target")
    args=arg.parse_args()
    with zipfile.ZipFile(sys.argv[0]) as z:
        f=Files(z);f.check_manifest();source(f);score,rows=direct(f)
        result={"historical_release_discovery":score,"earlier_unpaired":predecessor(f),"signed21_unchanged":diagnostic(f),"prior_source_matched":historical(f),"rejected_controls":negative_controls(f,rows)}
        if args.products:
            role,side,root=args.products;need(role in ARMS and side in ("A","B"),"role or side");native(f,role,side,root);result["native_products_executed"]=[role,side]
        print(json.dumps(result,indent=2))
if __name__=="__main__":main()
