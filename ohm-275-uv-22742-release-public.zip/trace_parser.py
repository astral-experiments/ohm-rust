"""Verbatim kernel-exec parser from the certified signed -21 diagnostic."""
import ast
from pathlib import Path
import re
PKGS=("constant_time_eq","blake3","uv")
def record_exec(stream):
    pending={};events=[];other=0;all_calls=0
    line_re=re.compile(r"^\s*(\d+)\s+([0-9.]+)\s+(.*)")
    for line in stream:
        m=line_re.match(line)
        if not m:continue
        pid,ts,body=m.groups()
        if body.startswith(("execve(","execveat(")):
            one=body
            if "<unfinished ...>" in body:
                pending[pid]=(ts,body.split("<unfinished ...>",1)[0]);continue
        elif body.startswith(("<... execve resumed>","<... execveat resumed>")):
            old=pending.pop(pid,None)
            if old is None:continue
            ts,before=old;one=before+body.split("resumed>",1)[1]
        else:continue
        if not re.search(r"\)\s+= 0\s*$",one):continue
        q=re.findall(r'"(?:\\.|[^"\\])*"',one)
        if not q:continue
        exe=ast.literal_eval(q[0]);base=Path(exe).name;all_calls+=1
        if base not in ("rustc","cargo","wild","ld.bfd","rust-lld","ld.lld","clang","cc","cc1","collect2","as") and not base.endswith(("-rustc","-wild","-gcc","-as")):
            other+=1;continue
        words=[ast.literal_eval(word) for word in q[1:]]
        crate=words[words.index("--crate-name")+1] if "--crate-name" in words and words.index("--crate-name")+1<len(words) else None
        events.append({"pid":int(pid),"time":ts,"exe":exe,"crate":crate,"rustc_probe":base=="rustc" and crate is None,"root_argv_line":one if crate in PKGS or crate=="uvx" else None})
    return {"all_successful_execs":all_calls,"other_execs":other,"processes":events}
