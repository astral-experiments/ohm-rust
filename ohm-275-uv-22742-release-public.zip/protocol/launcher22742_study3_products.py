"""Verify the two complete public ELF files, their Cargo owners, and real launcher behavior."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import launcher22742_study3_common as c

sp=importlib.util.spec_from_file_location("published_uvx_forwarding_oracle",c.OLD/"behavior.py")
oracle=importlib.util.module_from_spec(sp);sp.loader.exec_module(oracle)
STDIN=b"launcher\x00stdin\nnon-UTF8-\xff\n"

def owners(root,name,file):
    candidates=[*root.glob("build/uv/*/out/"+name),*root.glob("deps/"+name+"-*")]
    possible=[p for p in candidates if p.is_file() and not p.is_symlink() and p.suffix=="" and p!=file
              and p.stat().st_size==file.stat().st_size and os.access(p,os.X_OK)]
    actual=[p for p in possible if p.samefile(file)]
    if not actual:actual=[p for p in possible if c.sha(p)==c.sha(file)]
    c.need(len(actual)==1,("ambiguous Cargo producer",name,len(actual)))
    return str(actual[0].relative_to(root))

def binary(root,name):
    file=root/name
    c.need(file.is_file() and not file.is_symlink() and os.access(file,os.X_OK),"missing public ELF "+name)
    with file.open("rb") as f:header=f.read(64)
    c.need(header[:7]==b"\x7fELF\x02\x01\x01" and struct.unpack_from("<H",header,18)[0]==62,"invalid native x86-64 ELF")
    return {"bytes":file.stat().st_size,"sha256":c.sha(file),"producer":owners(root,name,file)}

def check(root,env,rev,evidence):
    evidence.mkdir()
    commands={"uv":[root/"uv","--version"],"uvx":[root/"uvx","--version"],
              "json":[root/"uv","self","version","--output-format","json"]}
    statuses={}
    for name,argv in commands.items():
        with (evidence/(name+".stdout")).open("xb") as out,(evidence/(name+".stderr")).open("xb") as err:
            try:statuses[name]=subprocess.run(argv,cwd=c.SOURCE,env=env,stdout=out,stderr=err,timeout=25).returncode
            except (OSError,subprocess.TimeoutExpired) as error:statuses[name]=str(error)
    c.write(evidence/"status.json",statuses)
    c.need(all(x==0 for x in statuses.values()) and all((evidence/(n+".stderr")).stat().st_size==0 for n in statuses),
           "public command exit or stderr; see "+str(evidence))
    raw={n:(evidence/(n+".stdout")).read_text() for n in ("uv","uvx")}
    detail=json.loads((evidence/"json.stdout").read_bytes())
    program={name:binary(root,name) for name in ("uv","uvx")}
    c.write(evidence/"programs.json",program)
    admitted=c.read(c.RESULTS/"product-admission.json")["ordinary"]
    proof=c.read(c.D/"git-version.json")
    current={k:c.git(c.SOURCE,*proof[k+"_args"]).decode().strip() for k in ("production","default")}
    c.write(evidence/"git.json",current)
    c.need(current==rev["raw_git"]==proof["bank"][c.A] and not any(k.startswith("UV_") for k in env),
           "actual historical checkout or ordinary build environment")
    c.need(detail==admitted["serialized"]=={"package_name":"uv","version":"0.13.1","target_triple":c.HOST,"commit_info":None} and
           raw==admitted["public_strings"]=={s:s+" 0.13.1 ("+c.HOST+")\n" for s in ("uv","uvx")},
           "actual native ordinary development version; see "+str(evidence))
    behavior=oracle.observe(root/"uvx",c.LANE/"qa")
    c.need(behavior["binary_sha256"]==program["uvx"]["sha256"] and behavior["cases"]==c.read(c.OLD/"behavior-control.json")["observed"]["cases"],"published argv/exit oracle")
    with tempfile.TemporaryDirectory(dir=c.LANE/"qa") as tmp:
        q=Path(tmp);front=q/"uvx";shutil.copyfile(root/"uvx",front);front.chmod(0o755)
        companion=q/"uv";companion.write_text('#!/usr/bin/python3 -ISB\nimport sys\nsys.stdout.buffer.write(sys.stdin.buffer.read());sys.exit(37)\n');companion.chmod(0o755)
        res=subprocess.run([front,*oracle.ARGUMENTS],input=STDIN,env=oracle.ENV,capture_output=True,timeout=15)
        c.need((res.returncode,res.stdout,res.stderr)==(37,STDIN,b""),"raw stdin or inherited child exit")
    return {"programs":program,"versions":raw,"detail":detail,"git":current,"argv_and_exit":behavior["cases"],"raw_stdin_hex":STDIN.hex(),"child_exit":37}

def changed(a,b):
    c.need(a["programs"]["uv"]["sha256"]==b["programs"]["uv"]["sha256"] and
           a["programs"]["uvx"]["sha256"]!=b["programs"]["uvx"]["sha256"],"A/B product resolution")
    c.need({k:v for k,v in a.items() if k!="programs"}=={k:v for k,v in b.items() if k!="programs"},"launcher observable changed")
