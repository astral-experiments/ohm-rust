"""Verify the three already enrolled compiler/Cargo runtimes inside the actual namespace."""

import os
from pathlib import Path
import subprocess
import launcher22742_study3_common as c

def selected(name):
    return name.startswith("bin/") or name.startswith("lib/") and (
        name.startswith("lib/rustlib/"+c.HOST+"/bin/") or name.startswith("lib/rustlib/"+c.HOST+"/lib/") or "/" not in name[4:])

def verify_files(sdk,files):
    for rel,r in files.items():
        f=sdk/rel
        c.need(not Path(rel).is_absolute() and ".." not in Path(rel).parts and f.is_file() and not f.is_symlink()
               and f.stat().st_size==r["bytes"] and c.sha(f)==r["sha256"],"different SDK member "+str(f))

def actual(role,arm,env):
    sdk=c.SDK
    c.need(os.statvfs(sdk).f_flag & os.ST_RDONLY and c.sha(sdk/"bin/rustc")==arm["launcher_sha256"] and
           c.sha(sdk/"bin/cargo")==arm["effective_cargo"] and c.sha(sdk/arm["driver_relative"])==arm["driver_sha256"],"wrong worker distribution")
    native=c.LANE/"sdks"/role
    c.need((sdk/"bin/rustc").samefile(native/"bin/rustc") and (sdk/"bin/cargo").samefile(c.LANE/"sdks"/("signed18" if role=="gnu22-cargo18" else role)/"bin/cargo"),"physical Cargo/rustc scope")
    members=arm["files"]
    if role=="signed18":
        observed={str(f.relative_to(native)) for f in native.rglob("*") if f.is_file() and selected(str(f.relative_to(native)))}
    else:
        observed={str(f.relative_to(native)) for f in native.rglob("*") if f.is_file()}
    c.need(observed==set(members),"actual read-only SDK inventory")
    verify_files(native,{n:v for n,v in members.items() if n!="bin/cargo" or role!="gnu22-cargo18"})
    roots=set()
    for bind in ("cargo","rustc"):
        cmd=[sdk/"bin"/bind,"-vV"]; res=subprocess.run(cmd,env=env|{"LD_DEBUG":"libs"},capture_output=True,timeout=25)
        c.need(res.returncode==0 and len(res.stderr)<4*c.M,"version with dynamic loader")
        if bind=="cargo":cargo=res.stdout.decode()
        else:
            rustc=res.stdout.decode()
            for line in res.stderr.splitlines():
                if b"calling init:" in line:
                    image=Path(os.fsdecode(line.split(b"calling init:",1)[1].strip()))
                    if image.name.startswith(("librustc_driver-","libLLVM.so")):roots.add(c.sha(image))
    f=arm["files"];expected_driver=arm["driver_sha256"]
    c.need(roots=={expected_driver,f["lib/libLLVM.so.23.1-rust-1.99.0-beta"]["sha256"]},"actual loader identity")
    rid={"signed18":"a4fa11bcd38280639cb94daacc125472657db6c3","signed21":"c79998a5cd143c445a4b2528f20953b176a65c5d","gnu22-cargo18":"556a8364f1485a03be31b1a50c250d63198a943d"}[role]
    c.need(rid in rustc and ("ohm-1.99.0-21" if role=="signed21" else "ohm-1.99.0-18") in cargo,"release source/version")
    return {"rustc":rustc,"cargo":cargo,"loaded":sorted(roots),"cargo_sha256":arm["effective_cargo"],"driver":expected_driver}
