"""Exclusive, air-gapped physical replay of published uv #22742."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import launcher22742_study3_common as c
import launcher22742_study3_score as score
import launcher22742_study3_sdks as subjects

def guard_source():
    sys.path.insert(0,str(c.GUARD_SCOUT))
    import stage1
    adapter,_=stage1.original.v.local_receipt(stage1.RECEIPT,stage1.OLD)
    legacy=c.WORK/"round18-rustc"
    guard=legacy/"guard-file-free-math-asm"
    original=stage1.original
    owners={
        stage1:c.GUARD_SCOUT/"stage1.py", original:guard/"bootstrap/producer_v2.py",
        original.sub:guard/"bootstrap/subjects.py", original.v:legacy/"branch-session-revisit/pr274-trials/intake.py",
        stage1.u:legacy/"branch-history-implementation/upstream-274/full-sysroot/build.py",
        stage1.u.common:legacy/"branch-history-implementation/build.py",
        adapter:legacy/"branch-history-implementation/physical.py", adapter.native:c.WORK/"round18-lab/native.py",
        sys.modules["common"]:c.WORK/"round18-lab/common.py", stage1.PRE:guard/"package-test-full-stack/tmpfs-price/material.py",
        stage1.PRE.c:guard/"package-test-full-stack/tmpfs-price/codec.py",
        stage1.PRE.i:guard/"package-test-full-stack/tmpfs-price/park_inputs.py",
        c:c.D/"launcher22742_study3_common.py",subjects:c.D/"launcher22742_study3_sdks.py",score:c.D/"launcher22742_study3_score.py",
    }
    sealed=c.read(c.REG)["inputs"]
    for module,path in owners.items():
        c.need(Path(module.__file__).resolve()==path and c.sha(path)==sealed[str(path)],"incorrect module owner for "+str(path))
    c.need(sys.modules["subjects"] is original.sub and original.sub.UP==stage1.UP and
           adapter.build is stage1.u.common and adapter.native.WORK==sys.modules["common"].WORK==c.WORK and
           adapter.native.OLD==sys.modules["common"].OLD and adapter.native.foreign.__globals__ is vars(adapter.native) and
           stage1.PRE.quiet.__globals__ is vars(stage1.PRE) and subjects.c is score.c is c,"historical and study guard bindings")
    return stage1,adapter

def capacity(extra=0):
    mem=Path("/proc/meminfo").read_text().split("MemAvailable:",1)[1].splitlines()[0].split()
    floors={"ram":int(mem[0])*1024,"root":shutil.disk_usage(c.D).free,"scratch":shutil.disk_usage("/recorded/scratch").free}
    c.need(floors["ram"]>=55*c.G and min(floors["root"],floors["scratch"])>=122*c.G+extra,("resource reserve",floors))
    return floors

def command(phase,p,out):
    _,repo,registry,receipt=c.handoff()
    argv=["/usr/bin/bwrap","--die-with-parent","--unshare-net","--unshare-pid","--ro-bind","/","/","--dev","/dev","--proc","/proc",
          "--size",str(20*c.G),"--tmpfs","/tmp","--dir",str(c.LANE),"--dir",str(c.LANE/"sdks"),"--bind",str(out),str(out)]
    for path in (repo,registry,receipt):
        if path.is_relative_to("/dev") or path.is_relative_to("/tmp"):
            argv+=["--ro-bind",str(path),str(path)]
    for role in c.ROLES:
        base=p["arms"][role]["sdk"]; argv+=["--ro-bind",base,str(c.LANE/"sdks"/role)]
    argv+=["--ro-bind",str(Path(p["arms"]["signed18"]["sdk"])/"bin/cargo"),str(c.LANE/"sdks/gnu22-cargo18/bin/cargo")]
    for n in ("cache","index"):argv+=["--ro-bind",str(registry/n),str(c.LANE/"cargo/registry"/n)]
    argv+=["--setenv","OHM_LAUNCHER_22742_OUT",str(out),"--","/usr/bin/taskset","-c","0-15","/usr/bin/python3","-ISB",str(c.D/"run.py"),"_worker",phase]
    return argv

def is_descendant(pid,own):
    while pid>1:
        if pid==own:return True
        try:
            vals=Path("/proc",str(pid),"stat").read_text().rsplit(")",1)[1].strip().split()
        except (FileNotFoundError,ProcessLookupError,PermissionError):return None
        pid=int(vals[1])
    return False

def launch(phase,b,host):
    p=c.enrolled();out=c.RESULTS/phase
    c.need(not out.exists(),"fresh evidence phase only")
    if phase!="discovery":
        c.need(score.discovery()["open_holdouts"],"discovery failed the cutoff")
    if phase=="holdout-2":score.checked("holdout-1")
    with b.PRE.four(host) as locks:
        opening=capacity(32*c.M)
        argv=command(phase,p,out);out.mkdir(mode=0o700)
        c.write(out/"intake.json",{"registration":c.registration(),"phase":phase,"argv":argv,"subjects":c.sha(c.SUBJECT_FILE),
                "opening":opening,"locks":locks,"utc_start_ns":time.time_ns(),"boot":Path("/proc/sys/kernel/random/boot_id").read_text().strip()})
        start=time.monotonic();low=dict(opening);fault=None
        with (out/"worker.log").open("xb") as f:
            proc=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            try:
                while proc.poll() is None:
                    free=capacity();low={k:min(v,free[k]) for k,v in low.items()}
                    foreign=[(pid,name) for pid,name in host.native.foreign() if is_descendant(pid,proc.pid) is False]
                    c.need(not foreign,("foreign compiler during phase",foreign))
                    c.need(time.monotonic()-start<3000,"50-minute phase limit")
                    c.need(sum(x.stat().st_size for x in out.rglob("*") if x.is_file())<32*c.M,"persistent evidence budget")
                    try:proc.wait(timeout=.35)
                    except subprocess.TimeoutExpired:pass
                c.need(proc.returncode==0 and (out/"complete.json").is_file(),"see "+str(out/"worker.log"))
            except BaseException as exc:
                fault=repr(exc);raise
            finally:
                if proc.poll() is None:
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.wait(timeout=4)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                c.write(out/"worker-return.json",{"exit":proc.returncode if fault is None else 1,"worker_exit":proc.returncode,"fault":fault,
                        "minimum":low,"elapsed_s":time.monotonic()-start,"complete":c.sha(out/"complete.json") if (out/"complete.json").is_file() else None})
    score.checked(phase)
    if phase=="discovery":print(json.dumps(score.discovery(),indent=2))
    if phase=="holdout-2":print(json.dumps(score.final(),indent=2))

def main(args):
    reg=c.registration()
    if args==["plan"]:
        print(json.dumps({"registration":reg,"orders":{ph:c.schedule(ph) for ph in c.PHASES},
              "material_ready":c.MATERIAL.is_file(),"version_proof_closed":(c.PROOF/"worker-return.json").is_file(),
              "product_admitted":(c.RESULTS/"product-admission.json").is_file(),"case":"ordinary --bins literal A to first unstaged B"},sort_keys=True));return
    if len(args)==2 and args[0]=="admit":
        import launcher22742_study3_admit as gate
        print(json.dumps(gate.admit(args[1]),sort_keys=True));return
    if args==["score"]:print(json.dumps(score.final(),indent=2));return
    if args==["discovery-result"]:print(json.dumps(score.discovery(),indent=2));return
    if len(args)==2 and args[0]=="_worker":
        import launcher22742_study3_worker as worker;worker.inner(args[1],c.RESULTS/args[1]);return
    c.need(os.geteuid()!=0 and Path("/proc/1/comm").read_text().strip()=="systemd" and os.environ.get("OHM_LAUNCHER_22742")==reg,"physical registration and original host")
    os.sched_setaffinity(0,{29});b,host=guard_source()
    c.need(len(args)==2 and args[0]=="run" and args[1] in c.PHASES,"plan | admit DIAGNOSTIC_RETURN_SHA | run PHASE | discovery-result | score")
    launch(args[1],b,host)

if __name__=="__main__":main(sys.argv[1:])
