"""The original raw-receipt gate with the two-arm cardinality; the primary estimator is unchanged."""
from statistics import median
import launcher22742_pair2_common as c
import launcher22742_pair2_evidence as evidence
from launcher22742_study3_score import estimate, ratio, raw_product

def checked(name):
    d=c.RESULTS/name
    q=c.read(d/"complete.json");ret=c.read(d/"worker-return.json");intake=c.read(d/"intake.json")
    c.need(ret["exit"]==0 and ret["complete"]==c.sha(d/"complete.json") and q["registration"]==c.registration()
           and q["subjects"]==c.sha(c.SUBJECT_FILE)==intake["subjects"] and q["phase"]==name,"open/foreign phase")
    c.need(q["sdks"]==c.sha(d/"actual-sdks.json") and len(q["seed_ids"])==len(c.ROLES),"SDKs and independently built A seeds")
    for arm in c.ROLES:
        cold=c.read(d/("seed-"+arm)/"cold-A-clock.json")
        seed=c.read(d/("seed-"+arm)/"seed.json")
        raw_product(d/("seed-"+arm)/"product-A",seed["A"])
        c.need(q["seed_ids"][arm]==seed["identity"]==[name,arm,cold["pid"],cold["start_ns"],cold["end_ns"]]
               and "uv" in cold["packages"] and q["seeds"][arm]=={k:v for k,v in seed.items() if k!="identity"},
               "fresh per-arm A history and its two public programs")
    rows=c.read(d/"triplets.json");c.need(q["triplets"]==c.sha(d/"triplets.json") and len(rows)==6,"triplet aggregate")
    for i,row in enumerate(rows):
        c.need(row["order"]==c.schedule(name)[i] and set(row["arms"])==set(c.ROLES),"balanced role order")
        for arm,obs in row["arms"].items():
            path=d/f"r{i+1}-{arm}.json"
            c.need(obs["receipt"]==c.sha(path) and obs["sha_seed"]==q["seeds"][arm]["archive"],"different restored history")
            x=c.read(path); clocks=x["clocks"];a,b=x["A"],x["B"]
            for side,value in (("A",a),("B",b)):raw_product(d/f"r{i+1}-{arm}"/("product-"+side),value)
            c.need(x["phase"]==name and x["role"]==arm and a==q["seeds"][arm]["A"] and a["programs"]["uv"]==b["programs"]["uv"] and
                   a["programs"]["uvx"]["sha256"]!=b["programs"]["uvx"]["sha256"] and b==q["B"][arm],"complete ELF and process evidence")
            c.need(obs["edit_ns"]==clocks["edit"]["wall_ns"] and obs["noop_ns"]==clocks["noop"]["wall_ns"] and
                   obs["sham_ns"]==clocks["sham"]["wall_ns"] and not clocks["sham"]["packages"] and not clocks["noop"]["packages"] and
                   "uv" in clocks["edit"]["packages"],"first edit versus native hot controls")
            c.need(clocks["noop"]["start_ns"]>=clocks["edit"]["end_ns"] and clocks["edit"]["write_closed_ns"] is not None
                   and clocks["edit"]["write_closed_ns"]<=clocks["edit"]["start_ns"],"first unseen edit then immediate no-op")
            evidence.row(d/f"r{i+1}-{arm}",clocks,a,b,x["head"],x["postimage"])
            evidence.stamps(x["stamps"],a,b)
            for label,clock in clocks.items():
                logs=d/f"r{i+1}-{arm}"
                c.need(clock==c.read(logs/(label+"-clock.json")) and clock["stdout"]==c.sha(logs/(label+".stdout"))
                       and clock["stderr"]==c.sha(logs/(label+".stderr")),"raw output or clock changed")
                c.need(clock["argv"]==[str(c.SDK/"bin/cargo"),*c.COMMAND] and clock["exit"]==0 and
                       clock["end_ns"]-clock["start_ns"]==clock["wall_ns"],"ordinary wall clock")
    return rows,q

def clock_report(rows):
    by_arm={}
    for arm in c.ROLES:
        obs=[r["arms"][arm] for r in rows]
        by_arm[arm]={"n":len(obs), "noop_exceeds_B":sum(o["noop_ns"]>o["edit_ns"] for o in obs),
                     "noop_equals_B":sum(o["noop_ns"]==o["edit_ns"] for o in obs),
                     "in_execution_pair_order_ns":{field:[o[field] for o in obs] for field in ("edit_ns","sham_ns","noop_ns")}}
    return by_arm

def discovery():
    rows,_=checked("discovery");values=ratio(rows,"signed18")
    return {"excluded":True,"paired_ratio":values,"median":median(values),"threshold":1.8,"open_holdouts":median(values)>=1.8,"all_clocks":clock_report(rows)}

def final():
    c.need(discovery()["open_holdouts"],"discovery did not reach 1.8")
    first,x=checked("holdout-1");second,y=checked("holdout-2");rows=first+second
    c.need(len(rows)==12 and x["B"]==y["B"] and all(x["seed_ids"][arm]!=y["seed_ids"][arm] for arm in c.ROLES),"fresh independent histories and identical complete B products")
    values=ratio(rows,"signed18");est=estimate(values)
    orders={",".join(k):median(r for r,row in zip(values,rows) if tuple(row["order"])==k) for k in (c.ROLES,c.ROLES[::-1])}
    # Preserve V3's additional six subgroups, even though only two physical orders remain.
    labels=c.original.schedule("holdout-1")+c.original.schedule("holdout-2")
    inherited={",".join(k):median(r for r,label in zip(values,labels) if label==list(k)) for k in sorted({tuple(v) for v in labels})}
    seeds=[median(values[:6]),median(values[6:])]
    ok=est["interval"][0]>2 and est["sign_p"]<=.05 and min([*seeds,*orders.values(),*inherited.values()])>2
    return {"primary":"signed18/gnu22-cargo18","first_B_statistic":est,"ratios":values,"two_execution_orders":orders,"six_preregistered_block_labels":inherited,
            "fresh_phase_medians":seeds,"qualifies_over_2x":ok,"native_median_s":{arm:{field:median(row["arms"][arm][field] for row in rows)/1e9 for field in ("edit_ns","sham_ns","noop_ns")} for arm in c.ROLES},
            "all_clocks":clock_report(rows),"holdout_clocks_by_phase":{p:clock_report(rs) for p,rs in (("holdout-1",first),("holdout-2",second))},
            "scope":"same signed -18 Cargo; packaged rustc, std and compiler-side toolchain; native-input classification is disabled"}
