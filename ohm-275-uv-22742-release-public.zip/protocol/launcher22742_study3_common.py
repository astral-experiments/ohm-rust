"""Shared public source and prospective experimental identities for the launcher edit."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import subprocess
import sys

D=Path(__file__).resolve().parent
WORK=D.parents[4]
FIX=D.parents[1]/"corpus/launcher-22742"
MATERIAL=FIX/"input/material.json"
OLD=WORK/"round18-rustc/uvx-binary-edit"
DIST=D.parent/"literal-21076-dist22"
SUBJECT=DIST/"discovery-job22-literal-cli-001/subject-intake.json"
REG=D/"registration.json"
RESULTS=D/"records"
V2=D.parent/"literal-22742-bins-v2"
SUBJECT_FILE=V2/"records/subjects.json"
DIAG=D.parent/"literal-22742-version-proof"
PROOF=DIAG/"signed21-A-001"
LANE=Path("/tmp/ohm-literal-launcher-22742")
SDK=LANE/"sdk"
SOURCE=LANE/"source"
TARGET=LANE/"target"
PATH="crates/uv/src/bin/uvx.rs"
A="deba0cbdc329d0a6cd118d5e1d58a203df08c0d3"
B="801cb8566547b0d74690a0daf9c795502a5ddafb"
LOCK="587877fa59ff962b6f636fde2cd3c3926ef12ad3"
HOST="x86_64-unknown-linux-gnu"
ROLES=("signed18","signed21","gnu22-cargo18")
PHASES=("discovery","holdout-1","holdout-2")
COMMAND=["build","--locked","--offline","-j8","-p","uv","--bins"]
G=1<<30; M=1<<20
S18="02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
S21="4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e"
ARCH18=WORK/"upstream-monitor/download18/ohm-1.99.0-18-x86_64-unknown-linux-gnu.tar.gz"
ARCH18_SHA="629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8"
GUARD_SCOUT=WORK/"round18-rustc/over18-2x/release-scout"
ENV={"PATH":"/usr/bin:/bin","HOME":str(LANE/"home"),"LC_ALL":"C.UTF-8","TZ":"UTC","GIT_CONFIG_GLOBAL":"/dev/null",
     "GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_COUNT":"1","GIT_CONFIG_KEY_0":"safe.directory","GIT_CONFIG_VALUE_0":"*",
     "GIT_NO_LAZY_FETCH":"1","GIT_ALLOW_PROTOCOL":"file","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}

def need(ok,msg):
    if not ok:raise ValueError(msg)

def read(path):
    return json.loads(Path(path).read_bytes())

def write(path,obj):
    with Path(path).open("x") as f:
        json.dump(obj,f,indent=2,sort_keys=True);f.write("\n")

def sha(path):
    with Path(path).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()

def git(repo,*args,bare=False,stdin=None):
    cmd=["/usr/bin/git",("--git-dir" if bare else "-C"),str(repo),*args]
    p=subprocess.run(cmd,input=stdin,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
    need(p.returncode==0,(args,p.stderr[-800:]))
    return p.stdout

def gitblob(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()

def schedule(phase):
    plan=list(itertools.permutations(ROLES))
    random.Random(2274220261031+PHASES.index(phase)).shuffle(plan)
    return [list(row) for row in plan]

def registration():
    r=read(REG)
    need(__debug__ and all(sha(k)==v for k,v in r["inputs"].items()),"registered source changed")
    need(r["orders"]=={ph:schedule(ph) for ph in PHASES},"triplet schedule changed")
    for role in "AB":
        raw=(FIX/(role+"-uvx.rs")).read_bytes()
        need(gitblob(raw)==r["source_blobs"][role],"public source differs")
    need(gitblob((FIX/"Cargo.lock").read_bytes())==LOCK,"historical Cargo.lock")
    return sha(REG)

def handoff():
    x=read(MATERIAL)
    repo=Path(x["repo"]); registry=Path(x["registry"]); receipt=Path(x["registry_receipt"])
    need(all(p.is_absolute() and p.resolve()==p for p in (repo,registry,receipt)),"input custody paths must be canonical")
    need(repo.is_dir() and registry.is_dir() and receipt.is_file(),"incomplete historical material")
    for name in ["cache","index"]:need((registry/name).is_dir(),"missing registry "+name)
    need(x["locked_packages"]==654 and x["compiled_commands"]==x["timing_rows"]==0
         and x["registry_receipt_sha256"]==sha(receipt) and x["source_receipt_sha256"]==sha(x["source_receipt"]),
         "unclosed historical registry or source input custody")
    return x,repo,registry,receipt

def verify_git(repo):
    def out(*args):return git(repo,*args,bare=True).decode().strip()
    for side,rev in (("A",A),("B",B)):
        c=read(FIX/(side+"-commit.json"))
        need(c["sha"]==rev and out("rev-parse",rev+"^{tree}")==c["tree"] and out("cat-file","-p",rev).splitlines()[1]=="parent "+c["parents"][0],"original commit, parent, tree")
        need(out("rev-parse",rev+":Cargo.lock")==LOCK and git(repo,"show",rev+":"+PATH,bare=True)==(FIX/(side+"-uvx.rs")).read_bytes(),"locked release source")
    need(out("diff","--name-status",A,B)=="M\t"+PATH,"literal one-file workload")
    v=read(D/"git-version.json")
    for rev in (A,B):
        for path in ("build","formatter"):
            name=v["build_script" if path=="build" else path]
            need(out("rev-parse",rev+":"+name)==v[path+"_blob"],"wrong uv version source")
        for kind in ("production","default"):
            need(out(*v[kind+"_args"],rev)==v["bank"][rev][kind],"wrong historical Git "+kind+" abbreviation")
    fields=v["bank"][A]["production"].split()
    return {"revision":A,"short":fields[1],"date":fields[2],"describe":fields[3],"tag":"0.13.1","distance":137,
            "build_script_blob":v["build_blob"],"formatter_blob":v["formatter_blob"],"raw_git":v["bank"][A],
            "tree_A":read(FIX/"A-commit.json")["tree"],"tree_B":read(FIX/"B-commit.json")["tree"],"lock_blob":LOCK}

def enrolled():
    admission=read(RESULTS/"product-admission.json")
    need(admission["registration"]==registration() and admission["diagnostic_return"]==sha(PROOF/"worker-return.json") and
         admission["verification"]==sha(PROOF/"verified.json") and read(PROOF/"worker-return.json")["verified"]==admission["verification"],
         "the real signed product proof must be closed")
    p=read(SUBJECT_FILE); _,repo,registry,receipt=handoff()
    need(sha(SUBJECT_FILE)=="cd16bfc81a0018cab5719a2d6a20548fe3ddde4c6cfee7d1ef38dbab2b1a0ce4" and
         p["registration"]==sha(V2/"registration.json") and p["material_sha256"]==sha(MATERIAL) and
         p["registry_receipt_sha256"]==sha(receipt) and p["git"]==verify_git(repo),"source or v2 physical enrollment drift")
    return p
