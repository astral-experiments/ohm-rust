"""Private phase worker. Target archives contain A only and are never shared between SDKs or phases."""
import hashlib
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import launcher22742_study3_common as c
import launcher22742_study3_products as products
import launcher22742_study3_sdks as subjects

def checkout(repo):
    src=c.SOURCE
    c.need(not src.exists() and os.statvfs(repo).f_flag&os.ST_RDONLY,"source custody")
    subprocess.run(["git","init","-q",src],env=c.ENV,check=True)
    (src/".git/objects/info/alternates").write_text(str(repo/"objects")+"\n")
    if (repo/"shallow").is_file():shutil.copyfile(repo/"shallow",src/".git/shallow")
    tags=c.git(repo,"for-each-ref","--format=%(objectname) %(refname)","refs/tags",bare=True).splitlines()
    stdin=b"".join(b"create "+line.split(b" ",1)[1]+b" "+line.split(b" ",1)[0]+b"\n" for line in tags)
    c.need(0<len(stdin)<2*c.M,"missing or unbounded tag refs");c.git(src,"update-ref","--stdin",stdin=stdin)
    c.git(src,"-c","core.autocrlf=false","checkout","-q","--detach",c.A)
    version=c.read(c.D/"git-version.json")
    c.need(not c.git(src,"status","--porcelain=v1") and c.git(src,"rev-parse","HEAD").strip().decode()==c.A
           and all(c.git(src,*version[x+"_args"]).decode().strip()==version["bank"][c.A][x] for x in ("production","default"))
           and c.gitblob((src/version["build_script"]).read_bytes())==version["build_blob"]
           and c.gitblob((src/version["formatter"]).read_bytes())==version["formatter_blob"],"actual checkout or version program identity")
    c.need(c.git(src,"diff","--name-only",c.A,c.B).decode().strip()==c.PATH and c.gitblob((src/"Cargo.lock").read_bytes())==c.LOCK,"historical lock and tree")
    return (src/c.PATH).stat().st_mtime_ns

def state(mode, stamp=None):
    source=c.SOURCE/c.PATH
    if mode=="A":
        source.write_bytes((c.FIX/"A-uvx.rs").read_bytes());os.utime(source,ns=(stamp,stamp))
    wanted=(c.FIX/(mode+"-uvx.rs")).read_bytes()
    old=c.git(c.SOURCE,"diff","--name-only").decode().strip()
    c.need(c.git(c.SOURCE,"rev-parse","HEAD").strip().decode()==c.A and not c.git(c.SOURCE,"diff","--cached","--name-only")
           and old==("" if mode=="A" else c.PATH) and source.read_bytes()==wanted and
           c.gitblob((c.SOURCE/"Cargo.lock").read_bytes())==c.LOCK,"wrong literal edit")
    return c.gitblob(wanted)

def clock(folder,label,env,edit=None):
    work=c.SOURCE/c.PATH;argv=[str(c.SDK/"bin/cargo"),*c.COMMAND]
    pstdout=folder/(label+".stdout");pstderr=folder/(label+".stderr")
    with pstdout.open("xb") as stdout,pstderr.open("xb") as stderr:
        if edit is not None:
            before=work.stat().st_mtime_ns;work.write_bytes(edit)
            c.need(work.stat().st_mtime_ns>before,"first-B edit has no fresh mtime")
        applied=time.monotonic_ns() if edit is not None else None
        start=time.monotonic_ns()
        p=subprocess.Popen(argv,cwd=c.SOURCE,env=env,stdout=stdout,stderr=stderr)
        try:rc=p.wait(timeout=1200 if label.startswith("cold-") else 180)
        except subprocess.TimeoutExpired:
            p.kill();p.wait();raise
        end=time.monotonic_ns()
    c.need(pstderr.stat().st_size<6*c.M and pstdout.stat().st_size<2*c.M,"bounded Cargo diagnostics")
    log=pstderr.read_text(errors="replace")
    packages=re.findall(r"^\s*(?:Compiling|Checking)\s+(\S+)",log,re.M)
    row={"argv":argv,"pid":p.pid,"exit":rc,"write_closed_ns":applied,"start_ns":start,"end_ns":end,"wall_ns":end-start,"packages":packages,
         "stdout":c.sha(pstdout),"stderr":c.sha(pstderr)}
    c.write(folder/(label+"-clock.json"),row)
    c.need(rc==0 and pstdout.stat().st_size==0 and "Finished" in log,(label,rc,log[-1000:]))
    if label in ("sham","noop","settled"):c.need(not packages,"unexpected compilation in "+label)
    else:c.need("uv" in packages,"missing package compilation "+label)
    return row

def output_stamps():
    result={}
    for name in ("uv","uvx"):
        f=c.TARGET/"debug"/name;s=f.stat()
        result[name]=[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]
    return result

def setup(role):
    if c.SDK.is_symlink():c.SDK.unlink()
    c.SDK.symlink_to(c.LANE/"sdks"/role,target_is_directory=True)
    env=c.ENV|{"PATH":str(c.SDK/"bin")+":/usr/bin:/bin","RUSTC":str(c.SDK/"bin/rustc"),"RUSTDOC":str(c.SDK/"bin/rustdoc"),
        "CARGO_HOME":str(c.LANE/"cargo"),"CARGO_NET_OFFLINE":"true","CARGO_TARGET_DIR":str(c.TARGET),"TMPDIR":str(c.LANE/"tmp"),
        "CARGO_TERM_COLOR":"never"}
    return env

def fresh_target():
    c.need(c.TARGET.parent==c.LANE and not c.TARGET.is_symlink(),"private target only")
    if c.TARGET.exists():shutil.rmtree(c.TARGET)

def archive(file,restore=False):
    if restore:
        c.need(not c.TARGET.exists() and file.is_file(),"dirty restore")
        argv=["tar","-I","zstd -T2","-xf",file,"-C",c.LANE]
    else:
        c.need(not file.exists(),"exclusive seed archive")
        argv=["tar","--format=posix","--pax-option=delete=atime,delete=ctime","-I","zstd -1 -T2","-cf",file,"-C",c.LANE,"target"]
    subprocess.run(argv,env=c.ENV,cwd=c.LANE,check=True,timeout=280)

def inner(phase,out):
    c.need(phase in c.PHASES and out==c.RESULTS/phase and os.environ["OHM_LAUNCHER_22742_OUT"]==str(out) and
           os.sched_getaffinity(0)==set(range(16)) and os.statvfs(c.D).f_flag&os.ST_RDONLY and
           not os.statvfs(out).f_flag&os.ST_RDONLY and os.stat(c.LANE).st_dev==os.stat("/tmp").st_dev!=os.stat(c.D).st_dev,"unregistered phase namespace")
    p=c.enrolled();_,repo,_,_=c.handoff()
    for sub in ("home","tmp","qa","seeds"):(c.LANE/sub).mkdir()
    stamp=checkout(repo);reg=c.registration(); seeds={};seedids={};versions={};gold={};triplets=[]
    seed_order=c.schedule(phase)[0]
    for role in seed_order:
        env=setup(role);versions[role]=subjects.actual(role,p["arms"][role],env);fresh_target()
        state("A",stamp);folder=out/("seed-"+role);folder.mkdir()
        cold=clock(folder,"cold-A",env);original=products.check(c.TARGET/"debug",env,p["git"],folder/"product-A")
        prev=output_stamps();clock(folder,"settled",env);c.need(output_stamps()==prev,"changed seed ELF on hot A")
        arc=c.LANE/"seeds"/(role+".tar.zst");archive(arc);arc.chmod(0o400)
        c.need(0<arc.stat().st_size<3*c.G,"A archive exceeds prior --bins allowance")
        seeds[role]={"archive":c.sha(arc),"bytes":arc.stat().st_size,"A":original}
        seedids[role]=[phase,role,cold["pid"],cold["start_ns"],cold["end_ns"]]
        c.write(folder/"seed.json",seeds[role]|{"identity":seedids[role]})
    c.write(out/"actual-sdks.json",versions)
    fresh_target()
    edit=(c.FIX/"B-uvx.rs").read_bytes()
    for ix,order in enumerate(c.schedule(phase),1):
        trip={"order":order,"arms":{}}
        for role in order:
            env=setup(role);state("A",stamp);arc=c.LANE/"seeds"/(role+".tar.zst")
            c.need(arc.stat().st_mode&0o777==0o400 and arc.stat().st_size==seeds[role]["bytes"],"protected same-arm A seed")
            fresh_target();archive(arc,True)
            folder=out/f"r{ix}-{role}";folder.mkdir()
            a=products.check(c.TARGET/"debug",env,p["git"],folder/"product-A")
            c.need(a==seeds[role]["A"],"restored A differs");prev=output_stamps()
            sham=clock(folder,"sham",env);c.need(output_stamps()==prev,"restored A no-op touched a binary")
            raw=clock(folder,"edit",env,edit)
            before=output_stamps();again=clock(folder,"noop",env)
            c.need(before==output_stamps(),"immediate hot B command touched a public ELF")
            state("B");b=products.check(c.TARGET/"debug",env,p["git"],folder/"product-B");products.changed(a,b)
            if role in gold:c.need(b==gold[role],"different complete B binaries across restores")
            else:gold[role]=b
            c.need(raw["wall_ns"]>again["wall_ns"],"first compilation indistinguishable from hot no-op")
            receipt=out/(folder.name+".json")
            c.write(receipt,{"phase":phase,"role":role,"order":order,"A":a,"B":b,"clocks":{"sham":sham,"edit":raw,"noop":again},
                "seed":seeds[role]["archive"],"postimage":c.gitblob(edit),"head":c.A})
            trip["arms"][role]={"receipt":c.sha(receipt),"edit_ns":raw["wall_ns"],"noop_ns":again["wall_ns"],"sham_ns":sham["wall_ns"],"sha_seed":seeds[role]["archive"]}
            print(phase,ix,role,"first",round(raw["wall_ns"]/1e9,4),"noop",round(again["wall_ns"]/1e9,4),flush=True)
        triplets.append(trip)
    fresh_target()
    c.need(all(c.sha(c.LANE/"seeds"/(r+".tar.zst"))==seeds[r]["archive"] for r in c.ROLES),"frozen A archive changed")
    c.write(out/"triplets.json",triplets)
    c.write(out/"complete.json",{"phase":phase,"registration":reg,"subjects":c.sha(c.SUBJECT_FILE),"seeds":seeds,
                                "seed_ids":seedids,"B":gold,"triplets":c.sha(out/"triplets.json"),"sdks":c.sha(out/"actual-sdks.json")})
