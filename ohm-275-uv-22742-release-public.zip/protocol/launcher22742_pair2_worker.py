"""Fresh paired worker, reusing the authentic V3 commands, product checks and host namespace."""
import os
import launcher22742_pair2_common as c
import launcher22742_pair2_evidence as evidence
from launcher22742_study3_worker import archive, checkout, clock, fresh_target, output_stamps, products, setup, state, subjects

def inner(phase,out):
    c.need(phase in c.PHASES and out==c.RESULTS/phase and os.environ["OHM_LAUNCHER_22742_OUT"]==str(out) and
           os.sched_getaffinity(0)==set(range(16)) and os.statvfs(c.D).f_flag&os.ST_RDONLY and
           not os.statvfs(out).f_flag&os.ST_RDONLY and os.stat(c.LANE).st_dev==os.stat("/tmp").st_dev!=os.stat(c.D).st_dev,"unregistered phase namespace")
    p=c.enrolled();_,repo,_,_=c.handoff()
    for sub in ("home","tmp","qa","seeds"):(c.LANE/sub).mkdir()
    stamp=checkout(repo);reg=c.registration(); seeds={};seedids={};versions={};gold={};triplets=[]
    seed_order=c.schedule(phase)[0]
    for role in seed_order:
        env=setup(role);versions[role]=subjects.actual(role,p["arms"][role],env);fresh_target()
        state("A",stamp);folder=out/("seed-"+role);folder.mkdir()
        cold=clock(folder,"cold-A",env);original=products.check(c.TARGET/"debug",env,p["git"],folder/"product-A")
        prev=output_stamps();clock(folder,"settled",env);c.need(output_stamps()==prev,"changed seed ELF on hot A")
        arc=c.LANE/"seeds"/(role+".tar.zst");archive(arc);arc.chmod(0o400)
        c.need(0<arc.stat().st_size<3*c.G,"A archive exceeds prior --bins allowance")
        seeds[role]={"archive":c.sha(arc),"bytes":arc.stat().st_size,"A":original}
        seedids[role]=[phase,role,cold["pid"],cold["start_ns"],cold["end_ns"]]
        c.write(folder/"seed.json",seeds[role]|{"identity":seedids[role]})
    c.write(out/"actual-sdks.json",versions)
    fresh_target()
    edit=(c.FIX/"B-uvx.rs").read_bytes()
    for ix,order in enumerate(c.schedule(phase),1):
        trip={"order":order,"arms":{}}
        for role in order:
            env=setup(role);state("A",stamp);arc=c.LANE/"seeds"/(role+".tar.zst")
            c.need(arc.stat().st_mode&0o777==0o400 and arc.stat().st_size==seeds[role]["bytes"],"protected same-arm A seed")
            fresh_target();archive(arc,True)
            folder=out/f"r{ix}-{role}";folder.mkdir()
            a=products.check(c.TARGET/"debug",env,p["git"],folder/"product-A")
            c.need(a==seeds[role]["A"],"restored A differs");prev=output_stamps()
            sham=clock(folder,"sham",env);after_sham=output_stamps();c.need(after_sham==prev,"restored A no-op touched a binary")
            raw=clock(folder,"edit",env,edit)
            before=output_stamps();again=clock(folder,"noop",env)
            after_noop=output_stamps();c.need(before==after_noop,"immediate hot B command touched a public ELF")
            state("B");b=products.check(c.TARGET/"debug",env,p["git"],folder/"product-B");products.changed(a,b)
            if role in gold:c.need(b==gold[role],"different complete B binaries across restores")
            else:gold[role]=b
            stamps={"before_sham":prev,"after_sham":after_sham,"before_noop":before,"after_noop":after_noop}
            clocks={"sham":sham,"edit":raw,"noop":again}
            evidence.row(folder,clocks,a,b,c.A,c.gitblob(edit))
            evidence.stamps(stamps,a,b)
            receipt=out/(folder.name+".json")
            c.write(receipt,{"phase":phase,"role":role,"order":order,"A":a,"B":b,"clocks":clocks,"stamps":stamps,
                "seed":seeds[role]["archive"],"postimage":c.gitblob(edit),"head":c.A})
            trip["arms"][role]={"receipt":c.sha(receipt),"edit_ns":raw["wall_ns"],"noop_ns":again["wall_ns"],"sham_ns":sham["wall_ns"],"sha_seed":seeds[role]["archive"]}
            print(phase,ix,role,"first",round(raw["wall_ns"]/1e9,4),"noop",round(again["wall_ns"]/1e9,4),flush=True)
        triplets.append(trip)
    fresh_target()
    c.need(all(c.sha(c.LANE/"seeds"/(r+".tar.zst"))==seeds[r]["archive"] for r in c.ROLES),"frozen A archive changed")
    c.write(out/"triplets.json",triplets)
    c.write(out/"complete.json",{"phase":phase,"registration":reg,"subjects":c.sha(c.SUBJECT_FILE),"seeds":seeds,
                                "seed_ids":seedids,"B":gold,"triplets":c.sha(out/"triplets.json"),"sdks":c.sha(out/"actual-sdks.json")})
