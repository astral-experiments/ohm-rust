"""Decide whether the real source edit compiled from its source, products and Cargo records."""
import re
import launcher22742_pair2_common as c
from launcher22742_study3_products import STDIN, changed
from launcher22742_study3_score import raw_product

def row(folder, clocks, a, b, head, postimage):
    c.need(head==c.A and postimage==c.gitblob((c.FIX/"B-uvx.rs").read_bytes()) and
           postimage!=c.gitblob((c.FIX/"A-uvx.rs").read_bytes()),"wrong source edit or checkout")
    changed(a,b)
    c.need(a["programs"]["uv"]==b["programs"]["uv"],"unrelated uv ELF or owner changed")
    admitted=c.read(c.original.RESULTS/"product-admission.json")["ordinary"]
    expected_git=c.read(c.original.D/"git-version.json")["bank"][c.A]
    expected_cases=c.read(c.OLD/"behavior-control.json")["observed"]["cases"]
    for side,product in (("A",a),("B",b)):
        raw_product(folder/("product-"+side),product)
        c.need(product["versions"]==admitted["public_strings"] and product["detail"]==admitted["serialized"] and
               product["git"]==expected_git and product["argv_and_exit"]==expected_cases and
               product["raw_stdin_hex"]==STDIN.hex() and product["child_exit"]==37,"native version, Git or forwarding evidence")
    c.need(set(clocks)=={"sham","edit","noop"},"missing physical clock")
    for name,clock in clocks.items():
        out,err=folder/(name+".stdout"),folder/(name+".stderr")
        log=err.read_text(errors="replace")
        packages=re.findall(r"^\s*(?:Compiling|Checking)\s+(\S+)",log,re.M)
        compile_uv=bool(re.search(r"^\s*Compiling\s+uv(?:\s|$)",log,re.M))
        c.need(clock==c.read(folder/(name+"-clock.json")) and clock["argv"]==[str(c.SDK/"bin/cargo"),*c.COMMAND] and
               clock["exit"]==0 and clock["pid"]>0 and 0<clock["start_ns"]<clock["end_ns"] and
               clock["wall_ns"]==clock["end_ns"]-clock["start_ns"] and clock["stderr"]==c.sha(err) and
               clock["stdout"]==c.sha(out) and out.stat().st_size==0 and "Finished" in log,"inconsistent physical Cargo clock or raw output")
        c.need(clock["packages"]==packages and (compile_uv if name=="edit" else not packages),"incorrect raw build roster on "+name)
    aclock,first,again=(clocks[k] for k in ("sham","edit","noop"))
    c.need(aclock["write_closed_ns"] is None and again["write_closed_ns"] is None and first["write_closed_ns"] is not None and
           aclock["end_ns"]<=first["write_closed_ns"]<=first["start_ns"] and first["end_ns"]<=again["start_ns"],
           "write, sham, first-B or immediate no-op out of sequence")

def stamps(values,a,b):
    for left,right,product in (("before_sham","after_sham",a),("before_noop","after_noop",b)):
        c.need(values[left]==values[right] and set(values[left])=={"uv","uvx"} and all(
            len(v)==4 and v[2]==product["programs"][name]["bytes"] for name,v in values[left].items()),
            "A sham or immediate B no-op touched a native product")
