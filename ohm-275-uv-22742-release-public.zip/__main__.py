"""Verify normalized receipts and retain the recorded raw hashes when following original seals."""
import ast
import gzip
import re
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import recorded_verifier as recorded
from public_projection import ORIGINAL, NAMES, SOURCE_FIELDS, TARGETS, need, project, sha, spec, timing

ORIGINAL_MANIFEST="0376f625ef2f8d802a38d969492b5e69957fcfbc9f1742dcf53026e0053ec5cb"
OBS_VERIFIER="e02950926fcd64fb4a5cbd3e7dcb6c9601eab334dff9d7af3f0ff6e99ba1c618"
class PublishedFiles(recorded.Files):
    def hash(self,name):
        b=self.raw(name);d=sha(b)
        if not hasattr(self,"projection"):self.projection=self.j("NORMALIZATION.json")["members"]
        if name not in self.projection:return d
        row=self.projection[name]
        need(row["published_sha256"]==d,"projected member mismatch: "+name)
        return row["original_sha256"]
    def check_manifest(self):
        entries=self.z.infolist();names=[x.filename for x in entries]
        need(len(names)==len(set(names))<750 and sum(x.file_size for x in entries)<8_000_000,"excessive/duplicate publication records")
        public=self.j("SHA256.json");src=self.j("SOURCE-SHA256.json");raw=self.j("NORMALIZATION.json")
        need(set(public)==set(names)-{"SHA256.json"} and all(sha(self.raw(n))==h for n,h in public.items()),"published member hashes")
        need(sha(self.raw("SOURCE-SHA256.json"))==ORIGINAL_MANIFEST and sha(self.raw("recorded_verifier.py"))==src["__main__.py"]==OBS_VERIFIER and
             raw["original_archive_sha256"]==ORIGINAL,"private source or original verifier digest")
        need(len(raw["rules"])==len(NAMES) and all(r["id"]==label and r["published_token"]==t.decode() and
             r["original_receipt_field"]==field and len(r["original_token_sha256"])==64 and r["original_token_bytes"]>8
             for r,label,t,field in zip(raw["rules"],NAMES,TARGETS,SOURCE_FIELDS)),"fixed normalization contract")
        meant=set(src)-{"__main__.py","README.md"}
        need(set(raw["members"])<=meant and meant<=set(names) and not any(timing(n) for n in raw["members"]),"timing bytes changed")
        need(sum(1 for n in meant if timing(n))==raw["untouched_timing_members"],"time-gate membership")
        self.projection=raw["members"]
        for n in meant:
            b=self.raw(n);x=raw["members"].get(n)
            if x:
                content=gzip.decompress(b) if x["gzip"] else b
                need(x["gzip"]==n.endswith(".gz") and x["original_sha256"]==src[n] and x["published_sha256"]==public[n] and
                     x["published_bytes"]==len(b) and x["published_content_sha256"]==sha(content) and bool(x["counts"]) and
                     set(x["counts"])<=set(NAMES) and all(isinstance(v,int) and v>0 for v in x["counts"].values()),"normalized origin "+n)
            else:need(src[n]==public[n],"untouched original member "+n)
        need({n for n in self.projection if n.startswith(("direct/","previous/"))}=={
                 "direct/intake.json","previous/intake.json","previous/worker-return.json","previous/worker.log"} and
             sum(n.startswith(("direct/","previous/")) and ("/product-A/" in n or "/product-B/" in n) for n in meant)==270,
             "protected original native witness files")
        need(len(self.z.read("README.md"))>400 and src["README.md"]==raw["original_readme_sha256"],"report provenance")

def verify_original(path):
    with path.open("rb") as h:need(hashlib.file_digest(h,"sha256").hexdigest()==ORIGINAL,"wrong local private original")
    with zipfile.ZipFile(sys.argv[0]) as public,zipfile.ZipFile(path) as old:
        f=PublishedFiles(public);f.check_manifest()
        refs=f.j("NORMALIZATION.json");rules=spec(old)
        need([r[2] for r in rules]==refs["rules"] and old.read("SHA256.json")==f.raw("SOURCE-SHA256.json"),"fixed mapping or source inventory differs")
        raw_manifest=f.j("SOURCE-SHA256.json");changed=set();unchanged=0;checked_argv=0;checked_args=0
        for n,expected in raw_manifest.items():
            original=old.read(n);need(sha(original)==expected,"original member "+n)
            if n in ("__main__.py","README.md"):continue
            out,proof=project(n,original,rules)
            if proof:
                changed.add(n)
                # Gzip block layout may differ between zlib versions. The exact
                # decompressed public bytes and the published member digest are both checked.
                published=f.raw(n)
                want=gzip.decompress(out) if proof["gzip"] else out;got=gzip.decompress(published) if proof["gzip"] else published
                need(want==got,"independent projection mismatch: "+n)
                if n.endswith("/execve.trace.gz"):
                    from trace_parser import record_exec
                    old_exec=record_exec(gzip.decompress(original).decode().splitlines())["processes"]
                    new_exec=record_exec(got.decode().splitlines())["processes"]
                    need(len(old_exec)==len(new_exec),"kernel process loss")
                    for e,ne in zip(old_exec,new_exec):
                        need({k:v for k,v in e.items() if k!="root_argv_line"}=={k:v for k,v in ne.items() if k!="root_argv_line"},"kernel identity or time changed")
                        if e["root_argv_line"] is None:continue
                        tokens=lambda line:[ast.literal_eval(m) for m in re.findall(r'"(?:\\.|[^"\\])*"',line)]
                        before=tokens(e["root_argv_line"]);after=tokens(ne["root_argv_line"])
                        need(len(before)==len(after),"kernel argv lost")
                        for a,b in zip(before,after):
                            text=a.encode()
                            for raw_token,target,_ in sorted(rules,key=lambda r:-len(r[0])):text=text.replace(raw_token,target)
                            need(text.decode()==b,"kernel argv semantics changed")
                        checked_argv+=1;checked_args+=len(before)-1
                for k in ("counts","original_sha256","original_bytes","original_content_sha256","published_content_sha256","gzip"):
                    need(proof[k]==refs["members"][n][k],"independent normalization "+n+" "+k)
            else:
                need(f.raw(n)==original,"unexpected original byte change: "+n);unchanged+=1
        need(changed==set(refs["members"]) and checked_argv==12,"projection membership or kernel argv")
        print(json.dumps({"original_verified":ORIGINAL,"published_changed_records":len(changed),"original_data_members_byte_identical":unchanged,
              "sham_edit_noop_and_seed_members_byte_identical":refs["untouched_timing_members"],"kernel_rustc_argv_records":checked_argv,"kernel_rustc_visible_argv_values":checked_args,"original_native_product_receipt_files":270},sort_keys=True))

if __name__=="__main__":
    if len(sys.argv)==3 and sys.argv[1]=="--verify-original":
        verify_original(Path(sys.argv[2]))
    else:
        recorded.Files=PublishedFiles
        recorded.main()
