probe.d: /recorded/workspace/work/uv-workflow-search/phase-costs/trait-rosters/paired/literal-22742-dirty-root/probe.rs

libohm_probe.rlib: /recorded/workspace/work/uv-workflow-search/phase-costs/trait-rosters/paired/literal-22742-dirty-root/probe.rs

/recorded/workspace/work/uv-workflow-search/phase-costs/trait-rosters/paired/literal-22742-dirty-root/probe.rs:
