#![allow(unused_imports)]
use std::arch::asm;
use std::arch::x86_64::__m128i;

#[cfg(case = "pcmpeqb")]
pub fn probe(mut a: __m128i, b: __m128i) -> __m128i {
    unsafe { asm!("pcmpeqb {a}, {b}", a = inlateout(xmm_reg) a, b = in(xmm_reg) b, options(pure, nomem, preserves_flags, nostack)) };
    a
}

#[cfg(case = "pand")]
pub fn probe(mut a: __m128i, b: __m128i) -> __m128i {
    unsafe { asm!("pand {a}, {b}", a = inlateout(xmm_reg) a, b = in(xmm_reg) b, options(pure, nomem, preserves_flags, nostack)) };
    a
}

#[cfg(case = "pmovmskb")]
pub fn probe(a: __m128i) -> u32 {
    let mask: u32;
    unsafe { asm!("pmovmskb {mask:e}, {a}", mask = lateout(reg) mask, a = in(xmm_reg) a, options(pure, nomem, preserves_flags, nostack)) };
    mask
}

#[cfg(case = "comment")]
pub fn probe(mut a: usize) -> usize {
    unsafe { asm!("/* {0} */", inout(reg) a, options(pure, nomem, preserves_flags, nostack)) };
    a
}

#[cfg(case = "none")]
pub fn probe(a: usize) -> usize { a }

#[cfg(case = "external")]
use std::arch::global_asm;
#[cfg(case = "external")]
global_asm!(".pushsection .rodata", ".incbin \"payload.bin\"", ".popsection");
#[cfg(case = "external")]
pub fn probe(a: usize) -> usize { a }
