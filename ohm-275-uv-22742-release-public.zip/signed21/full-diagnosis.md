# Why signed Ohm −21 rebuilds native uv on an unchanged tree

The first unchanged command was representative of the next two. With the original parent of uv PR 22742, each repeat marked 36 packages as compiling, started four rustc processes, and ran the signed Wild linker twice. All three held the source, target, toolchain, flags and register inputs fixed. The same pair of native products passed the ELF, Git-version, launcher argv, raw stdin, non-UTF8 and child-status checks on all four runs.

| Cargo command on historical A | Wall time under tracing | Cargo progress labels | Kernel rustc execs |
|---|---:|---:|---:|
| Cold seed | 143.468 s | 502 | 627 |
| First unchanged | 4.579 s | 36 | 4 |
| Second unchanged | 4.429 s | 36 | 4 |
| Third unchanged | 4.429 s | 36 | 4 |

The separate V3 unwrapped run took 109.307 s cold and 1.819 s on its first repeat. It stopped before B, with all original gates intact. The four new elapsed observations include Cargo trace logging and kernel exec tracing. They are unsuitable for a wall-time speed claim. The cold trace has 584 named rustc calls, including the standard `___` target probe, plus 43 calls without a crate name. Each repeat has precisely the four named compilations below and zero compiler probes.

## Two distinct reasons at the leaves

On all three repeats the actual `cargo::compiler::fingerprint` log gave each of `constant_time_eq` 0.4.2 and `blake3` 1.8.7 its own `StaleItem(MissingFile)` for `/dev/null/ohm-untracked-relink-inputs`. That path returned ENOTDIR. Each crate retained the path in both its own rustc Make dep-info and its own translated Cargo fingerprint. The historical sources `lib.rs`, `classic.rs`, `generic.rs` and `sse2.rs` in the first crate had unchanged inode, size and nanosecond mtimes. Both complete library rustc arg lists included `-Zohm-check-relink-inputs`. The two uv binaries instead reported a stale dependency fingerprint at `UnitIndex(553)`. Both started rustc and each ran the enrolled `wild-ld/ld.bfd`. Their kernel argv traces show the first 360 argv entries, followed by strace’s explicit ellipsis. They are not evidence about any unprinted final flags.

The native image SHA-256 was unchanged on every repeat for each executable. It was `4c3b97d071037dd580fade791ec5348124beac68789eda2008c1d9cb76ce3ec2` for uv and `8b82d4c7f358e56be89541971197a2f3f4206775d2379a397be9eb0fba77531a` for uvx. The two owning registered relink manifests contained 58 and 67 object entries respectively. The raw input and output evidence is in `../signed21-001/`.

The first crate’s actual rlib contains six `pcmpeqb`, four `pand`, and two `pmovmskb` instructions in its SSE2 path. The signed default target enables SSE2 and omits AVX. Seven independent compiles with the same signed rustc and its real native-input check separate these forms from already-recognized or externally dependent inputs.

| Source compiled in isolation | Result in dep-info |
|---|---|
| Plain Rust | No marker |
| Existing register-only `/* {0} */` barrier | Advisory only |
| `pcmpeqb {a}, {b}` | Hard rebuild marker |
| `pand {a}, {b}` | Hard rebuild marker |
| `pmovmskb {mask:e}, {a}` | Hard rebuild marker |
| `.incbin "payload.bin"`, first and changed contents | Hard rebuild marker both times. Recompiling produced distinct rlibs `b70d7175…` and `d5e0b9f9…`. |

The `.incbin` case exercises both real contents manually. It establishes payload dependence and compiler reporting. The actual unchanged Cargo repetitions establish the separate scheduling behavior on uv.

## What the three-opcode change could remove

A strictly qualified implementation would admit only those three complete x86-64 GNU instruction lines with exactly two rustc-supplied, validated register placeholders. The new case could use `VerifyNativeLink` to produce the versioned advisory. Preserve the fallbacks for unknown assembler blocks, external files, raw or AT&T assembly, unsupported configurations and bundled native archives. Signed −21 Cargo only recognizes the old advisory. It handles the versioned one conservatively. First GNU −22 Cargo is exactly the #330 head `8269d772aa1ef02e5efaa331dfb40eb55d71f719`. It preserves both real advisories so a reused dependency can still require consumers to check native inputs. A matched compiler experiment on this version would use that exact Cargo for both the unmodified and changed rustc. The historical C18-controlled release comparison never activates this classifier. [Rust marker writer](https://github.com/astral-experiments/ohm-rust/blob/556a8364f1485a03be31b1a50c250d63198a943d/compiler/rustc_interface/src/passes.rs#L713-L717) [Cargo reader](https://github.com/astral-experiments/ohm-cargo/pull/330)

`blake3` blocks the expected broad win. Its actual rlib command bundles two archives, `static=blake3_sse2_sse41_avx2_assembly` and `static=blake3_avx512_assembly`. If its marker comes from an unrelated unsupported operation, accepting the three new forms cannot remove it. If the forms are the only unsupported operation, the compiler still sees assembly and then unconditionally returns `Rebuild` for a bundled native archive, before choosing either advisory. A later link reads the bytes already inside the rlib. Rechecking that link cannot bring newly replaced native archive bytes into an already-built rlib. A design to track those actual archive inputs and recover changed, removed or higher-priority candidates would be a separate compiler change. [Rust archive guard](https://github.com/astral-experiments/ohm-rust/blob/556a8364f1485a03be31b1a50c250d63198a943d/compiler/rustc_codegen_llvm/src/asm.rs#L1606-L1618)

Only one of the four observed rustc launches is directly removable by the narrow rule under these conditions. Under tracing, that crate went from kernel exec to the mtime of Cargo’s successfully written library fingerprint in 0.241, 0.223 and 0.239 s. The dependent blake3 process had already started after 0.173, 0.163 and 0.175 s. These are overlapping, instrumented windows. They do not show a causal 0.24 s saving. The simple classifier rule has no demonstrated 2× opportunity on this native launcher workflow. No first edit was performed here. The real signed −18 comparison and any statistical first-edit claim require separate prospective measurement.

The all-state source audit checked 260 Ohm Rust PRs and the actual classifier source at all 25 directly relevant or incompletely listed heads. No existing PR in that snapshot recognized these SSE2 opcodes. Earlier #263 covered a register-comment barrier, and #275 added a different register comment and scalar division. The artifact and source evidence identifies a genuine false-positive reason separately from its limited end-to-end opportunity.

## Reproduce the audit

From this directory run `taskset -c 29 /usr/bin/python3 -ISB read.py`. This verifies the frozen raw logs and receipts and regenerates `analysis.json` byte for byte, without compiling. The original three-arm V3, the physical diagnostic registration and its recorded files remain separate.

| Artifact | SHA-256 |
|---|---|
| Physical controller `../run.py` | `f3ee432618ee8b138a4260d35039dd28ab8d2541e1aa8b09ed7643574bab9c2f` |
| Registered physical study | `2ab879a3d035208e4f5a3f12359f66a8030566c5c7f5e0795473d1d59085df8e` |
| Native intake | `7eb4d6c760fddd5c6718138042b771e1edf8b2febf5175045b5bc6e355f86eea` |
| Closed worker return | `4a27cb80d71293bde55dbd00f39f85d9afe7ff1c65bb0b281df77d9af0c53d52` |
| Complete native observations | `cb6b747131b0d86eb58a177d535eea78265899c462708cd04c5d274e86426677` |
| Derived evidence | `cdc78901e7a25f85c76cb027c77daee20470e1d5bd6f1d42c4b7ffb12d225bf7` |
