"""Deterministic path projection. Actual local names are learned only from a supplied original."""
import gzip
import hashlib
import io
import json
from pathlib import PurePosixPath
import re
import struct
from urllib.parse import urlsplit

ORIGINAL="e58a148372604ee75f7df7da04bcf90cd149d5a454987db113325e1cf77b01d6"
NAMES=("cache_directory","registry_host","workspace","signed21_release_storage","host_scratch","signed21_memory_storage","private_lock_directory","boot_instance")
TARGETS=(b"registry-cache-01",b"registry.invalid",b"/recorded/workspace",b"/recorded/release21",b"/recorded/scratch",b"/recorded/memory",b"/recorded/lease",b"recorded-boot-01")
SOURCE_FIELDS=(
    "uv/registry-receipt.json registry_identity",
    "uv/registry-receipt.json configured_source URI hostname",
    "uv/material.json registry prefix before /work/uv-workflow-search/",
    "uv/subjects.json archive21.path parent",
    "uv/subjects.json archive21.path grandparent",
    "uv/subjects.json arms.signed21.sdk prefix before /release21/sdk",
    "direct/intake.json third locks entry grandparent",
    "direct/intake.json boot")
def need(v,msg):
    if not v:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def spec(z):
    j=lambda n:json.loads(z.read(n))
    r=j("uv/registry-receipt.json");m=j("uv/material.json");s=j("uv/subjects.json");i=j("direct/intake.json")
    archive=PurePosixPath(s["archive21"]["path"])
    values=(r["registry_identity"],urlsplit(r["configured_source"]).hostname,m["registry"].split("/work/uv-workflow-search/",1)[0],
            str(archive.parent),str(archive.parent.parent),s["arms"]["signed21"]["sdk"].rsplit("/release21/sdk",1)[0],
            str(PurePosixPath(i["locks"][2]).parent.parent),i["boot"])
    rules=[]
    for label,source,target,field in zip(NAMES,values,TARGETS,SOURCE_FIELDS):
        raw=source.encode();need(len(raw)>8 and raw!=target,"bad normalization source")
        rules.append((raw,target,{"id":label,"original_token_sha256":sha(raw),"original_token_bytes":len(raw),"published_token":target.decode(),"original_receipt_field":field}))
    need(len({r[0] for r in rules})==len(rules),"duplicate projection rule")
    return rules

def project(name,data,rules):
    binary=name.endswith(".gz");plain=gzip.decompress(data) if binary else data
    content=plain;counts={}
    # The longer registry cache token includes the host. The private release directory
    # includes its scratch parent. Replace each most specific original once per occurrence.
    for old,new,description in sorted(rules,key=lambda r:-len(r[0])):
        n=content.count(old)
        if n:
            need(new not in plain,"placeholder collision in input")
            counts[description["id"]]=n;content=content.replace(old,new)
    if not counts:return data,None
    if binary:
        dst=io.BytesIO()
        with gzip.GzipFile(filename=PurePosixPath(name).stem,mode="wb",compresslevel=1,fileobj=dst,mtime=struct.unpack("<I",data[4:8])[0]) as b:b.write(content)
        stored=dst.getvalue()
    else:stored=content
    return stored,{"counts":counts,"original_sha256":sha(data),"published_sha256":sha(stored),"original_bytes":len(data),"published_bytes":len(stored),
                   "original_content_sha256":sha(plain),"published_content_sha256":sha(content),"gzip":binary}

def timing(name):
    # Complete plain release receipts and associated Cargo outputs, including both
    # cold seeds and the sole earlier unpaired B, must survive byte-for-byte.
    return bool(re.fullmatch(r"(?:direct|previous)/(?:r\d+-(?:signed18|gnu22-cargo18)(?:\.json|/(?:edit|noop|sham)(?:-clock\.json|\.stdout|\.stderr))|seed-(?:signed18|gnu22-cargo18)/(?:cold-A|settled)(?:-clock\.json|\.stdout|\.stderr)|(?:triplets|complete|actual-sdks)\.json)",name))
