# uv #21086 first-edit discovery

From this extracted directory run `python3 -ISB verify.py` with Python 3.10+ and Git 2.44+ on PATH. Git reconstructs the historical child tree in a temporary directory. The verifier derives every timing result from the archived Cargo commands and checks the native parser evidence. No compiler, network or uv checkout is required.

`raw/pairs.jsonl` is the six randomized triples in physical order. Each setup.zip contains the cold parent build and its settled no-op. Each pair ZIP contains the restored-parent no-op, the first full dirty-source check and the following child no-op. The signed release-18 Cargo executable is fixed for all three compilers. The independent parser records are outside the timing study. The original six are discovery only, with zero held-out pairs and no isolated patch-only comparison.
