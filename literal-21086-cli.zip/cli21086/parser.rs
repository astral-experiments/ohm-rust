use clap::{error::ErrorKind, Parser};
use uv_cli::{CheckArgs, Cli, Commands, ProjectCommand};

fn check(args: &[&str]) -> Result<CheckArgs, clap::Error> {
    let result = Cli::try_parse_from(args)?;
    let Commands::Project(group) = *result.command else { panic!("expected project command") };
    let ProjectCommand::Check(check) = *group else { panic!("expected check") };
    Ok(check)
}

fn main() {
    let mode = std::env::args().nth(1).unwrap();
    match mode.as_str() {
        "default" => {
            let ordinary = check(&["uv", "check"]).unwrap();
            assert!(!ordinary.show_version && !ordinary.fix);
            #[cfg(child_edit)]
            assert!(!ordinary.show_command);
            println!("default check");
        }
        "flag" => {
            let parsed = check(&[
                "uv", "check", "--preview-features", "check-command",
                "--script", "script with spaces.py", "--ty-version", "0.0.17", "--show-command",
            ]);
            #[cfg(child_edit)]
            {
                let check = parsed.unwrap();
                assert!(check.show_command && !check.show_version);
                assert_eq!(check.script.as_deref(), Some(std::path::Path::new("script with spaces.py")));
                assert_eq!(check.ty_version.as_deref(), Some("0.0.17"));
                println!("check.show_command=true");
            }
            #[cfg(not(child_edit))]
            {
                let Err(err) = parsed else { panic!("parent accepted --show-command") };
                assert_eq!(err.kind(), ErrorKind::UnknownArgument);
                assert_eq!(err.exit_code(), 2);
                print!("{err}");
            }
        }
        "help" => {
            let Err(err) = check(&["uv", "check", "--help"]) else { panic!("help ran check") };
            assert_eq!(err.kind(), ErrorKind::DisplayHelp);
            let message = err.to_string();
            assert!(message.contains("Usage:") && !message.contains("--show-command"));
            print!("{message}");
        }
        _ => panic!("unknown fixture mode"),
    }
}
