"""Verify source identities in the portable seven-file uv #21086 first-edit packet."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

A = "e6d90a6a80322d12e11089d0d86f767f784529ba"
B = "09d1aa59907756478190bddb095bb6c464668e60"
TREES = {"A": "6707db9058adc53ff852405dc5cea0f4d9157add",
         "B": "8de1b5c4861b007bd956711d0ae5f8b85e8a15bc"}
LOCK = "c1601688714997cf9380248c63a6bbb32537224d"
PATCH = "447da2f1ef61fa7e819d7d3b818e55250918bd5d4f7ebd0e656e2c49728b494c"
MATERIAL = "c065e6844a7a61f93039ccb90e2ada095adcd07f935653d9e9e787ab9258454e"
PATHS = ["crates/uv-cli/src/lib.rs", "crates/uv/src/commands/project/check.rs",
         "crates/uv/src/commands/project/check/ty.rs", "crates/uv/src/lib.rs",
         "crates/uv/src/printer.rs", "crates/uv/src/settings.rs", "crates/uv/tests/project/check.rs"]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args, data=None):
    env = {"PATH": os.environ["PATH"], "LC_ALL": "C", "HOME": os.devnull,
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull,
           "GIT_ATTR_NOSYSTEM": "1", "GIT_NO_LAZY_FETCH": "1",
           "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0", "GIT_ALLOW_PROTOCOL": ""}
    return subprocess.check_output(["git", "--git-dir", repo, "-c", "pack.threads=1",
                                    "-c", "core.autocrlf=false", *args], env=env, input=data)


def roster(repo):
    objects = {A: "commit", B: "commit", LOCK: "blob"}
    states = {}
    for side, rev in (("A", A), ("B", B)):
        assert git(repo, "rev-parse", rev+"^{tree}").decode().strip() == TREES[side]
        objects[TREES[side]] = "tree"
        paths = {}
        for entry in git(repo, "ls-tree", "-r", "-t", "-z", rev).rstrip(b"\0").split(b"\0"):
            info, filename = entry.split(b"\t", 1)
            _, kind, oid = info.decode().split()
            name = filename.decode()
            assert name not in paths
            paths[name] = oid
            if kind == "tree" or name in PATHS or name == ".gitattributes" or name.endswith("/.gitattributes"):
                objects[oid] = kind
        assert paths["Cargo.lock"] == LOCK
        states[side] = paths
    assert states["A"].keys() == states["B"].keys()
    return objects, states


def verify(folder):
    folder = Path(folder)
    raw = (folder/"material.json").read_bytes()
    assert digest(raw) == MATERIAL
    receipt = json.loads(raw)
    assert (receipt["A"], receipt["B"], receipt["patch_sha256"]) == (A, B, PATCH)
    assert receipt["complete_changed_paths"] == PATHS
    assert {s: v["tree"] for s, v in receipt["trees"].items()} == TREES
    assert receipt["checkout_lock"] == receipt["registry"]["lock"] == LOCK
    assert receipt["registry"]["packages"] == 683
    delta = (folder/"edit.patch").read_bytes()
    assert digest(delta) == PATCH
    pack = (folder/"source.pack").read_bytes()
    assert pack.startswith(b"PACK") and len(pack) <= 1024*1024
    with tempfile.TemporaryDirectory(prefix="uv21086-") as tmp:
        repo = Path(tmp)/"objects.git"
        git(repo, "init", "--bare", "--quiet", "--template=")
        git(repo, "index-pack", "--stdin", data=pack)
        assert git(repo, "rev-parse", B+"^").decode().strip() == A
        assert git(repo, "rev-parse", A+"^").decode().strip() == receipt["parent_of_A"]
        allowed, states = roster(repo)
        listed = dict(row.split() for row in git(repo, "cat-file", "--batch-all-objects",
                                                "--batch-check=%(objectname) %(objecttype)").decode().splitlines())
        assert listed == allowed
        assert git(repo, "diff", "--no-ext-diff", "--binary", "--full-index", "--no-renames", A, B) == delta
        assert git(repo, "diff-tree", "--no-commit-id", "-r", "--name-status",
                   "--no-renames", A, B).decode().splitlines() == ["M\t"+p for p in PATHS]
        # Populate a private index at A. Unmodified blobs are deliberately absent.
        git(repo, "read-tree", A)
        git(repo, "apply", "--cached", "--whitespace=nowarn", "-", data=delta)
        assert git(repo, "write-tree", "--missing-ok").decode().strip() == TREES["B"]
        for rel in PATHS:
            assert states["A"][rel] != states["B"][rel]
        counts = {k: list(allowed.values()).count(k) for k in ("commit", "tree", "blob")}
    return {"A": A, "B": B, "trees": TREES, "paths": PATHS, "patch_sha256": PATCH,
            "lock": LOCK, "counts": counts}
