"""Verify the historical Git edit, raw Cargo records and all three independently linked native parsers."""
import hashlib
import itertools
import json
import random
import re
import runpy
import statistics
import zipfile
from pathlib import Path

D=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
median=statistics.median
REG='b3625c9f786ed6c2cc3688b3368c5ea14b1cc517fe26fd36c2f242ff78b2c1c0'
SMOKE='f2f82fb1d09efad5e4a1e8c484eda2818e08769bb7a8804979e6aee6dbbd1d8a'
PARSER='3c4dfb462dc7e9d09c695797afb2c36f944e2f63778143777945c36515806ebb'
QA='ddff6f15bd8f2ac6e6a13cf73200da7567bb57ec5ca96aea2f09938e32478914'
CLOCK='dc9917529ea8b3021a8d89f70d7e85a7677aad34a66b667863be0b203cefeb3e'
CARGO='02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573'
RELCARGO='4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e'
LLVM='43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51'
DRIVERS={'stock':'a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de','parent':'5c7784b3fc4a1a2502e8a89ab7187effb27e31d0ece8510c09995e6c09d4c239','candidate':'dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3'}
LAUNCHERS={'stock':'c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60','parent':'c930b062ca10b3f3da27804ac86e4e7a54f0213fe119ca1cc244c4ac04eea85c','candidate':'f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9'}
ROLES={'stock':'signed18','parent':'matched278-on','candidate':'released21'}
CMD=['/tmp/uv-workflow-search/sdk/bin/cargo','check','-p','uv-cli','--locked','--offline','-j8']
STATES=('settled-A','edit-D','noop-D')
SUFFIXES=('.json','.primary.json','.stderr','.stdout','.usage.json')
def archive(z,states):
    names={state+s for state in states for s in SUFFIXES}
    assert set(z.namelist())==names and len(z.infolist())==len(names) and all(i.file_size<300000 for i in z.infolist())
    assert z.testzip() is None
def command(z,name,dirty,wall=None):
    record=json.loads(z.read(name+'.json'));err=z.read(name+'.stderr')
    assert record['cmd']==CMD and record['wall_s']>0
    if wall is not None:assert record['wall_s']==wall
    work=re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)
    if dirty is None:assert record['dirty_units'].count('uv_cli')==work.count(b'uv-cli')==1
    else:assert record['dirty_units']==dirty and work==([b'uv-cli'] if dirty else [])
    usage=json.loads(z.read(name+'.usage.json'));assert usage['user_us']+usage['sys_us']>0
    assert b'Finished' in err and z.read(name+'.stdout')==b''
    return json.loads(z.read(name+'.primary.json'))
def parser(folder,role,src,accept,original):
    obs={}
    for st in ('A','B'):
        row=read(folder/(st+'.json'))
        outputs={k:(folder/(st+'.'+k+'.stdout')).read_bytes() for k in ('default','flag','help')}
        assert row['state']==st and row['role']==role and row['source']['head']==src['A'] and row['source']['source_tree']==src['trees'][st]
        assert row['source']['dirty_paths']==([] if st=='A' else src['paths'])
        assert (row['cargo'],row['driver'],row['cold_target'],row['witness'],row['exit'])==(CARGO,DRIVERS[role],True,PARSER,0)
        assert row['cargo_argv']==[CMD[0],'build','--locked','--offline','-j8','-p','uv-cli','--lib']
        log=(folder/(st+'.cargo.log')).read_bytes();assert sha(log)==row['cargo_sha256'] and b'Compiling uv-cli v' in log and b'Finished' in log
        argv=row['rustc_argv']
        assert argv[:5]==['/tmp/uv-workflow-search/sdk/bin/rustc','--edition=2024','parser.rs','-C','debuginfo=0']
        assert ('child_edit' in argv)==(st=='B') and argv[-2]=='-o' and argv[-1].endswith('/witness')
        externs=[argv[i+1] for i,k in enumerate(argv) if k=='--extern']
        for lib in ('clap','uv_cli'):
            assert any(v.startswith(lib+'=') and v.endswith('.rlib') for v in externs)
        assert all(re.fullmatch('[a-f0-9]{64}',row[k]) for k in ('program','unit','clap'))
        assert row['outputs']=={k:sha(v) for k,v in outputs.items()}==accept[st]['outputs']
        assert accept[st]['row']==original[role+'/'+st+'.json']['sha256']
        assert outputs['default']==b'default check\n' and b'Usage:' in outputs['help'] and b'--show-command' not in outputs['help']
        assert outputs['flag'].startswith(b"error: unexpected argument '--show-command' found") if st=='A' else outputs['flag']==b'check.show_command=true\n'
        obs[st]=row
    assert all(obs['A'][k]!=obs['B'][k] for k in ('program','unit'))
    assert obs['A']['outputs']['help']==obs['B']['outputs']['help']
    assert read(folder/'return.json')=={'exit':0,'registration':REG,'driver':DRIVERS[role]}
def verify():
    assert __debug__
    files=read(D/'files.json')
    assert set(files)=={x.relative_to(D).as_posix() for x in D.rglob('*') if x.is_file() and x!=D/'files.json'}
    assert all(not (D/n).is_symlink() and sha((D/n).read_bytes())==v for n,v in files.items())
    src=runpy.run_path(str(D/'source.py'))['verify'](D)
    p=read(D/'provenance.json');sm=read(D/'worker-namespace.json')
    assert sha((D/'worker-namespace.json').read_bytes())==SMOKE and sm['registration']==p['registration']==REG
    assert p['roles']==ROLES and p['seed']==212108601 and p['threshold']==1.8 and p['heldout_triples']==0
    rel=p['release21'];assert rel['source']=='c79998a5cd143c445a4b2528f20953b176a65c5d' and rel['tag']=='ohm-1.99.0-21' and rel['archive_sha256']=='6f550de85f95440a61b5bd1a9d2ab0528d4fcaf674fdc008f5e986d2138be6c4'
    assert p['local_stage2']['historical']['candidate_sha256']==DRIVERS['parent'] and p['local_stage2']['historical']['launcher_sha256']==LAUNCHERS['parent']
    assert sha((D/'parser.rs').read_bytes())==PARSER and sha((D/'parser/accepted.json').read_bytes())==QA
    q=read(D/'parser/accepted.json');assert q['registration']==REG and q['namespace']==SMOKE and q['cold_parsers']==6 and q['timing_rows']==0
    data=(D/'raw/pairs.jsonl').read_bytes()
    rows=[json.loads(r) for r in data.splitlines()]
    seq=list(itertools.permutations(sorted(ROLES)));random.Random(p['seed']).shuffle(seq)
    assert len(rows)==6 and list(map(list,seq))==p['sequence']==p['enrolled_orders']['discovery']==[list(x) for x in rows]
    for role in ROLES:
        arm=D/'raw'/role;idn=read(arm/'identity.json');cfg=p['inputs'][role];probe=sm['arms'][role]
        assert (idn['launcher'],idn['cargo'])==(LAUNCHERS[role],CARGO)==(cfg['launcher'],cfg['cargo'])==(probe['launcher'],probe['cargo'])
        assert (DRIVERS[role],LLVM)==(probe['driver'],p['llvm'])
        assert set(probe['loaded'].values())=={z['sha256'] for z in idn['linked'].values()}=={DRIVERS[role],LLVM}
        assert cfg['sdk_cargo_before_overlay']==(RELCARGO if role=='candidate' else CARGO)
        assert (arm/'cargo.txt').read_text().strip()==probe['versions']['cargo'].strip() and (arm/'rustc.txt').read_text().strip()==probe['versions']['rustc'].strip()
        lines=(arm/'protocol.log').read_text().splitlines(); reg=json.loads(lines[0]);assert reg['packages']==683 and reg['lock']==src['lock']
        assert [json.loads(s[7:])for s in lines if s.startswith('UVPAIR ')]==[{'state':'ready','patch':src['patch_sha256']}]+[row[role]for row in rows]
        meta=read(arm/'metadata.json')
        assert set(meta)=={'A','B'} and meta['A']['sha256']!=meta['B']['sha256'] and all(re.fullmatch('[0-9a-f]{64}',m['sha256'])for m in meta.values())
        with zipfile.ZipFile(arm/'setup.zip')as z:
            archive(z,('warm','settled'))
            warm=command(z,'warm',None);assert command(z,'settled',[])==warm=={k:v for k,v in meta['A'].items() if k!='sha256'}
        for i,row in enumerate(rows,1):
            clock=row[role];assert clock['state']=='measured' and clock['trial']==str(i) and clock['dirty']==['uv_cli']
            with zipfile.ZipFile(arm/f'pair-{i}.zip')as z:
                archive(z,STATES)
                a,b,c=(command(z,s,dirty,clock[w]) for s,dirty,w in zip(STATES,([],['uv_cli'],[]),('parent_noop','edit','noop'),strict=True))
                assert a['name']==b['name']==warm['name'] and a!=b==c
                assert (a['size'],a['mtime'])==(warm['size'],warm['mtime'])
                if i==6:assert b=={k:v for k,v in meta['B'].items() if k!='sha256'}
        parser(D/'parser'/role,role,src,q['programs'][role],p['original_parser_rows'])
    assert sha(data)==CLOCK
    def ratios(a,b):
        if b=='parent':return [(r[a]['edit']/r['candidate']['edit'])/(r[b]['edit']/r['candidate']['edit']) for r in rows]
        return [r[a]['edit']/r[b]['edit'] for r in rows]
    ratios_by_name={ROLES[k]+'/'+ROLES[v]:ratios(k,v) for k,v in (('stock','parent'),('stock','candidate'),('parent','candidate'))}
    direct=ratios_by_name['signed18/released21'];assert median(direct)<p['threshold']
    score={'discovery':{k:median(v) for k,v in ratios_by_name.items()},'discovery_seconds':{label:median(r[k]['edit']for r in rows)for k,label in ROLES.items()},'excluded_triples':6,'heldout_triples':0,'opens_confirmation':False}
    assert score==read(D/'registered-score.json')
    return {'registered_score':score,'paired_ratios':ratios_by_name,'direct_range':[min(direct),max(direct)],'signed21_faster':sum(x>1 for x in direct),'first_edits_with_one_dirty_uv_cli':18,'immediately_preceding_clean':18,'immediately_following_clean':18,'fresh_cold_A_histories':3,'post_warmup_clean':3,'parser_builds':6,'parser_processes':18,'source':src}
if __name__=='__main__':print(json.dumps(verify(),indent=2,sort_keys=True))
