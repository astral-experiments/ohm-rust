"""Portable definitions for the literal-parent shipped-stack records."""
import hashlib
import itertools
import json
import math
import random
import re
import statistics
import zipfile
from pathlib import Path

D = Path(__file__).resolve().parent
REG = "5bfaa71c9bf59c22844768175ca826855cf136b0ac9f4edd900850a293b474f3"
SCORE = "8e063421a8bbcaa08c72dade8239d547cc8f417860dcc2ad5ec5a7df5c38aa49"
BRIDGE = "4f25cd4e712f3a2e5fb28f158acefc5310093137ce863e78093c1a8b38f900aa"
SOURCE = ["9f5808695af96f92daf680ded0ebe939869241ed","79ef389e39e3b21a5443b7ab25e890f33b0dadf9"]
PATCH = "d8ba1f8ed9b1ad4a2256c38373cf9a6912b4e8a5267874bd35aa570bc535cc28"
CARGO = "02a86ebd2d9e4f237b33f212102b81ed145eb77fae090d67e379cb6f1d70a573"
RELCARGO = "4695ab8e260ba4d6363e42b785c8f410dd79d9255f0313dab6c19e978878f43e"
CARGOS = {"stock":CARGO,"parent":CARGO,"candidate":RELCARGO}
R18 = "a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de"
R21 = "dae4f8dc64b2b2ac9dc04dfe2cfad633d6af1a87da2dfc532e757ffe758680e3"
DRIVERS = {"stock":R18,"parent":R21,"candidate":R21}
L18 = "c6ab483d6698f68eebb49d74b27361f3e02ede55452dc0416c3fdec9a45b7f60"
L21 = "f7663fb7dec7e5c7ea613a85ff1d6e4c00bf97b8c50534f17e5c95cd599712b9"
LAUNCHERS = {"stock":L18,"parent":L21,"candidate":L21}
LLVM = "43bac9749e539cd5988a4d5452b64582cf07ac9e7c059fde29c7bee76e106c51"
ARCHIVES = {"signed18":"629abab6a87c84bb4d910549ca96a31e437e3dc9de3039fedcbb7b50d198a5e8","signed21":"6f550de85f95440a61b5bd1a9d2ab0528d4fcaf674fdc008f5e986d2138be6c4"}
CMD = ["/tmp/uv-workflow-search/sdk/bin/cargo","check","-p","uv-cli","--locked","--offline","-j8"]
PH = ("discovery","confirm-1","confirm-2")
ROLES = {"stock":"R18/C18","parent":"R21/C18","candidate":"R21/C21"}
CONTRAST = [("stock","parent","fixed signed Cargo18: rustc18+std18 / rustc21+std21"),
            ("stock","candidate","complete signed stack18 / complete signed stack21"),
            ("parent","candidate","fixed rustc21+std21: Cargo18 / Cargo21")]
med = statistics.median
def read(p):
    return json.loads(p.read_bytes())
def sha(b):
    return hashlib.sha256(b).hexdigest()


def stats(cohorts):
    def ratio(row,a,b):
        # Preserve the registered signed/on arithmetic, including its division order.
        return (row[a]['edit']/row['candidate']['edit'])/(row[b]['edit']/row['candidate']['edit']) if b=='parent' else row[a]['edit']/row[b]['edit']
    def phases(rows):
        return {v:med(r[k]['edit']for r in rows) for k,v in ROLES.items()}
    d=cohorts[0];h=cohorts[1:];allh=h[0]+h[1];result={}
    for a,b,label in CONTRAST:
        t=1 if a=='parent' else 2;alpha=.05 if t==1 else .025
        v=[ratio(r,a,b)for r in allh];ordered=sorted(v);i=max(k for k in range(6)if 2*sum(math.comb(12,j)for j in range(k+1))/4096<=alpha)
        interval=[ordered[i],ordered[-1-i]];seeds=[med(ratio(r,a,b)for r in h1)for h1 in h];strata=[[x for x,r in zip(v,allh)if (list(r).index(a)<list(r).index(b))==first]for first in (False,True)]
        assert list(map(len,strata))==[6,6]
        by_order=list(map(med,strata));v2=[x for x in v if x!=t];n=len(v2);high=sum(x>t for x in v2);pv=sum(math.comb(n,j)for j in range(high,n+1))/2**n
        result[label]=dict(median=med(v),interval=interval,p=pv,threshold=t,seed_medians=seeds,order_medians=by_order,passed=interval[0]>t and pv<alpha and min(seeds+by_order)>t)
    disc={label:med(ratio(r,a,b)for r in d)for a,b,label in CONTRAST}
    assert disc[CONTRAST[1][2]]>=1.8
    return dict(excluded_triples=6,opens_confirmation=True,discovery=disc,discovery_seconds=phases(d),heldout_triples=12,heldout_seconds=phases(allh),contrasts=result,primary_direct_2x=result[CONTRAST[1][2]]['passed'])

def phase(p,idx,smoke,source):
    plan=read(p/'plan.json');rows=[json.loads(s)for s in (p/'pairs.jsonl').read_bytes().splitlines()];seq=list(itertools.permutations(sorted(ROLES)));random.Random(218761801+idx).shuffle(seq)
    assert plan['config']['seed']==218761801+idx and plan['config']['pairs']==6 and plan['config']['case']=='literal21076-cli' and plan['config']['plain'] and not plan['config']['diagnostics']
    assert plan['source']==source and plan['sequence']==list(map(list,seq))==[list(r)for r in rows] and len(rows)==6
    for role in ROLES:
        arm=p/role;ident=read(arm/'identity.json');meta=read(arm/'metadata.json');cfg=plan['inputs'][role]
        assert read(arm/'worker-mounted.json')==smoke[role]
        assert cfg['cargo']==ident['cargo']==CARGOS[role] and cfg['launcher']==ident['launcher']==LAUNCHERS[role]
        assert cfg['sdk_cargo_before_overlay']==(CARGO if role=='stock' else RELCARGO) and DRIVERS[role]in cfg['drivers'].values()
        assert {v['sha256']for v in ident['linked'].values()}=={DRIVERS[role],LLVM}
        assert set(meta)=={'A','B'} and all(re.fullmatch('[0-9a-f]{64}',v['sha256'])for v in meta.values()) and meta['A']['sha256']!=meta['B']['sha256']
        assert (arm/'cargo.txt').read_text().strip()==smoke[role]['versions']['cargo'].strip() and (arm/'rustc.txt').read_text().strip()==smoke[role]['versions']['rustc'].strip()
        log=(arm/'protocol.log').read_text().splitlines();reg=json.loads(log[0]);assert reg['packages']==683 and reg['lock']=='c1601688714997cf9380248c63a6bbb32537224d'
        msgs=[json.loads(s[7:])for s in log if s.startswith('UVPAIR ')]
        assert msgs==[{'state':'ready','patch':PATCH}]+[r[role]for r in rows]
        with zipfile.ZipFile(arm/'setup.zip')as z:
            warm=json.loads(z.read('warm.json'));settled=json.loads(z.read('settled.json'))
            assert warm['cmd']==settled['cmd']==CMD and 'uv_cli'in warm['dirty_units'] and settled['dirty_units']==[]
        for i,r in enumerate(rows,1):
            assert r[role]['state']=='measured'and r[role]['trial']==str(i)and r[role]['dirty']==['uv_cli']
            with zipfile.ZipFile(arm/f'pair-{i}.zip')as z:
                prim={}
                for n,k,dirty in [('settled-A','parent_noop',[]),('edit-D','edit',['uv_cli']),('noop-D','noop',[])]:
                    rec=json.loads(z.read(n+'.json'));err=z.read(n+'.stderr')
                    assert rec['cmd']==CMD and rec['dirty_units']==dirty and rec['wall_s']==r[role][k]>0
                    assert re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)==([b'uv-cli']if dirty else []) and b'Finished'in err and not z.read(n+'.stdout')
                    usage=json.loads(z.read(n+'.usage.json'));assert usage['user_us']+usage['sys_us']>0
                    prim[n]=json.loads(z.read(n+'.primary.json'))
                a,b,c=[prim[n] for n in ('settled-A','edit-D','noop-D')];assert a['name']==b['name'] and a!=b==c
                if i==6:assert b=={k:v for k,v in meta['B'].items()if k!='sha256'}
    return rows
