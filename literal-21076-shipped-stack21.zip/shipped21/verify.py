"""Offline replay. Pass --controls to challenge the independent reader with altered records."""
import gzip
import io
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay import *
import execs


def source():
    ref = read(D/"source.json")
    assert [ref["parent"],ref["child"]] == SOURCE
    pack = (D/"source.pack").read_bytes()
    patch = (D/"edit.patch").read_bytes()
    assert sha(pack) == "68726072ee06da9d8f79b7fb640236b1970a83cba760db6ee116a80449a499e7"
    assert sha(patch) == PATCH and ref["lock_oid"] == "c1601688714997cf9380248c63a6bbb32537224d"
    env = dict(PATH=os.environ["PATH"], LC_ALL="C", GIT_CONFIG_GLOBAL=os.devnull,
               GIT_CONFIG_NOSYSTEM="1", GIT_NO_LAZY_FETCH="1", GIT_ALLOW_PROTOCOL="file")
    with tempfile.TemporaryDirectory() as temp:
        def git(*args, data=None):
            return subprocess.check_output(["git","--git-dir",Path(temp)/"git",*args], env=env, input=data)
        git("init","--quiet","--bare")
        git("index-pack","--stdin",data=pack)
        assert git("rev-parse",SOURCE[1]+"^").decode().strip() == SOURCE[0]
        assert git("diff","--binary","--full-index","--no-renames","--no-ext-diff",*SOURCE,"--") == patch
        for i,rev in enumerate(SOURCE):
            assert git("rev-parse",rev+"^{tree}",rev+":Cargo.lock").decode().splitlines() == [ref["tree"][i],ref["lock_oid"]]
            assert sha(git("cat-file","blob",rev+":Cargo.lock")) == ref["lock_sha256"]
            assert all(git("rev-parse",rev+":"+n).decode().strip() == ids[i] for n,ids in ref["files"].items())


def inputs():
    p=read(D/"provenance.json"); ns=read(D/"worker-namespace.json")["arms"]; signed=read(D/"signed.json")
    assert p["registration_sha256"]==REG and p["score_sha256"]==SCORE and p["heldout_summary_sha256"]==BRIDGE
    assert signed["archive_sha256"]==ARCHIVES and signed["release21_archive_bytes"]==359657153
    assert p["registration"]["roles"]==ROLES and p["registration"]["cargo"]==CARGOS and p["registration"]["drivers"]==DRIVERS
    assert p["registration"]["source"]==SOURCE+[PATCH] and p["registration"]["zero_prior_scientific_rows"]==0 and p["registration"]["gate"]==1.8
    ref=signed["files"]
    assert [len(ref[k])for k in ("signed18","signed21")]==[71,67]
    for role,arm in ns.items():
        what="signed18" if role=="stock" else "signed21"; files=ref[what]
        assert (arm["driver"],arm["launcher"],arm["cargo"],set(arm["loaded"].values()),arm["timing_rows"])==(DRIVERS[role],LAUNCHERS[role],CARGOS[role],{DRIVERS[role],LLVM},0)
        assert files["bin/rustc"]["sha256"]==arm["launcher"] and files["bin/cargo"]["sha256"]==(CARGO if what=="signed18" else RELCARGO)
        assert {v["sha256"]for n,v in files.items()if "librustc_driver-" in n or n.endswith("libLLVM.so.23.1-rust-1.99.0-beta")}=={DRIVERS[role],LLVM}
    assert ns["parent"]["versions"]["rustc"]==ns["candidate"]["versions"]["rustc"] and ns["parent"]["versions"]["cargo"]==ns["stock"]["versions"]["cargo"]!=ns["candidate"]["versions"]["cargo"]
    return ns,p


def parser(role):
    seen=[]
    for state in ("A","B"):
        folder=D/"parser"/role
        j=read(folder/(state+"-behavior.json")); build=read(folder/(state+"-build.json"))
        name={"stock":"stock18","parent":"release21","candidate":"candidate"}[role]
        assert (j["source"],j["arm"],j["compiler_sha256"],j["expected_clap_exit"],j["fresh_empty_cargo_target"])==(state,name,DRIVERS[role],2,True)
        assert j["witness_source"]==sha((D/"parser.rs").read_bytes())=="a68406fb268b51d34bd33f13b8746b4fc5057b9b5536086869e0c028f8da0915"
        assert j["diagnostic"]=="error: invalid bump component `foo`"+("" if state=="A" else "\n\nUsage: uv version [OPTIONS] [VALUE]\n\nFor more information, try '--help'.\n")
        assert build["exit"]==0 and build["argv"][1:]==["build","--locked","--offline","-j8","-p","uv-cli","--lib"]
        assert build["end_ns"]-build["start_ns"]==build["elapsed_ns"]>0
        log=folder/(state+"-build.cargo.log")
        if role!="stock":
            assert log.stat().st_size==build["bytes"] and sha(log.read_bytes())==build["stdout_sha256"]
        seen.append(j)
    assert all(seen[0][k]!=seen[1][k] for k in ("program_sha256","libuv_cli_sha256"))


def detail(role):
    folder=D/"detail"/role; j=read(folder/"detailed.json");cmd=CMD+["-vv","--message-format=json-render-diagnostics"]
    assert j["cargo_argv"]==cmd and j["measured_rows"]==0 and j["patch"]==PATCH
    assert j["driver"]==DRIVERS[role] and j["cargo_sha256"]==CARGOS[role]
    for n,h in j["raw"].items():
        if n!="detailed-B.stdout":
            assert sha((folder/n).read_bytes())==h
    with gzip.open(folder/"detailed-execve.gz","rt") as f:
        argv=execs.bindings((line.rstrip("\n")for line in f),Path(CMD[0]).parents[1],cmd)
    assert argv==j["rustc_argv"] and j["threads_args"]==[x for x in argv if x.startswith("-Zthreads=")]
    jsonl=[json.loads(x)for x in (folder/"detailed-B.portable.jsonl").read_bytes().splitlines()]
    assert jsonl[-1]=={"reason":"build-finished","success":True}
    dirty=[x for x in jsonl if x["reason"]=="compiler-artifact" and not x["fresh"]]
    assert len(dirty)==1 and dirty[0]["target"]["name"]=="uv_cli" and "lib" in dirty[0]["target"]["kind"]
    for state in ("before","after"):
        assert not (folder/("detailed-"+state+".stdout")).read_bytes()
        err=(folder/("detailed-"+state+".stderr")).read_bytes()
        assert b"Finished" in err and not re.findall(rb"^\s*(?:Checking|Compiling) ([\w-]+) v",err,re.M)
    return {"cargo_sha256":CARGOS[role],"role":ROLES[role],"rustc_argv":argv}


def bridge(blocks,score):
    b=read(D/"heldout-bridge-summary.json");assert b["official_score"]==score and b["source_score_sha256"]==SCORE and b["registration"]==REG
    rows=[]
    for ph,block in zip(PH[1:],blocks[1:]):
        for i,row in enumerate(block,1):
            rr={}
            for role,cell in row.items():
                with zipfile.ZipFile(D/ph/role/f"pair-{i}.zip") as z:u=json.loads(z.read("edit-D.usage.json"))
                rr[role]=dict(wall=cell["edit"],user_cpu=u["user_us"]/1e6,system_cpu=u["sys_us"]/1e6)
            def div(a,c):return rr[a]["wall"]/rr[c]["wall"]
            rows.append(dict(seed=ph,i=i,order=list(rr),roles=rr,whole=div("stock","candidate"),fixed=div("stock","parent"),cargo=div("parent","candidate")))
    assert rows==b["heldout_rows"]
    counts={}
    for key in ("whole","fixed","cargo"):
        counts[key]=[sum(r[key]>1 for r in rows),sum(r[key]>2 for r in rows)]
        assert counts[key]==[b[key+"_positive"],b[key+"_over_two"]]
    assert counts=={"whole":[12,4],"fixed":[12,4],"cargo":[6,0]}
    return counts


def verify():
    assert __debug__; files=read(D/"files.json")
    assert set(files)=={str(p.relative_to(D))for p in D.rglob("*")if p.is_file() and p!=D/"files.json"}
    assert all(not (D/n).is_symlink() and sha((D/n).read_bytes())==h for n,h in files.items())
    source();smoke,p=inputs()
    assert sha((D/"physical-score.stdout").read_bytes())==SCORE and sha((D/"heldout-bridge-summary.json").read_bytes())==BRIDGE
    assert all(p["raw"][n]["sha256"]==h for n,h in files.items() if n in p["raw"] and n not in p["projected"])
    for role in ROLES: parser(role)
    blocks=[phase(D/ph,k,smoke,SOURCE)for k,ph in enumerate(PH)]
    score=stats(blocks);argv={r:detail(r)for r in ROLES}
    assert {**score,"actual_Cargo_and_rustc_argv":argv}==read(D/"physical-score.stdout")
    counts=bridge(blocks,score)
    return dict(registration=REG,source=SOURCE,excluded_triples=6,heldout_triples=12,first_edits=54,clean_noops=108,independent_cold_histories=9,parser_A_B_outcomes=6,untimed_kernel_execs=3,heldout_counts_greater_one_two=counts,scored=score)


def controls():
    smoke,_=inputs()
    def refused(operation):
        try:operation()
        except (AssertionError,KeyError,ValueError):return
        raise AssertionError("mutation accepted")
    outcomes=[]
    for change in ("wrong_cargo","cross_trial_pair","changed_raw_clock"):
        with tempfile.TemporaryDirectory() as t:
            dest=Path(t)/"phase";shutil.copytree(D/PH[1],dest)
            if change=="wrong_cargo":
                j=read(dest/"candidate/identity.json");j["cargo"]=CARGO
                (dest/"candidate/identity.json").write_text(json.dumps(j))
            elif change=="cross_trial_pair":
                f=dest/"pairs.jsonl"; a=[json.loads(x)for x in f.read_bytes().splitlines()]
                for label in ("edit","parent_noop","noop"):
                    a[0]["parent"][label],a[1]["parent"][label]=a[1]["parent"][label],a[0]["parent"][label]
                f.write_text("".join(json.dumps(x)+"\n"for x in a))
            else:
                f=dest/"stock/pair-1.zip"
                with zipfile.ZipFile(f)as z: parts={n:z.read(n)for n in z.namelist()}
                j=json.loads(parts["edit-D.json"]);j["wall_s"]+=0.01;parts["edit-D.json"]=json.dumps(j).encode()
                with zipfile.ZipFile(f,"w")as z:
                    for n,v in parts.items():z.writestr(n,v)
            refused(lambda:phase(dest,1,smoke,SOURCE))
            outcomes.append(change)
    return outcomes


if __name__=="__main__":
    assert sys.argv[1:] in ([],["--controls"])
    result=verify()
    if sys.argv[1:]:result["rejected"]=controls()
    print(json.dumps(result,indent=2))
