"""Decode complete successful kernel exec argument vectors."""
import re
# strace -xx encodes every string byte, including quotes, commas and backslashes.
HEX=r'(?:\\x[0-9a-f]{2})*'
CALL=re.compile(r'^execve\("('+HEX+r')", \[((?:"'+HEX+r'"(?:, )?)*)\], [^)]*\)\s+= 0$')
def strings(line):
    found=CALL.fullmatch(line)
    if not found:
        if line.startswith('execve(') and line.rstrip().endswith('= 0'):
            raise ValueError('successful execve beyond the complete argv or string bound')
        return None
    def decode(text):return bytes.fromhex(text.replace('\\x','')).decode()
    return [decode(found[1]),[decode(x)for x in re.findall(r'"('+HEX+r')"',found[2])]]
def bindings(lines,sdk,cmd):
    calls=[x for line in lines if (x:=strings(line))]
    assert [a for f,a in calls if f==str(sdk/'bin/cargo')]==[cmd]
    rustc=str(sdk/'bin/rustc')
    rows=[(f,a) for f,a in calls if '--crate-name' in a]
    assert len(rows)==1,[(f,a[a.index('--crate-name')+1]) for f,a in rows]
    f,a=rows[0];assert f==a[0]==rustc and a[a.index('--crate-name')+1]=='uv_cli'
    assert a[a.index('--crate-type')+1]=='lib' and any(x.startswith('--emit=') and 'metadata' in x for x in a)
    assert any(x.endswith('crates/uv-cli/src/lib.rs') or x=='src/lib.rs' for x in a)
    return a
