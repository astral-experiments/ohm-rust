"""Use Cargo's actual executable extern linkage for the unchanged #22958 trait witness."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from unittest.mock import patch

D=Path(__file__).resolve().parent
ORIGINAL=D.parent/'schema-22958-finite306'
spec=importlib.util.spec_from_file_location('original_22958_two_arm_study',ORIGINAL/'run.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
read,sha=t.read,t.sha
OLD=t.qa.trait_control
OLD_EVIDENCE=t.qa.evidence
BASE_AUDIT=t.audit
NAMES=('serde','uv_configuration')
def externs(argv,name):
    return [x.partition('=')[2] for n,x in enumerate(argv[1:]) if argv[n]=='--extern' and x.startswith(name+'=')]
def selected(rows,owners):
    binary,=[r for r in owners if r['crate']=='uv' and r['role']=='bin']
    argv=binary['argv'];paths={}
    for name,importer in (('serde','uv_configuration'),('uv_configuration','uv_cli')):
        selected_owner,=[r for r in owners if r['crate']==importer and r['role']=='lib']
        ref,=externs(selected_owner['argv'],name)
        paths[name]=externs(argv,name)
        pair=[Path(x)for x in paths[name]]
        assert [p.suffix for p in pair]==['.rlib','.rmeta'] and pair[0].with_suffix('.rmeta')==pair[1] and Path(ref) in pair
        hit,=[r for r in rows if r['target']['name']==name and 'lib'in r['target']['kind'] and all(str(f)in r['filenames']for f in pair)]
        assert all(p.is_absolute() and p.is_relative_to(t.qa.target) and p.stem.startswith('lib'+name+'-')for p in pair)
    args=[]
    for i,flag in enumerate(argv[:-1]):
        if flag=='--extern' and argv[i+1].partition('=')[0] in NAMES:
            args.extend([flag,argv[i+1]])
    assert len(args)==8
    return paths,args,t.qa.input_options(argv)
def diagnostics(raw,state):
    logs=[json.loads(line)for line in raw.splitlines()if line]
    errors=[q for q in logs if q.get('level') in ('error','error: internal compiler error')]
    if state=='A':
        real=[q for q in errors if not(q.get('code')is None and q['message']=='aborting due to 1 previous error')]
        assert len(real)==1 and real[0]['code']['code']=='E0432' and real[0]['message']=='unresolved import `uv_configuration::MetadataOutputVersion`'
        prim,=[s for s in real[0]['spans']if s['is_primary']]
        assert prim['line_start']==12 and prim['text'][0]['text'].strip()=='use uv_configuration::MetadataOutputVersion;'
    else:
        assert state in ('B','fresh-B') and not errors
    return [q['message'] for q in errors]
def link_command(cmd,source,old_flags,extern,search):
    i=cmd.index('-o');assert list(cmd[5:i])==old_flags
    assert list(map(str,cmd[:5]))==[str(t.qa.sdk/'bin/rustc'),'--edition=2024',str(source),'--crate-name','fixed_trait_witness']
    return list(cmd[:5])+search+extern+list(cmd[i:])
def trait(dest,env,rows,owners,state):
    paths,extern,search=selected(rows,owners)
    old_search=t.qa.input_options(next(z['argv']for z in owners if z['crate']=='uv_cli' and z['role']=='lib'))
    old_flags=old_search+sum((['--extern',name+'='+paths[name][0]]for name in ('uv_configuration','serde')),[])
    info={n:[dict(path=x,sha256=sha(Path(x)),bytes=Path(x).stat().st_size)for x in hits]for n,hits in paths.items()}
    assert all(Path(row['path']).resolve(strict=True).is_relative_to(t.qa.target) and row['bytes']>0 for hits in info.values()for row in hits)
    base=t.qa.run
    def run(cmd,src,e,dst,label,*rest):
        if label in ('old-trait-build','introduced-traits-build'):
            cmd=link_command(cmd,D/'trait-control.rs',old_flags,extern,search)
        result=base(cmd,src,e,dst,label,*rest)
        if label=='introduced-traits-build':diagnostics(result[1],state)
        return result
    with patch.object(t.qa,'run',run):
        result=OLD(dest,env,rows,owners,state)
    assert (dest/'old-trait.stdout').read_bytes()==b'Columns\n'
    t.c.write(dest/'client-link.json',dict(state=state,consumer='uv executable',source_sha256=sha(D/'trait-control.rs'),selected=info,
                    build_stdout_sha256=sha(dest/'build.stdout'),binary_argv=sha(next((dest/'build-owners').glob('uv-bin-*.json')))))
    return result
def evidence(role,proof):
    result=OLD_EVIDENCE(role,proof);out=D/('functional-'+role+'-001');receipts={}
    for state in ('A','B','fresh-B'):
        d=out/state;rows=t.qa.native_rows((d/'build.stdout').read_bytes());owners=[read(x)for x in (d/'build-owners').glob('*.json')]
        paths,extern,search=selected(rows,owners);r=read(d/'client-link.json')
        assert r['state']==state and r['consumer']=='uv executable' and r['source_sha256']==sha(D/'trait-control.rs') and r['build_stdout_sha256']==sha(d/'build.stdout') and r['binary_argv']==sha(next((d/'build-owners').glob('uv-bin-*.json')))
        for k,parts in paths.items():
            assert [x['path']for x in r['selected'][k]]==parts and all(x['bytes']>0 and re.fullmatch('[a-f0-9]{64}',x['sha256'])for x in r['selected'][k])
        for tag in ('old-trait-build','introduced-traits-build'):
            cmd=read(d/(tag+'.return.json'));args=cmd['argv'];assert args[5:args.index('-o')]==search+extern
            assert cmd['exit']==int(state=='A'and tag=='introduced-traits-build')
        diagnostics((d/'introduced-traits-build.stderr').read_bytes(),state)
        assert (d/'old-trait.stdout').read_bytes()==b'Columns\n'
        if state!='A':
            assert (d/'introduced-traits.stdout').read_bytes()==b'Columns\nnew enum: preview and unknown select Preview\n' and read(d/'introduced-traits.return.json')['exit']==0
        receipts[state]=sha(d/'client-link.json')
    return result|{'authentic_client_link':receipts}
def rebind():
    t.D=D;t.REG=D/'registration.json';t.ADMIT=D/'admission.json';t.qa.trait_control=trait;t.qa.evidence=evidence
    t.bind()
def audit():
    r=read(D/'registration.json');prior=ORIGINAL/'functional-stock-001';failed=read(D/'previous.json')
    assert r['original_registration']==sha(ORIGINAL/'registration.json') and r['original_study']==sha(ORIGINAL/'run.py') and failed['raw']==t.qa.book(prior)
    assert read(prior/'return.json')['exit']==1 and not(prior/'success.json').exists() and not(prior/'closed.json').exists()
    assert all(not (ORIGINAL/t.cfg(i)['name']).exists()for i in t.PH)
    return BASE_AUDIT()
if __name__=='__main__':
    assert __debug__;os.umask(0o077);rebind();t.audit=audit
    report=t.main(sys.argv[1:])
    if report is not None:print(json.dumps(report,indent=2,sort_keys=True))
