"""Compare the exact qualified format-12 optimized T4 and signed −18 on uv #20990 native workspace test prep."""
from contextlib import contextmanager
import hashlib,importlib.util,inspect,json,os,shutil,subprocess,sys
from pathlib import Path
import re
from statistics import median
from unittest.mock import patch
from zipfile import ZipFile
D=Path(__file__).resolve().parent;COST=D.parents[1];W=COST.parent;R=COST/'trait-rosters';REG=D/'registration.json'
def load(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
f=load('attested_finite306_native_subjects',R/'build-test-ordinary/finite306/run.py')
sem=load('workspace_cargo_test_after_edit',D.parent/'20990-v3/semantics.py')
pr=load('uv20990_program_products',D/'products.py')
o,h=f.o,f.h;read=f.read;need=pr.need;sha=pr.digest
PH=('discovery','confirm-1','confirm-2');ROLES=('stock','candidate')
PROTO=read(D/'case.json');A,B,ARGS=PROTO['A'],PROTO['B'],PROTO['args']
def conf(ph):return read(D/(ph+'.json'))
def subject(deep=False):
    doc=f.subjects(deep);return {'issuer':doc['issuer'],'original_subject_registration':doc['registration'],'arms':doc['arms']}
def audit():
    reg=read(REG);need(__debug__ and all(sha(D/n)==v for n,v in reg['files'].items()),'registered files')
    o.audit();doc=subject();need(o.screen.CASES['20990']==(A,B,ARGS),'literal case')
    need(sha(o.screen.BANK/'receipt.json')==PROTO['bank_receipt_sha256'],'unmodified historical registry')
    code=['git','--git-dir',str(o.screen.BANK/'uv.git')]
    env=dict(PATH='/usr/bin:/bin',GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
    def git(*args):return subprocess.check_output([*code,*args],env=env)
    need(git('rev-parse',B+'^').decode().strip()==A and hashlib.sha256(git('diff','--full-index','--binary',A,B)).hexdigest()==PROTO['patch_sha256'],'original first-parent diff')
    need(git('diff','--name-only',A,B).decode().splitlines()==PROTO['paths'],'whole edit')
    for ph in PH:
        c=conf(ph);need(c['bank']==str(o.screen.BANK)and c['sdks']=={k:v['sdk']for k,v in doc['arms'].items()}and c['name']=='workspace-20990-finite306-'+ph+'-001'and c['plain'] and not c['diagnostics']and f.order(c)==reg['orders'][ph],'scope and 3/3 true orders')
    need(len({conf(p)['seed']for p in PH})==3 and os.sched_getaffinity(0)in ({29},set(range(16))),'seeds and cpu')
    return sha(REG)
def fresh(data):
    msg=sem.messages(data);arts=[r for r in msg if r['reason']=='compiler-artifact']
    need(len(arts)==PROTO['fresh_artifacts']and all(r['fresh']is True for r in arts)and sum(r['reason']=='build-finished'and r['success']is True for r in msg)==1,'authentic complete Cargo fresh roster')
    return msg
def worker(out,case):
    need(case=='20990'and out.name in ROLES and any(out.parent==D/conf(p)['name']for p in PH),'native target')
    doc=read(out.parent/'subject-intake.json');need(doc==subject(),'unchanged true T4/source and signed Cargo')
    backend=o.pairs.worker
    def inner(root,case):
        inherited=o.pairs.measure;held={}
        def observe(run,env,target,cmd,label,plain):
            h.floor(True)
            if label=='warm':f.identity(read(root/'identity.json'),doc['arms'][root.name])
            row=inherited(run,env,target,cmd,label,plain)
            if label=='warm':
                b=pr.run(run/'authoritative-A',[*cmd,'--message-format=json-render-diagnostics'],o.screen.SRC,env)
                ref=pr.ref_map(fresh(b.stdout),env,target,o.screen.SRC,PROTO['units'])
                held['ref']=ref;pr.put(run/'units.json',ref)
            ref=held['ref'];edited=label in ('edit-D','noop-D')
            rr,ss=pr.take(run,label,env,target,o.screen.SRC,ref,PROTO,edited)
            if label=='warm':held['warm']=(rr,ss)
            elif label in ('settled','settled-A'):
                oldp,olds=held['warm'];need(oldp==rr,'original warm A artifacts');pr.transition(olds,ss,ref['owner'],False);held['A']=(rr,ss)
                if label=='settled':
                    size=int(subprocess.check_output(['du','-s','-B1',target]).split()[0])
                    need(shutil.disk_usage('/tmp').free>size+(4<<30),'private fixed A copy plus transient space')
            elif label=='edit-D':
                need(sorted(row['dirty_units'])==sorted(PROTO['required_dirty']),'eight real package progress lines')
                need(held['A'][0]['workspace']['sha256']!=rr['workspace']['sha256'],'edited tests in new executable')
                pr.transition(held['A'][1],ss,ref['owner'],True);held['B']=(rr,ss)
            else:
                need(label=='noop-D'and rr==held['B'][0],'same B forms');pr.transition(held['B'][1],ss,ref['owner'],False)
                held.update(env=env.copy(),cmd=cmd.copy(),target=target,last=run.name)
            h.floor(True);return row
        with patch.object(o.pairs,'measure',observe):backend(root,case)
        need(held['last']=='pair-6'and o.screen.git('rev-parse','HEAD').decode().strip()==A and not o.screen.git('diff','--exit-code',B),'actual edit on parent')
        folder=o.screen.LANE/'records'/'functional';folder.mkdir()
        env=held['env']|{'UV_OFFLINE':'1','INSTA_UPDATE':'no'};cmd=held['cmd'];rr,ss=held['B']
        stable=pr.run(folder/'fresh',[*cmd,'--message-format=json-render-diagnostics'],o.screen.SRC,env)
        fresh(stable.stdout)
        originals=sem.signatures(rr,sha)
        for name in PROTO['tests']:
            call=[a for a in cmd if a!='--no-run']+['--message-format=json-render-diagnostics','--verbose',name,'--','--exact']
            obs=pr.run(folder/name,call,o.screen.SRC,env)
            _,facts=sem.verify(name,rr,stable.stdout,obs.stdout,obs.stderr,obs.returncode)
            need(sem.signatures(rr,sha)==originals and ss==pr.stamps(held['target']),'same genuine images throughout each native test')
            pr.put(folder/(name+'.verified.json'),facts)
        pr.put(folder/'all-images.json',originals)
        o.pairs.publish(folder,root);h.floor(True)
    with patch.object(o.pairs,'worker',inner):o.worker(out,case,PROTO)
def replay(phase,dest):
    cfg=conf(phase);doc=subject();plan=read(dest/'plan.json')
    need(read(dest/'subject-intake.json')==doc and plan['config']==cfg and list(plan['config']['sdks'])==list(cfg['sdks']) and
         plan['sequence']==f.order(cfg) and plan['runner']==sha(D/'run.py') and plan['source']==[A,B],'physical sealed enrollment')
    seq=plan['sequence'];rows=list(map(json.loads,(dest/'pairs.jsonl').read_text().splitlines()));need(len(rows)==6,'all genuine pairs')
    cmd=[str(o.screen.LANE/'sdk/bin/cargo'),*ARGS,'--locked','--offline','-j8']
    for k in ROLES:
        directory=dest/k;f.identity(read(directory/'identity.json'),doc['arms'][k])
        need(sha(directory/'edit.patch')==PROTO['patch_sha256']and plan['inputs'][k]['cargo']==o.CARGO,'fixed Cargo/full forward edit')
        for n in ('rustc.txt','cargo.txt'):need((directory/n).read_bytes()==(f.PRIOR/k/n).read_bytes(),'actual release receipts')
        def load_row(z,label,edited):
            r=json.loads(z.read(label+'.json'));ps=json.loads(z.read(label+'.products.json'));ss=json.loads(z.read(label+'.stamps.json'))
            need(r['cmd']==cmd and r['wall_s']>0 and len(ss)>=len(PROTO['units']) and set(ps)=={'uv','uvx','workspace'},'ordinary clock command/products')
            err=z.read(label+'.stderr');dirty=[n.decode().replace('-','_')for n in re.findall(rb'^\s*(?:Checking|Compiling) ([\w-]+) v',err,re.M)]
            need(r['dirty_units']==dirty and (sorted(dirty)==sorted(PROTO['required_dirty'])if label=='edit-D'else bool(dirty)if label=='warm'else not dirty),'raw native Cargo progress')
            for n,v in ps.items():
                content=z.read(label+'.'+n+'.out');need(hashlib.sha256(content).hexdigest()==v['stdout_sha256']==PROTO['products']['B'if edited else 'A'][n]and re.fullmatch('[a-f0-9]{64}',v['sha256'])and v['bytes']>100000,'real complete listings/versions and whole files')
            return r,ps,ss
        with ZipFile(directory/'setup.zip')as z:
            ref=json.loads(z.read('units.json'))
            need(set(ref['owner'])=={u[0]for u in PROTO['units']} and len(set(ref['owner'].values()))==11,'distinct concrete unit owners')
            initial=fresh(z.read('authoritative-A.stdout'))
            need(json.loads(z.read('authoritative-A.command.json'))=={'argv':cmd+['--message-format=json-render-diagnostics'],'exit':0},'independent Cargo artifact census')
            actual={pr.role(r,o.screen.SRC)for r in initial if r['reason']=='compiler-artifact'and Path(r['target']['src_path']).is_relative_to(o.screen.SRC)}
            need(all((p,n,tuple(kinds),t)in actual for p,n,kinds,t in PROTO['units']),'original Cargo roles')
            warm,wp,ws=load_row(z,'warm',False);_,ap,as_=load_row(z,'settled',False);need(wp==ap,'cold→settled A');pr.transition(ws,as_,ref['owner'],False)
        for i,(pair,order)in enumerate(zip(rows,seq,strict=True),1):
            with ZipFile(directory/f'pair-{i}.zip')as z:
                a,aps,ats=load_row(z,'settled-A',False);b,bps,bts=load_row(z,'edit-D',True);n,nps,nts=load_row(z,'noop-D',True)
                need(ap==aps and bps==nps and aps['workspace']['sha256']!=bps['workspace']['sha256'],'stable controls, changed workspace test')
                pr.transition(as_,ats,ref['owner'],False);pr.transition(ats,bts,ref['owner'],True);pr.transition(bts,nts,ref['owner'],False)
                f.paired(pair,order,i,k,a,b,n)
        with ZipFile(directory/'functional.zip')as z:
            ids=json.loads(z.read('all-images.json'));need({n:v[-1]for n,v in ids.items()}=={n:v['sha256']for n,v in bps.items()},'both real tests used same final B files')
            stable=z.read('fresh.stdout');fresh(stable);need(json.loads(z.read('fresh.command.json'))=={'argv':cmd+['--message-format=json-render-diagnostics'],'exit':0},'off-clock B roster')
            for name in PROTO['tests']:
                c=json.loads(z.read(name+'.command.json'));need(c['argv']==[a for a in cmd if a!='--no-run']+['--message-format=json-render-diagnostics','--verbose',name,'--','--exact'],'correct real test')
                _,facts=sem.verify(name,bps,stable,z.read(name+'.stdout'),z.read(name+'.stderr'),c['exit'])
                need(facts==json.loads(z.read(name+'.verified.json')),'original test outcomes')
    return [[p['stock']['edit']/p['candidate']['edit'],list(p)[0]] for p in rows]
def dest(phase):return D/conf(phase)['name']
def closed(phase):
    d=dest(phase);p=read(d/'closed.json');need(p['registration']==sha(REG)and all(sha(d/n)==v for n,v in p['files'].items()),'physical hashes')
    v=replay(phase,d);need(v==p['values'],'raw schedule/score');return v
def score():
    d=closed('discovery');rows=list(map(json.loads,(dest('discovery')/'pairs.jsonl').read_text().splitlines()))
    gap=median(x['candidate']['edit']-x['stock']['edit']/2 for x in rows)
    v={'discovery_pairs':6,'median_direct':median(x[0]for x in d),'paired_candidate_gap_s':gap,
       'arm_medians_s':{k:median(x[k]['edit']for x in rows)for k in ROLES},'held_out_pairs':0,'opens_confirmation':f.gate(d)}
    if not v['opens_confirmation']or not(dest('confirm-2')/'closed.json').exists():return v
    a,b=closed('confirm-1'),closed('confirm-2');all_=sorted(x[0]for x in a+b);strata=[median(w for w,k in a+b if k==r)for r in ROLES];seeds=[median(x[0]for x in z)for z in (a,b)];p=o.SCORE['sign_p'](all_,2)
    return v|{'held_out_pairs':12,'median':median(all_),'interval':[all_[1],all_[-2]],'coverage':1-26/4096,'order_medians':strata,'seed_medians':seeds,'p_above_two':p,'lower_above_2':all_[1]>2 and p<.025 and min(strata+seeds)>2}
def run(phase):
    cfg=conf(phase);need(not dest(phase).exists(),'fresh output')
    if phase!=PH[0]:
        need(f.gate(closed(PH[0])),'original 1.8 discovery gate')
        if phase==PH[2]:need(len(closed(PH[1]))==6,'first independent six')
    sys.path.insert(0,str(o.screen.SCOUT));import stage1
    host,_=stage1.original.v.local_receipt(stage1.RECEIPT,stage1.OLD)
    source=f.serial_source(o.pairs.outer)
    @contextmanager
    def already(other):
        need(Path(other.__file__)==Path(host.__file__) and Path(other.native.__file__)==Path(host.native.__file__) and set(other.locks())==set(host.locks())<set(locks) and len(set(locks))==4,'actual four native locks');yield locks
    with h.watched(),stage1.PRE.four(host)as locks:
        h.floor();doc=subject(True)
        with patch.object(stage1.PRE,'four',already),patch.object(o,'order',f.order),patch.object(inspect,'getsource',side_effect=lambda fn:source if fn is o.pairs.outer else (_ for _ in ()).throw(AssertionError('unexpected source selector'))):
            o.outer(D,D/(phase+'.json'),doc)
    d=dest(phase);values=replay(phase,d)
    files=[p for p in d.rglob('*')if p.is_file()]
    pr.put(d/'closed.json',{'registration':sha(REG),'values':values,'files':{p.relative_to(d).as_posix():sha(p)for p in files}})
    return score() if phase==PH[0]else dict(closed=closed(phase),phase=phase)
def main(args):
    seal=audit()
    if args==['audit']:return {'registration':seal,'original_ordinary_B_seconds':PROTO['old_ordinary_B_s'],'package_progress':PROTO['required_dirty'],'actual_units':len(PROTO['units']),'native_jobs':0}
    if args and args[0]=='worker':worker(Path(args[1]),args[2]);return
    need(os.sched_getaffinity(0)=={29},'native coordination')
    if args==['admit']:return subject(True)
    if args==['score']:return score()
    if len(args)==2 and args[0]=='closed'and args[1]in PH:return closed(args[1])
    need(len(args)==1 and args[0]in PH,'audit | admit | discovery | confirm-1 | confirm-2 | closed PHASE | score')
    return run(args[0])
if __name__=='__main__':
    doc=main(sys.argv[1:])
    if doc is not None:print(json.dumps(doc,sort_keys=True),flush=True)
