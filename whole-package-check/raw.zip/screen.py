"""Price first-edit and no-op Cargo commands in an offline, RAM-only target."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
TASK = HERE.parent.parent
SCOUT = TASK / "work/round18-rustc/over18-2x/release-scout"
BANK = Path(os.environ.get("UV_SCREEN_BANK", str(TASK / "work/round18-rustc/over18-2x/frontend/derive-20992/source-crlf/material-001")))
SDK = Path(os.environ.get("UV_SCREEN_SDK", str(TASK / "work/upstream-monitor/toolchain18")))
LANE = Path("/tmp/uv-workflow-search")
SRC = LANE / "uv"
CASES = {
    "20990": ("91b561383cadfc553d1e25cc38160d8fd05c4520", "b60da7ad468d5bb8a6b3dee7d7e54a47981f23c7",
              ["test", "-p", "uv", "--test", "workspace", "--no-run"]),
    "20988": ("b60da7ad468d5bb8a6b3dee7d7e54a47981f23c7", "1979349b68dbaa936b98c0f409c1df0598fa72f1",
              ["check", "-p", "uv"]),
    "20987": ("fbb0a829a377f1f8fd26bdaf6e4e07364ad0621b", "63486364d7720c30ecf1a0819b75d8de4db5b2b1",
              ["build", "-p", "uv", "--bin", "uv"]),
    "20987-check": ("fbb0a829a377f1f8fd26bdaf6e4e07364ad0621b", "63486364d7720c30ecf1a0819b75d8de4db5b2b1",
                    ["check", "-p", "uv-virtualenv", "--all-targets"]),
    "parser": ("a50af60fb4162d7f94812d64c481c30a0200b6d8", "63251e5ce54f03363a10c088d7f9f6d6ba268302",
               ["test", "-p", "uv-pypi-types", "--lib", "--no-run"]),
    "20220": ("4fab9d39023ec01489b4d7e5acb398939b5fd9b7", "95e2f573a7e48a03dd8fdcfae5597774ac692479",
              ["check", "-p", "uv-install-wheel", "--all-targets"]),
    "20651": ("b6b2e7639c6d05e54cd1954a899182b81565fb00", "c2e07d56c6897f968a62f23b4feabf029787e772",
              ["check", "-p", "uv-cli", "--all-targets"]),
}


def git(*args):
    return subprocess.check_output(["git", "-C", SRC, *args])


def objects(target):
    return {p.relative_to(target).parts[-3] + "/" + p.name: (p.stat().st_ino, p.stat().st_size)
            for p in (target / "debug/incremental").glob("*/s-*/*.o")}


def sidecars(target):
    paths = (target / "debug").glob("**/*.public-api-hash")
    return {str(p.relative_to(target)): json.loads(p.read_bytes()) for p in paths}


def measure(out, env, target, cmd, label):
    before = objects(target)
    start = time.perf_counter_ns()
    p = subprocess.run(cmd, cwd=SRC, env=env, capture_output=True)
    wall = time.perf_counter_ns() - start
    (out / (label + ".jsonl")).write_bytes(p.stdout)
    (out / (label + ".log")).write_bytes(p.stderr)
    if p.returncode:
        raise RuntimeError(p.stderr.decode(errors="replace")[-1700:] + p.stdout.decode(errors="replace")[-800:])
    after = objects(target)
    changed = {}
    for key, val in after.items():
        if before.get(key) != val:
            unit = key.split("/")[0]
            changed[unit] = changed.get(unit, 0) + 1
    rows = [json.loads(line) for line in p.stdout.splitlines() if line.startswith(b"{")]
    artifacts = [r for r in rows if r.get("reason") == "compiler-artifact"]
    summary = {"wall_s": wall / 1e9, "cmd": cmd, "changed_object_files": changed,
               "dirty_units": [r["target"]["name"] for r in artifacts if not r["fresh"]],
               "executables": [r["executable"] for r in artifacts if r["executable"]]}
    timing = target / "cargo-timings/cargo-timing.html"
    if timing.exists():
        shutil.copyfile(timing, out / (label + ".html"))
    (out / (label + ".json")).write_text(json.dumps(summary, indent=2))
    print(out.name, label, round(wall / 1e9, 3), len(summary["dirty_units"]), flush=True)
    return summary


def worker(dest, cases, flags):
    assert set(os.sched_getaffinity(0)) == set(range(16))
    assert os.statvfs(TASK).f_flag & os.ST_RDONLY
    assert os.statvfs(BANK).f_flag & os.ST_RDONLY
    assert subprocess.check_output(["stat", "-f", "-c", "%T", "/tmp"], text=True).strip() == "tmpfs"
    assert not any((LANE / name).exists() for name in ("uv", "target", "records"))
    installed = LANE / "sdk"
    assert os.statvfs(installed).f_flag & os.ST_RDONLY
    env = dict(PATH=str(installed / "bin") + ":/usr/bin:/bin", HOME=str(LANE / "home"), CARGO_HOME=str(LANE / "cargo"),
               RUSTC=str(installed / "bin/rustc"), RUSTDOC=str(installed / "bin/rustdoc"), CARGO_TERM_COLOR="never",
               LC_ALL="C.UTF-8", CARGO_NET_OFFLINE="true", GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_NOSYSTEM="1",
               GIT_NO_LAZY_FETCH="1", GIT_ALLOW_PROTOCOL="file")
    if flags:
        env["RUSTFLAGS"] = flags
    trace = os.environ.get("UV_SCREEN_TRACE") == "1"
    rdr = os.environ.get("UV_SCREEN_RDR")
    if rdr:
        sys.path.insert(0, str(HERE))
        import rdr_snapshot
    if trace:
        env["RUSTC_WRAPPER"] = str(HERE / "rustc-trace.sh")
    os.environ.update({k:v for k,v in env.items() if k.startswith("GIT_") or k == "HOME"})
    (LANE / "home").mkdir()
    subprocess.run(["git", "-c", "core.autocrlf=false", "clone", "--no-checkout",
                    (BANK / "uv.git").resolve().as_uri(), SRC], check=True, env=env)
    records = LANE / "records"
    records.mkdir()
    (records / "compiler.txt").write_bytes(subprocess.check_output([env["RUSTC"], "-vV"], env=env))
    (records / "cargo.txt").write_bytes(subprocess.check_output([str(installed / "bin/cargo"), "-Vv"], env=env))
    (records / "environment.json").write_text(json.dumps(env, indent=2))
    try:
        for case in cases:
            parent, edited, args = CASES[case]
            out = records / case
            out.mkdir()
            target = LANE / "target"
            env["CARGO_TARGET_DIR"] = str(target)
            if target.exists():
                shutil.rmtree(target)
            git("checkout", "-f", "--detach", parent)
            delta = git("diff", "--binary", parent, edited)
            (out / "edit.patch").write_bytes(delta)
            jobs = "-j4" if case == "20220" else "-j8"
            cmd = [str(installed / "bin/cargo"), *args, "--locked", "--offline", jobs, "--timings",
                   "--message-format=json-render-diagnostics"]
            measure(out, env, target, cmd, "warm")
            measure(out, env, target, cmd, "settled")
            (out / "parent-sidecars.json").write_text(json.dumps(sidecars(target)))
            if rdr:
                parent_rdr = rdr_snapshot.collect(target, set(rdr.split(",")))
            subprocess.run(["git", "-C", SRC, "apply", "--index", "-"], input=delta, check=True)
            assert git("write-tree").strip() == git("rev-parse", edited + "^{tree}").strip()
            git("reset", "-q", "--mixed", parent)
            assert git("rev-parse", "HEAD").decode().strip() == parent
            # Compare the working files with the complete child tree even when
            # the real unstaged edit contains a new file absent from A's index.
            expected_index = dict(os.environ, GIT_INDEX_FILE=str(LANE / "expected.index"))
            subprocess.run(["git", "-C", SRC, "read-tree", edited], env=expected_index, check=True)
            subprocess.run(["git", "-C", SRC, "update-index", "-q", "--refresh"], env=expected_index, check=True)
            subprocess.run(["git", "-C", SRC, "diff-files", "--quiet"], env=expected_index, check=True)
            if trace:
                (out / "rustc").mkdir()
                env["UV_SCREEN_TRACE_DIR"] = str(out / "rustc")
                if os.environ.get("UV_SCREEN_PROFILE"):
                    env["UV_SCREEN_PROFILE"] = os.environ["UV_SCREEN_PROFILE"]
            d = measure(out, env, target, cmd, "first-edit")
            env.pop("UV_SCREEN_TRACE_DIR", None)
            env.pop("UV_SCREEN_PROFILE", None)
            (out / "edited-sidecars.json").write_text(json.dumps(sidecars(target)))
            if rdr:
                edited_rdr = rdr_snapshot.collect(target, set(rdr.split(",")))
                (out / "rdr.json").write_text(json.dumps(rdr_snapshot.compare(parent_rdr, edited_rdr)))
            measure(out, env, target, cmd, "noop")
            if case == "20990":
                exe, = [Path(s) for s in d["executables"] if "workspace-" in s]
                listing = subprocess.check_output([exe, "--list"], env=env, cwd=SRC)
                assert b"workspace_metadata::workspace_metadata_quiet: test" in listing
                assert b"workspace_metadata::workspace_metadata_extra_quiet: test" in listing
                (out / "edited.list").write_bytes(listing)
            if case == "parser":
                exe, = [Path(s) for s in d["executables"] if "/uv_pypi_types-" in s]
                listing = subprocess.check_output([exe, "--list"], env=env, cwd=SRC)
                assert b"simple_json::tests::parse_pypi_simple_json_rejects_invalid_input: test" in listing
                (out / "edited.list").write_bytes(listing)
            if case == "20220":
                verify = subprocess.run([str(installed / "bin/cargo"), "test", "--locked", "--offline", jobs,
                    "-p", "uv-errors", "--lib", "tests::formats_debug_error_chain", "--", "--exact"],
                    env=env, cwd=SRC, capture_output=True)
                (out / "verify.log").write_bytes(verify.stdout + verify.stderr)
                assert verify.returncode == 0 and b"1 passed; 0 failed" in verify.stdout
    finally:
        with zipfile.ZipFile(dest, "x", zipfile.ZIP_DEFLATED, compresslevel=3) as z:
            for path in sorted(records.rglob("*")):
                if path.is_file():
                    z.write(path, str(path.relative_to(records)))


def outer(name, cases, flags):
    sys.path.insert(0, str(SCOUT))
    import stage1 as b
    assert re.fullmatch("[a-z0-9-]+", name) and all(i in CASES for i in cases)
    out = HERE / name
    out.mkdir()
    os.sched_setaffinity(0, {29})
    host, _ = b.original.v.local_receipt(b.RECEIPT, b.OLD)
    with b.PRE.four(host):
        avail = b.available()
        assert avail["ram"] >= 55 * 2**30, avail
        cmd = ["bwrap", "--die-with-parent", "--unshare-net", "--unshare-pid", "--ro-bind", "/", "/",
               "--dev", "/dev", "--proc", "/proc", "--size", str(24 * 2**30), "--tmpfs", "/tmp",
               "--ro-bind", str(BANK), str(BANK),
               "--dir", str(LANE / "cargo"), "--ro-bind", str((BANK / "registry").resolve()), str(LANE / "cargo/registry"),
               "--ro-bind", str(SDK.resolve(strict=True)), str(LANE / "sdk"),
               "--bind", str(out), str(out), "--", "taskset", "-c", "0-15", "/usr/bin/python3", "-ISB",
               str(Path(__file__).resolve()), "worker", name, ",".join(cases), flags]
        (out / "launch.json").write_text(json.dumps({"command": cmd, "opening": avail,
             "trace": os.environ.get("UV_SCREEN_TRACE"), "rdr": os.environ.get("UV_SCREEN_RDR"),
             "runner": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
        try:
            p = subprocess.run(cmd, check=True, timeout=3600)
        finally:
            (out / "ending.json").write_text(json.dumps(b.available()))


if __name__ == "__main__":
    mode, name, selection, flags = sys.argv[1:]
    cases = selection.split(",")
    if mode == "outer":
        outer(name, cases, flags)
    else:
        assert mode == "worker"
        worker(HERE / name / "records.zip", cases, flags)
