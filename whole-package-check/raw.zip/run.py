"""Fresh whole-uv #20988 transfer from the qualified same-format H3 and T4 compilers."""
from collections import Counter
from pathlib import Path
from statistics import median
from unittest.mock import patch
from zipfile import ZipFile
import hashlib, itertools, json, os, re, stat, subprocess, sys

D = Path(__file__).resolve().parent
R = D.parents[2]
OLD = R / "paired/prebolt-release22-007"
M = D.parent / "matched"
sys.path.insert(0, str(OLD))
import prebolt_bench as b

o, u = b.o, b.uv
PH = ("discovery", "confirm-1", "confirm-2")
REG = D / "registration.json"
INTAKE = D / "admission.json"
HIST = R / "paired/uv-package-20988"
ACTUAL = M / "admission.json"
SEEDS = [4261143207, 2740424593, 3509207731]
GOLD = b.read(HIST / "historical.json")
RULE = sorted(GOLD["packages"])
ROLES = ("stock", "parent", "candidate")
DIGEST = {"stock": "a7648053cbad025c1bb0bebb7009ce9e1515bdb02e8c30bef29b52a881e5b8de", "parent": "02dce4f3b", "candidate": "f10dcce34"}
read, sha, check = b.read, b.sha, b.check
ORIG_WORKER, ORIG_COLLECTED = b.worker, b.collected


def digest(doc):
    return hashlib.sha256((json.dumps(doc, sort_keys=True) + "\n").encode()).hexdigest()


def cfg(k, phase):
    check(k == "uv" and phase in PH, "whole uv only")
    return read(OLD / "uv" / (phase + ".json")) | {
        "seed": SEEDS[PH.index(phase)], "name": phase + "-whole-uv-matched-v12-001",
        "sdks": {role: arm["sdk"] for role, arm in read(ACTUAL)["arms"].items()}}


def filemap(sdk, registered, overlay=False):
    # Device/inode values are irrelevant across the genuinely independent SDK projection.
    check(sdk.is_dir() and not sdk.is_symlink(), "real SDK")
    actual = {str(f.relative_to(sdk)): f for f in sdk.rglob("*") if f.is_file() or f.is_symlink()}
    check(set(actual) == set(registered) and len(actual) == 77, "complete 77-file SDK")
    for n, f in actual.items():
        expected = registered[n]
        check(f.resolve() == f and stat.S_ISREG(f.stat().st_mode) and [sha(f), f.stat().st_size, stat.S_IMODE(f.stat().st_mode)] == expected, "actual SDK bytes/mode " + n)
    if overlay:
        check(registered["bin/cargo"][0] == o.CARGO and os.statvfs(sdk).f_flag & os.ST_RDONLY, "fixed signed Cargo in read-only projection")


def issuer():
    previous = read(ACTUAL)
    result = subprocess.check_output(["/usr/bin/taskset", "-c", "29", "/usr/bin/python3", "-ISB", str(M/"run.py"), "admit"], env=dict(os.environ, GIT_NO_LAZY_FETCH="1"))
    check(json.loads(result)["verified"] == sha(ACTUAL), "current original H3/T4 deeply admitted and both trained subjects verify")
    out = {}
    for role in ("parent", "candidate"):
        arm = previous["arms"][role]
        sdk = Path(arm["sdk"])
        source = read(sdk.parent / "native-payloads.json")
        entries = {k[4:]: v for k, v in source.items() if k.startswith("sdk/")}
        filemap(sdk, entries)
        out[role] = entries
    proof = {"registration": sha(REG), "original_fixed_header_issuer": sha(ACTUAL), "fixed_issuer_facts": previous,
             "arms": previous["arms"], "native_files": out, "cargo": o.CARGO, "historical_clocks": 0}
    local(proof, stored=False)
    return proof


def local(proof, stored=True):
    if stored:
        check(read(INTAKE) == proof, "real prior positive whole-uv admission")
    previous = read(ACTUAL)
    check(sha(ACTUAL) == read(REG)["fixed_issuer_sha256"] == proof["original_fixed_header_issuer"] and proof["fixed_issuer_facts"] == previous and proof["arms"] == previous["arms"], "frozen real fixed-header subjects")
    check(proof["registration"] == sha(REG) and proof["historical_clocks"] == 0 and proof["cargo"] == previous["cargo_sha256"] == o.CARGO, "subject provenance and fixed signed Cargo")
    arms = proof["arms"]
    for role in ROLES:
        check(arms[role]["driver_sha256"] == read(REG)["role_pins"][role]["driver"] and arms[role]["driver_sha256"].startswith(DIGEST[role]), "exact real DSO")
    shared = []
    for role in ("parent", "candidate"):
        a = arms[role]; pins = read(REG)["role_pins"][role]; files = proof["native_files"][role]
        check(a["header_format"] == 12 and [a[k] for k in ("commit","tree","profile_sha256","launcher_sha256")] == [pins[k] for k in ("commit","tree","profile","launcher")], "current actual source, own trained profile and launcher")
        check(len(files) == 77 and files[a["driver_relative"]][0] == a["driver_sha256"] and files["bin/rustc"][0] == a["launcher_sha256"] and files["bin/cargo"][0] == b.s.KIT_CARGO, "complete source-arm identity")
        common = {n:v for n,v in files.items() if n not in ["bin/rustc", a["driver_relative"]]}
        shared.append(common)
    check(shared[0] == shared[1] and len(shared[0]) == previous["common_companions"] == 75 and digest(shared[0]) == previous["common_companions_sha256"] and arms["parent"]["profile_sha256"] != arms["candidate"]["profile_sha256"], "all 75 common files + two exact native subjects")


def plans():
    return {p:cfg("uv", p) for p in PH}


def audit():
    check(__debug__, "assertions required")
    reg = read(REG)
    for rel, expected in reg["bindings"].items():
        check(sha(D/rel) == expected, "frozen source/input " + rel)
    check(sha(Path(u.P["bank"])/"receipt.json") == u.P["bank_receipt_sha256"] and sha(ACTUAL) == reg["fixed_issuer_sha256"], "source material and native issuer")
    check(u.P["args"] == ["check", "-p", "uv"] and u.P["A"] == "b60da7ad468d5bb8a6b3dee7d7e54a47981f23c7" and u.P["B"] == "1979349b68dbaa936b98c0f409c1df0598fa72f1" and u.P["patch_sha256"] == "24852ea0d29fe8eb355f2a0d4eb682c54e53fa56af3d048635f4de9049925ecb", "actual complete #20988")
    with ZipFile(u.ORIGIN) as z:
        raw = z.read("20988/first-edit.jsonl")
        arts = [json.loads(l) for l in raw.splitlines()]
        targets = sorted([r["target"]["name"],r["target"]["kind"][0]] for r in arts if r.get("reason")=="compiler-artifact" and not r["fresh"])
        check(hashlib.sha256(raw).hexdigest() == GOLD["cargo_json_sha256"] and targets == GOLD["dirty_artifacts"] and len(targets) == 15 and packages(z.read("20988/first-edit.log")) == RULE and len(RULE) == 13, "15 historical Cargo targets and 13 plain package lines")
    stages = plans()
    oldseeds = {read(root/(stage+".json"))["seed"] for root in (OLD/"uv",OLD/"resolver",M,D.parent/"trial") for stage in PH}
    check(not oldseeds.intersection(SEEDS) and len(set(SEEDS))==3, "separate fresh seeds")
    for ph,q in stages.items():
        check(q == read(D/(ph+".json")) and q["case"]=="20988" and q["plain"] and not q["diagnostics"] and q["pairs"] == 6, "one excluded and two independently seeded cohorts")
        order = list(map(list,o.order(q)))
        check(order == reg["orders"][ph] and set(map(tuple,order)) == set(itertools.permutations(ROLES)), "six actual order permutations")
    check(len(set(str(reg["orders"][ph]) for ph in PH))==3, "separate order histories")
    return {"registration":sha(REG), "historical_rows":0, "source": [u.P["A"],u.P["B"]], "seeds":SEEDS, "dirty_packages":13, "historical_products":15, "native_members_each":77}


def packages(raw):
    names = re.findall(rb"^\s*(?:Checking|Compiling) ([\w-]+) v", raw, re.M)
    return sorted(name.decode().replace("-", "_") for name in names)


def products(target):
    rows = {}
    for stem, kind in GOLD["dirty_artifacts"]:
        package = "uv" if stem == "uvx" else stem.replace("_","-")
        matches = []
        for f in (target/"debug/build"/package).glob("*/out/lib"+stem+"-*.rmeta"):
            folder = f.parent.parent
            fingerprint = folder/"fingerprint"/("lib-"+stem+".public-api-hash")
            if ("lib" if fingerprint.is_file() else "bin") != kind:
                continue
            check(f.resolve(strict=True).is_relative_to(target.resolve()) and f.stem=="lib"+stem+"-"+folder.name,"real classified library/binary product")
            st=f.stat()
            value={"path":str(f.relative_to(target)),"size":st.st_size,"inode":st.st_ino,"mtime":st.st_mtime_ns}
            if kind=="lib":
                api=read(fingerprint)
                check(16<st.st_size<=96<<20 and api["version"]==1 and re.fullmatch("[0-9a-f]{32}",api["value"]), "actual library metadata/fingerprint")
                value["public_hash"]=api["value"]
            else:
                # Check-mode binary .rmeta can be an empty marker. Observe its own unit
                # fingerprint as a second source of fresh-build evidence.
                markers = {}
                for marker in [folder/"fingerprint"/("bin-"+stem), folder/"fingerprint"/("bin-"+stem+".json"),
                               folder/"fingerprint"/"invoked.timestamp", folder/"invoked.timestamp"]:
                    if marker.is_file():
                        st = marker.stat()
                        check(st.st_size < 512<<10 and marker.resolve().is_relative_to(folder.resolve()), "bounded private Cargo fingerprint")
                        markers[str(marker.relative_to(folder))]=[sha(marker),st.st_size,st.st_mtime_ns,st.st_ino]
                value["unit_markers"]=markers
            matches.append(value)
        check(len(matches)==1, "complete unique real package product " + stem+"/"+kind)
        rows[kind+"-"+stem] = matches[0]
    check(len(rows)==15, "fifteen expected whole-package products")
    return rows


def listed(path, role, expect_hash):
    # This is an off-clock inspection of the actual checked metadata, using its own rustc.
    sdk=o.screen.LANE/"sdk"
    run=subprocess.run([str(sdk/"bin/rustc"),"-Zls=root",str(path)],env=dict(os.environ,RUSTC_BOOTSTRAP="1"),capture_output=True)
    check(run.returncode==0 and not run.stderr and len(run.stdout)<256<<10, "native metadata loader refused "+str(path))
    check_listing(run.stdout,role,expect_hash)
    return run.stdout


def check_listing(data,role,expect_hash):
    text=data.decode()
    check(text.startswith("Crate info:\n") and re.search(r"(?m)^name "+role+r"-[a-f0-9]+$",text) and
          re.search(r"(?m)^triple x86_64-unknown-linux-gnu$",text) and
          re.search(r"(?m)^public_hash "+expect_hash+r"$",text),"native root/target/public fingerprint")


def worker(out,case):
    q=read(out.parent/"plan.json")["config"];proof=read(out.parent/"subject-intake.json");local(proof)
    check(q in plans().values() and out.parent==D/q["name"] and case=="20988" and os.sched_getaffinity(0)==set(range(16)), "real fresh native worker")
    arm=proof["arms"][out.name];sdk=o.screen.LANE/"sdk"
    if out.name != "stock":
        native=dict(proof["native_files"][out.name]); stock_cargo=o.S/"bin/cargo"
        native["bin/cargo"]=[o.CARGO,stock_cargo.stat().st_size,stat.S_IMODE(stock_cargo.stat().st_mode)]
        filemap(sdk,native,overlay=True)
    check(sha(sdk/arm["driver_relative"])==arm["driver_sha256"] and sha(sdk/"bin/rustc")==arm["launcher_sha256"] and sha(sdk/"bin/cargo")==o.CARGO,"actual mapped source compiler and signed Cargo")
    original=o.original
    def observe(run,env,target,cmd,label,plain):
        row=original(run,env,target,cmd,label,plain)
        if label in ("settled-A","edit-D","noop-D"):
            check(plain and packages((run/(label+".stderr")).read_bytes())==(RULE if label=="edit-D" else []), "exact plain package dirtiness")
            b.write(run/(label+".all-products.json"),products(target))
        return row
    with patch.object(o,"original",observe):
        ORIG_WORKER("uv",out,case)
    for state,target in (("A",o.screen.LANE/"a-target"),("B",o.screen.LANE/"target")):
        rows=products(target)
        for role in ("uv","uv_workspace"):
            x=rows["lib-"+role];data=listed(target/x["path"],role,x["public_hash"])
            (out/(state+"-"+role+".metadata-list")).write_bytes(data)


def collected(k,ph,proof):
    check(k=="uv","whole package only")
    rows=ORIG_COLLECTED(k,ph,proof)
    where=D/cfg(k,ph)["name"]
    for role in ROLES:
        w=where/role
        complete=read(w/"metadata.json")
        for state in ("A","B"):
            for name in ("uv","uv_workspace"):
                value=complete[state]["lib-"+name]
                check_listing((w/(state+"-"+name+".metadata-list")).read_bytes(),name,value["public_hash"])
        for ix in range(1,7):
            with ZipFile(w/f"pair-{ix}.zip")as z:
                a,d,n=[json.loads(z.read(label+".all-products.json"))for label in ("settled-A","edit-D","noop-D")]
                check(len(a)==len(d)==len(n)==15 and set(a)==set(d)==set(n) and d==n,"whole B and clean repeat")
                check(packages(z.read("edit-D.stderr"))==RULE and not packages(z.read("settled-A.stderr")) and not packages(z.read("noop-D.stderr")),"raw zero/13/zero package checks")
                for key,old in a.items():
                    check(old["path"]==d[key]["path"] and old!=d[key],"fresh product after the edit "+key)
    return rows


def gate(k,rows):
    return k=="uv" and len(rows)==6 and median(r["stock_T"] for r in rows)>=1.8 and median(r["C_T"] for r in rows)>1


def outcome(cohorts):
    alpha=.025
    direct=b.contrast(lambda r:r["stock_T"],cohorts,("stock","candidate"),alpha,2)
    matched=b.contrast(lambda r:r["C_T"],cohorts,("parent","candidate"),alpha,1)
    return {"direct_signed18_over_T4":direct,"matched_same_header_H3_over_T4":matched,"positive_matched":matched["passed"],"direct_twofold":direct["passed"] and o.confirmed(cohorts)["qualified"],"heldout_triples":12,"multiplicity":"Two prospective transfer contrasts, per-contrast alpha 0.025. Earlier resolver work supplies zero rows."}


def live():
    positive=issuer();local(positive);return positive


def wire():
    b.REG=REG;b.ADMISSION=INTAKE;b.PROTOCOL={"uv":u.P};b.MODELS=dict.fromkeys(ROLES)
    b.cfg=cfg;b.home=lambda k:D;b.local_proof=local;b.live=live;b.collected=collected;b.eligible=gate


def main(args):
    wire()
    if args==["audit"]:return audit()
    if len(args)==3 and args[0]=="worker":return worker(Path(args[1]),args[2])
    check(len(args)==1 and args[0] in ("admit",*PH,"score"), "audit | admit | discovery | confirm-1 | confirm-2 | score")
    audit();ph=args[0]
    if ph=="admit":
        result=issuer()
        if not INTAKE.exists():b.write(INTAKE,result)
        local(result)
        return {"admission_sha256":sha(INTAKE),"observed_images":len(result["arms"]),"scored_historical_rows":0}
    proof=live();b.choose("uv")
    if ph in PH:
        if ph!="discovery":check(gate("uv",b.closed("uv","discovery",proof)),"excluded nomination did not open")
        if ph=="confirm-2":b.closed("uv","confirm-1",proof)
        b.launch("uv",ph,proof)
    disc=b.closed("uv","discovery",proof)
    out={"excluded_triples":6,"opens_confirmation":gate("uv",disc),"discovery_seconds":b.strength("uv","discovery"),"heldout_triples":0}
    if (D/cfg("uv","confirm-2")["name"]/"closed.json").exists():
        out.update(outcome([b.closed("uv",q,proof)for q in PH[1:]]));out["heldout_seconds"]={q:b.strength("uv",q)for q in PH[1:]}
    return out


if __name__=="__main__":
    result=main(sys.argv[1:])
    if result is not None:print(json.dumps(result,sort_keys=True,indent=2))
